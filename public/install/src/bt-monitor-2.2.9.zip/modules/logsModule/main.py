import json, time, re, os
import core.include.public as public
from core.include.monitor_helpers import basic_monitor_obj
from core import app


class main:


    def get_log_list(self,args):
        '''
            @name 获取日志列表
            @author hwliang
            @param p <int> 页码 (可选)
            @param row <int> 每页条数 (可选)
            @param callback <str> 回调函数 (可选)
            @param search <str> 搜索关键字 空 (可选)
            @param type <str> 日志类型 [系统设置、系统日志、网站日志 业务监控  告警通知 用户登录 主机授权 用户管理 ]  默认空 (可选)
            @param status_code <int> 状态码 -1:全部 0:失败 1:成功  默认-1 (可选)
            @param sort_key <str> 排序字段 默认id (可选)
            @param sort_type <str> 排序方式 desc:降序 asc:升序 默认desc (可选)
            @return dict
        '''
        # 安全监控('漏洞','病毒','挖矿')   安全监控-漏洞  安全监控-病毒  安全监控-挖矿

        # 获取参数
        p = args.get('p/d',1)
        row = args.get('row/d',10)
        callback = args.get('callback','')
        search = args.get('search','')
        type = args.get('type/xss','')
        status_code = args.get('status_code/d',-1)
        sort_key = args.get('sort_key/xss','id')
        sort_type = args.get('sort_type/xss','desc')

        # 表单验证
        if not sort_type in ['desc','asc']:
            sort_type = 'desc'
        if not re.match('^[\w]+$',sort_key):
            sort_key = 'id'
        order = '{} {}'.format(sort_key,sort_type)

        if p < 1: p = 1
        if row < 1: row = 10
        if status_code not in [-1,0,1]: status_code = -1

        sql_obj = public.M('logs')

        # 查询条件处理
        where = ''
        params = []
        if search:
            where = "`log` LIKE ?"
            params.append('%' + search + '%')
        if type:
            # where = "type = ?" if not where else where + " AND type = ?"
            where = "`type` like ? " if not where else where + " AND `type` like ?"
            params.append('%' + type + '%')
        if status_code != -1:
            where = "status_code = ?" if not where else where + " AND status_code = ?"
            params.append(status_code)

        # 获取分页
        total = sql_obj.where(where,params).count()
        data = public.get_page(total,p,row,callback)

        # 导出用条件
        export_log_where = sql_obj.where(where, params).order(order)

        # 获取数据
        data['data'] = sql_obj.where(where,params).order(order).limit(data["shift"],data['row']).select()

        # DEMO
        if basic_monitor_obj.in_demo():
            # IP匿名化
            for item in data['data']:
                item['log'] = public.mask_ipv4_address(item['log'])

        # 导出

        if args.get('export_log', None) == '1':
            ret_export_log = export_log_where.select()
            # ret_export_log = ret_data_.select()

            if ret_export_log is None or len(ret_export_log) < 1:
                return public.error('没有可导出的数据')

            # for item in ret_export_log:
            #     server_info = servers.get(int(item['sid']), {})
            #     item['ip'] = server_info.get('ip', '')
            #     item['login_ip'] = '{}{}'.format(
            #         item['login_ip'], ':{}'.format(item['port'])
            #         if int(item['port']) > 0 else '')
            #     item['remark'] = server_info.get('remark', '')

            import pandas as pd
            # 处理数据
            for i in ret_export_log:
                # i['addtime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(i['addtime']))
                i['status_code'] = '成功' if i['status_code'] == 1 else '失败'

            # 将数据转换为DataFrame对象
            df = pd.DataFrame(ret_export_log)

            #  选择需要导出的字段
            selected_columns = {"id": "编号", "type": "操作类型", "addtime": "操作时间", "log": "详情",
                                "username": "用户", "status_code": "状态"}

            selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)

            # # 导出数据到CSV文件中
            export_file_path = "/tmp/exported_master_control_logs.csv"
            selected_df.to_csv(export_file_path, index=False)
            from datetime import date
            return public.send_file('/tmp/exported_master_control_logs.csv', 'master_control_logs_{}.csv'.format(date.today()))

        return public.return_data(True,data)

    def get_error_log(self, args):
        '''
            @name 获取最后1000行错误日志信息
            @author Zhj<2022-07-20>
            @arg    n<?integer>  获取最后n行[可选 默认1000]
            @return dict
        '''
        n = int(args.get('n', 1000))

        log_file = public.get_panel_log_file(True)

        if not os.path.exists(log_file):
            return public.success('')

        return public.success(public.GetNumLines(log_file, n))
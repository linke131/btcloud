#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, sys, time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
# from core.include.warning import Warning
from core.include.monitor_helpers import warning_obj
# import core.include.c_loader.PluginLoader as plugin_loader


# Warning = plugin_loader.get_module('{}/core/include/warning.py'.format(public.get_panel_path())).Warning

def warn():
    # 开始告警
    # with Warning() as warning_obj:
    #     try:
    #         # 关闭事务自动提交
    #         warning_obj.db_autocommit(False)
    #
    #         # 获取所有主机告警规则
    #         warning_rules = warning_obj.get_warning_rules()
    #
    #         s = time.time()
    #         print('--开始告警')
    #         for warning_rule in warning_rules:
    #             warning_obj.warn(warning_rule)
    #         print('--告警结束 耗时：{}s'.format(time.time() - s))
    #
    #         # 提交事务
    #         warning_obj.db_commit()
    #
    #     except BaseException as e:
    #         # 回滚事务
    #         warning_obj.db_rollback()
    #
    #         # 记录异常堆栈
    #         public.print_exc_stack(e)
    #
    #         print('--告警出现异常: {}'.format(str(e)))

    try:
        # 获取所有主机告警规则
        warning_rules = warning_obj.get_warning_rules()

        s = time.time()
        print('--开始告警')
        for warning_rule in warning_rules:
            warning_obj.warn(warning_rule)
        print('--告警结束 耗时：{}s'.format(time.time() - s))

    except BaseException as e:
        # 记录异常堆栈
        public.print_exc_stack(e)

        print('--告警出现异常: {}'.format(str(e)))

if __name__ == '__main__':
    # 开始告警
    warn()
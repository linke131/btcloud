#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, sys, re, time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

# import core.include.public as public
from core.include.monitor_helpers import warning_obj

if __name__ == '__main__':
    warning_obj.update_servers()
#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os
import sys
import time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import sqlite_server

if __name__ == '__main__':
    cur_time = int(time.time())

    print('[{}]'.format(time.strftime('%Y-%m-%d %X')))
    os.system('chmod +x ./init.sh')
    os.system('./init.sh stop')
    time.sleep(30)
    os.system('chmod +x ./sqlite-server.sh')
    os.system('./sqlite-server.sh restart')

    with sqlite_server.Db('/www/server/bt-monitor/data/monitor_databases/availability_http_info') as db:
        s_time = time.time()
        print('|-正在整理数据库/www/server/bt-monitor/data/monitor_databases/availability_http_info.db >> ', end='')
        max_id = db.query().name('availability_http_info')\
            .where('uid > 0')\
            .where('create_time > ?', cur_time - (3 * 86400))\
            .value('id')
        db.query()\
            .name('availability_http_info')\
            .where('id < ?', max_id)\
            .delete()
        db.vacuum()
        print('{}s'.format(round(time.time() - s_time)))

    with sqlite_server.Db('/www/server/bt-monitor/data/monitor_databases/availability_port_info') as db:
        s_time = time.time()
        print('|-正在整理数据库/www/server/bt-monitor/data/monitor_databases/availability_port_info.db >> ', end='')
        max_id = db.query().name('availability_port_info')\
            .where('uid > 0')\
            .where('create_time > ?', cur_time - (3 * 86400))\
            .value('id')
        db.query()\
            .name('availability_port_info')\
            .where('id < ?', max_id)\
            .delete()
        db.vacuum()
        print('{}s'.format(round(time.time() - s_time)))

    with sqlite_server.Db('/www/server/bt-monitor/data/monitor_databases/availability_ping_info') as db:
        s_time = time.time()
        print('|-正在整理数据库/www/server/bt-monitor/data/monitor_databases/availability_ping_info.db >> ', end='')
        max_id = db.query().name('availability_ping_info')\
            .where('uid > 0')\
            .where('create_time > ?', cur_time - (3 * 86400))\
            .value('id')
        db.query()\
            .name('availability_ping_info')\
            .where('id < ?', max_id)\
            .delete()
        db.vacuum()
        print('{}s'.format(round(time.time() - s_time)))

    # 删除自定义脚本结果 三天前的数据
    with sqlite_server.Db('/www/server/bt-monitor/data/monitor_databases/custom_script') as db:
        s_time = time.time()
        print('|-正在整理数据库/www/server/bt-monitor/data/monitor_databases/custom_script.db >> ', end='')
        max_id = db.query().name('custom_script_result')\
            .where('create_time > ?', cur_time - (3 * 86400))\
            .value('id')
        db.query()\
            .name('custom_script_result')\
            .where('id < ?', max_id)\
            .delete()
        db.vacuum()
        print('{}s'.format(round(time.time() - s_time)))



    os.system('./init.sh start')
    print('')

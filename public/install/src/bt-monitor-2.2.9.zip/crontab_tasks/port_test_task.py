#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, sys, time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from core.include.monitor_helpers import warning_obj

if __name__ == '__main__':
    s_time = time.time()
    print('--开始测试端口')
    # 测试端口
    warning_obj.test_ports()
    print('--端口测试完成 耗时：{}s'.format(time.time() - s_time))
#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, sys, time, glob, py7zr


base_dir = '/www/server/bt-monitor'

os.chdir(base_dir)
sys.path.insert(0, base_dir)

if __name__ == '__main__':
    # 获取当天的请求日志文件名称
    today_log = '{}.json'.format(time.strftime('%Y-%m-%d'))

    # 获取未归档的请求文件
    unarchived_request_logs = glob.glob('{}/logs/request/*.json'.format(base_dir))

    # 开始归档
    s_time = time.time()
    print('|--开始归档请求日志')
    for item in unarchived_request_logs:
        # 获取日志文件名
        filename = os.path.basename(item)

        # 跳过今日请求日志
        if filename == today_log:
            continue

        print('|--正在归档文件{}'.format(filename), end='')
        with py7zr.SevenZipFile('{}/logs/request/{}.7z'.format(base_dir, filename[:-5]), 'w') as archive:
            archive.write(item, filename)

        # 删除原文件
        os.remove(item)

        print(' >> 完成')

    print('|--请求日志归档完成 耗时：{}s'.format(time.time() - s_time))

    # 获取已归档的文件列表
    archived_logs = glob.glob('{}/logs/request/*.7z'.format(base_dir))

    # 当归档文件数量超过180份时，删除最早的归档文件，仅保留最新的180份
    remove_num = len(archived_logs) - 180

    if remove_num > 0:
        # 对文件列表进行排序
        sorted_archived_logs = sorted([int(os.path.basename(x)[:-3].replace('-', '')) for x in archived_logs])

        # 删除旧的归档文件
        for i in range(remove_num):
            s = str(sorted_archived_logs[i])
            archive_file = '{}/logs/request/{}-{}-{}.7z'.format(base_dir, s[:4], s[4:6], s[6:])

            if os.path.exists(archive_file):
                os.remove(archive_file)

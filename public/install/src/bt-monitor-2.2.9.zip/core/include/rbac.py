#coding: utf-8
'''
 +------------------------------------------------------------------------------
 * 基于角色的数据库方式验证类
 +------------------------------------------------------------------------------
 */
// 配置文件增加设置
// USER_AUTH_ON 是否需要认证
// USER_AUTH_TYPE 认证类型
// USER_AUTH_KEY 认证识别号
// REQUIRE_AUTH_MODULE  需要认证模块
// NOT_AUTH_MODULE 无需认证模块
// USER_AUTH_GATEWAY 认证网关
// RBAC_DB_DSN  数据库连接DSN
// RBAC_ROLE_TABLE 角色表名称
// RBAC_USER_TABLE 用户表名称
// RBAC_ACCESS_TABLE 权限表名称
// RBAC_NODE_TABLE 节点表名称
/*
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bt_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `sid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
# sid 服务器id

CREATE TABLE IF NOT EXISTS `bt_node` (
  `node_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;
# level： 1 菜单，2 模块，3 权限，4 服务器权限

CREATE TABLE IF NOT EXISTS `bt_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

*/
'''
import os, json, time
from core import session, g, public
from core.include import pyotp
from functools import reduce

def AccessIntersection(check_access,server_access):
    '''
        @name 权限交集校验列表
        @param check_access 需要校验的权限
        @param server_access 拥有的权限
        @return []
    '''
    check_access = [int(i) for i in check_access]
    server_access = [int(i) for i in server_access]
    query = set(check_access).intersection(set(server_access))
    if not query:  # 有权限
        return []
    return list(query)

def AccessDifference(check_access, server_access=None):
    '''
        @name 权限差值校验列表
        @param check_access 需要校验的权限
        @param server_access 拥有的权限
        @return boolean
    '''
    if isinstance(check_access, int):
       check_access = [check_access]

    if isinstance(check_access, str):
        if check_access.find(',') > -1:
            check_access = check_access.split(',')
        else:
            check_access = [check_access]

    if server_access is None:
        server_access = g.get('server_list', [])

    if isinstance(check_access, list): check_access = [int(i) for i in check_access]
    if isinstance(server_access, list): server_access = [int(i) for i in server_access]
    # if not set(check_access).difference(set(server_access)):  # 有权限
    #     return True

    if not set(check_access).intersection(set(server_access)):
        return False

    return True


class Rbac:
    USER_AUTH_ON = True         # 开关
    USER_AUTH_TYPE = 2          # 认证类型
    ADMIN_AUTH_KEY = 1          # 超级管理员标识
    USER_AUTH_KEY = 'uid'           # 认证识别号
    REQUIRE_AUTH_MODULE = []    # 需要认证模块列表
    NOT_AUTH_MODULE = []        # 无需认证模块
    REQUIRE_AUTH_ACTION = []    # 需要认证的敏感操作
    NOT_AUTH_ACTION = []        # 无需认证的操作
    RBAC_ROLE_TABLE = 'bt_role'     # 角色表
    RBAC_USER_TABLE = 'bt_users'    # 用户表
    RBAC_ACCESS_TABLE = 'bt_access' # 权限表
    RBAC_NODE_TABLE = 'bt_node'     # 节点表


    def __init__(self):
        '''
            @name 构造函数
        '''
        self.__EXCEPT_LIST = [
            'server/modify_ssh_info',
        ]
        self.__UPDATE_CONFIG_INTERVAL = 600  # 配置信息更新间隔/秒
        self.__LAST_UPDATE_TIME = 0
        self.read_config()


    def read_config(self):
        '''
            @name 读取配置文件
        '''
        cur_time = int(time.time())
        if self.__LAST_UPDATE_TIME > cur_time - self.__UPDATE_CONFIG_INTERVAL:
            return

        self.__LAST_UPDATE_TIME = cur_time

        # 初始化配置信息
        rbac_config = public.read_config('rbac')
        self.USER_AUTH_ON = rbac_config['USER_AUTH_ON']
        self.USER_AUTH_TYPE = rbac_config['USER_AUTH_TYPE']
        self.ADMIN_AUTH_KEY = rbac_config['ADMIN_AUTH_KEY']
        self.USER_AUTH_KEY = rbac_config['USER_AUTH_KEY']
        self.REQUIRE_AUTH_MODULE = rbac_config['REQUIRE_AUTH_MODULE']
        self.NOT_AUTH_MODULE = rbac_config['NOT_AUTH_MODULE']
        self.REQUIRE_AUTH_ACTION = rbac_config['REQUIRE_AUTH_ACTION']
        self.NOT_AUTH_ACTION = rbac_config['NOT_AUTH_ACTION']
        self.RBAC_ROLE_TABLE = rbac_config['RBAC_ROLE_TABLE']
        self.RBAC_USER_TABLE = rbac_config['RBAC_USER_TABLE']
        self.RBAC_ACCESS_TABLE = rbac_config['RBAC_ACCESS_TABLE']
        self.RBAC_NODE_TABLE = rbac_config['RBAC_NODE_TABLE']


    def saveAccessList(self,authId=None):
        '''
            @name 保存权限列表
            @param authId 认证识别号
            @return boolean
        '''
        if not authId: authId = session.get('uid',0)
        if not authId: return False

        # 如果不是超级管理员，则需要获取当前用户的角色
        if self.USER_AUTH_TYPE != 2 and authId != self.ADMIN_AUTH_KEY:
            session['_ACCESS_LIST'] = self.getAccessList(authId)
        return True


    # def getRecordAccessList(self,authId = None,module = None):
    #     '''
    #         @name 取得模块的所属记录访问权限列表 返回有权限的记录ID数组
    #         @author hwliang
    #         @param authId 认证识别号
    #         @param module 模块名称
    #         @return array
    #     '''
    #     if not authId: authId = session.get('uid',0)
    #     if not authId: return False
    #
    #     if not module: module = g.get('module','')
    #     if not module: return False
    #
    #     accessList = self.getModuleAccessList(authId,module)
    #     return accessList


    def checkAccess(self):
        '''
            @name 检查当前操作是否需要认证
            @author hwliang
            @return bool
        '''
        if self.USER_AUTH_ON:
            _module = g.get('module','')
            _action = g.get('action','')
            if _module in self.NOT_AUTH_MODULE: # 无需认证的模块名?
                return False
            if _action in self.NOT_AUTH_ACTION: # 无需认证的操作名?
                return False
            return True
        return False

    def AccessDecision(self, args):
        '''
            @name 决定是否可以访问
            @author hwliang
            @param module 模块名称
            @return bool
        '''
        if self.USER_AUTH_TYPE == 2:
            self.read_config()

        # 检查认证过滤器
        if not self.checkAccess():
            return True

        _uid = session.get('uid', 0)
        if _uid == self.ADMIN_AUTH_KEY:  # 超级管理员？
            g.server_list = self.AdnminServerAccess()
            return True

        _module = g.get('module', '')
        _action = g.get('action', '')

        if self.USER_AUTH_TYPE == 2:
            #加强验证和即时验证模式 更加安全 后台权限修改可以即时生效
            #通过数据库进行访问检查
            role_id = self.getRoleId(session.get(self.USER_AUTH_KEY, 0))
            accessList = self.getAccessList(role_id)
            read_access, write_access, server_access = self.getServerList(role_id)
        else:
            accessList = []
            read_access, write_access, server_access = {}, {}, {}
        # return accessList

        # public.print_log(f"read_access:{read_access}")
        # public.print_log(f"write_access:{write_access}")
        # public.print_log(f"server_access:{server_access}")

        request_access = f"{_module}/{_action}"

        # public.print_log(f"request_access:{request_access}")

        # rbac 权限认证
        # 云监控全局权限
        if request_access in accessList:
            # public.print_log(f"全局权限:{request_access}")
            return True

        # 当前用户没有任何主机的读写权限
        if request_access not in reduce(lambda x, y: x+y, {**read_access, **write_access}.values(), []):
            return False

        _sid = args.get('sid', None)  # 服务器id
        permit_sid_list = []

        # 读
        if request_access in reduce(lambda x, y: x + y, read_access.values(), []):
            for k in read_access.keys():
                permit_sid_list.extend(server_access.get(k, []))
        # 写
        else:
            # 操作主机相关功能时必须携带sid
            if _sid is None:
                return False

            for k in write_access.keys():
                permit_sid_list.extend(server_access.get(k, []))

        permit_sid_list = list(set(permit_sid_list))

        # sid为None时
        # 获取当前用户允许访问的SID列表
        if _sid is None:
            _sid = ','.join(map(lambda x: str(x), permit_sid_list))

        # 服务器 sid 列表
        g.server_list = permit_sid_list

        # 权限校验
        return AccessDifference(_sid, permit_sid_list)

    def getRoleId(self, authId):
        '''
            @name 获取用户角色id
            @author hwliang
            @param authId 认证识别号
            @return role_id
        '''
        if not authId: return 0

        # 获取用户角色id
        db_obj = public.M('users')
        temp = db_obj.field("gid").where("uid=?",(authId)).find()

        if not temp: return 0
        role_id = temp["gid"]
        return role_id

    def getAccessList(self, role_id):
        '''
            @name 取得全局模块的所属记录访问权限列表
            @author hwliang
            @param authId 认证识别号
            @return list
        '''

        if not role_id: return {}
        # 获取模块
        sql = '''
            select node.node_id from
            {access_table} as access,
            {node_table} as node
            where
            access.role_id={role_id}
            and access.node_id=node.node_id
            and access.sid = 0
            and node.level=1
        '''.format(
        access_table=self.RBAC_ACCESS_TABLE,
        node_table=self.RBAC_NODE_TABLE,
        role_id=role_id)
        db_obj = public.M('')
        menu_list = db_obj.query(sql)

        access = []
        for menu in menu_list:
            menu_id = menu[0]

            # 获取模块
            sql = '''
                select node.node_id from
                {access_table} as access,
                {node_table} as node
                where
                access.role_id={role_id}
                and access.node_id=node.node_id
                and access.sid = 0
                and node.pid={node_id}
                and node.level=2
            '''.format(
            access_table=self.RBAC_ACCESS_TABLE,
            node_table=self.RBAC_NODE_TABLE,
            role_id=role_id,
            node_id=menu_id)
            db_obj = public.M('')
            module_list = db_obj.query(sql)


            for module in module_list:
                module_id = module[0]

                # 获取模块
                module_access = self.getModuleAccess(module_id)
                access.extend(module_access)

        # 获取公共模块
        sql = '''
            select node.node_id from
            {node_table} as node
            where
            node.name = "public"
            and node.pid=0
            and node.level=2
        '''.format(node_table=self.RBAC_NODE_TABLE)
        db_obj = public.M('')
        temp = db_obj.query(sql)
        # 获取模块
        module_access = self.getModuleAccess(temp[0][0])
        access.extend(module_access)
        return access

    def getServerList(self, role_id):
        '''
            @name 获取服务器权限，返回服务器权限
            @author hwliang
            @param authId 认证识别号
            @return
            read_access dict 只读 模块 id ： [权限,]
            write_access dict 写入 模块 id ： [权限,]
            read_server dict 只读 模块 id: [服务器id,]
            write_server dict 写入 模块 id: [服务器id,]
        '''
        if not role_id: return {}

        node_sql = public.M('node')

        # 模块 id ： [权限,]
        read_access = {}
        write_access = {}

        # 模块 id: [服务器id,]
        server_access = {}

        # 获取只读
        read_list = node_sql.field("node_id").where("level=4", ()).select()
        for access in read_list:
            node_id = access["node_id"]
            module_access = self.getModuleAccess(node_id)
            server_module_access = self.getRoleModuleAccess(role_id,node_id)
            read_access[node_id] = module_access
            server_access[node_id] = server_module_access

        # 获取写入
        write_list = node_sql.field("node_id").where("level=5", ()).select()
        for access in write_list:
            node_id = access["node_id"]
            module_access = self.getModuleAccess(node_id)
            server_module_access = self.getRoleModuleAccess(role_id, node_id)
            write_access[node_id] = module_access
            server_access[node_id] = server_module_access
        return read_access,write_access,server_access

    def getModuleAccess(self, moduleId):
        '''
            @name 获取模块下的权限
            @author hwliang
            @param authId 认证识别号
            @return list
        '''
        sql = '''select node.name from
            {node_table} as node
            where
            node.level=3
            and node.pid={moduleId}
        '''.format(
        node_table=self.RBAC_NODE_TABLE,
        moduleId=moduleId)
        db_obj = public.M('')
        module_access = db_obj.query(sql)

        access_list = []
        for access in module_access:
            access_list.append(access[0])
        return access_list

    def getRoleModuleAccess(self, roleId, moduleId):
        '''
            @name 获取模块下的服务器权限
            @author hwliang
            @param authId 认证识别号
            @return list
        '''
        sql = '''select access.sid from
            {access_table} as access
            where
            access.role_id={roleId}
            and access.node_id={moduleId}
            and access.sid != 0
        '''.format(
        access_table=self.RBAC_ACCESS_TABLE,
        roleId=roleId,
        moduleId=moduleId)
        db_obj = public.M('')
        role_module_access = db_obj.query(sql)
        server_list = []
        for access in role_module_access:
            if access[0] not in server_list:
                server_list.append(access[0])
        return server_list

    def AdnminServerAccess(self):
        '''
            @name 获取管理员服务器权限
            @author hwliang
            @param authId 认证识别号
            @return list
        '''
        server_list = public.M('server_list').field("sid").select()
        server_access = [i["sid"] for i in server_list]
        return server_access

    def AccessTwoStepAuth(self, args):
        '''
            @name 敏感操作二次动态口令认证
            @author hwliang
            @param module 模块名称
            @return bool
        '''
        path = '{}/config/two_step_auth.json'.format(public.get_panel_path())
        if not os.path.exists(path):
            return True

        two_auth_conf = json.loads(public.readFile(path))
        if two_auth_conf.get("open", False) == False:
            return True

        if self.USER_AUTH_TYPE == 2:
            self.read_config()

        _uid = session.get('uid', 0)
        # if _uid == self.ADMIN_AUTH_KEY:  # 超级管理员？
        #     return True

        _module = g.get('module', '')
        _action = g.get('action', '')
        request_access = f"{_module}/{_action}"

        # 敏感操作动态认证
        if request_access not in self.REQUIRE_AUTH_ACTION:
            return True

        # 缓存键名
        cache_key = "TWO_STEP_AUTH_" + str(_uid)
        cached_data = public.cache_get(cache_key)
        if cached_data == True:
            return True

        vcode = args.get("vcode", None)
        if vcode is None:
            return False

        otp = pyotp.TOTP(two_auth_conf["secret_key"])
        is_auth = otp.verify(vcode)
        if not is_auth:
            if public.sync_date(): is_auth = otp.verify(vcode)
        if not is_auth:
            return False

        public.cache_set(cache_key, True, 7200)
        return True

    # def getModuleAccessList(self,authId = None,module = None):
    #     '''
    #         @name 读取模块所属的记录访问权限
    #         @author hwliang
    #         @param authId 认证识别号
    #         @param module 模块名称
    #         @return list
    #     '''
    #
    #     db_obj = public.M('')
    #     sql = '''select node.node_id from
    #         {user_table} as user,
    #         {role_table} as role,
    #         {access_table} as access,
    #         {node_table} as node
    #         where
    #         user.uid={authId}
    #         and user.gid=role.role_id
    #         and user.gid=access.role_id
    #         and role.status=1
    #         and access.node_id=node.node_id
    #         and access.sid = 0
    #         and node.name='{module}'
    #         and node.level=2
    #         '''.format(
    #     role_table=self.RBAC_ROLE_TABLE,
    #     user_table=self.RBAC_USER_TABLE,
    #     access_table=self.RBAC_ACCESS_TABLE,
    #     node_table=self.RBAC_NODE_TABLE,
    #     authId=authId,
    #     module=module)
    #     module_id = db_obj.query(sql)
    #     if len(module_id) != 0:
    #         module_id = module_id[0][0]
    #     else:
    #         return []
    #
    #     # 获取模块
    #     node_sql = public.M('node')
    #     node_list = node_sql.field("node_id").where("pid=? AND level=3 AND status=1 AND display=1",(module_id)).select()
    #     return node_list







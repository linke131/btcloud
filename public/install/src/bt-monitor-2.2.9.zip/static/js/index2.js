import{_ as i}from"./server.js";import"./windi.js";import"./utils.js";import"./vue.js";import"./naive-ui.js";import"./index.vue_vue_type_script_setup_true_lang.js";export{i as default};

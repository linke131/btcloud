# coding: utf-8
# -------------------------------------------------------------------
# 宝塔Linux面板
# -------------------------------------------------------------------
# Copyright (c) 2014-2099 宝塔软件(http://bt.cn) All rights reserved.
# -------------------------------------------------------------------
# Author: wzz <wzz@bt.cn>
# -------------------------------------------------------------------

# 面板安全风险一键修复
# ------------------------------
import os, re, json, time, sys
from safeModel.base import safeBase

os.chdir("/www/server/panel")
sys.path.append("class/")
import public, config


class main(safeBase):
    __path = '/www/server/panel/data/warning'
    __risk = __path + '/risk'

    def __init__(self):
        self.configs = config.config()

    def set_security(self, get):
        '''
        自动修复对应的安全风险项
        @param get: 传 < dict_obj > 里面包含风险名列表 < list > m_name
        @return: 返回 dict_obj
        '''
        public.WriteFile(self.__path + '/repair_bar.txt', {"status": "准备修复", "percentage": 0})  # 修复进度条归零
        m_name_list = get.m_name
        list_length = len(m_name_list)  # 传过来的要修复的风险数量
        cve_list = [s for s in m_name_list if s.startswith('CVE')]
        m_name_list[:] = [s for s in m_name_list if not s.startswith('CVE')]
        is_autofix = public.read_config("safe_autofix")
        success = []
        failed = []
        cannot_automatically = []
        data = {
            "success": None,
            "failed": None,
            "cannot_automatically": None
        }
        risk_list = json.loads(public.ReadFile(self.__path + "/result.json"))["risk"]
        bar_num = 0  # 进度条
        if cve_list:
            for cve in cve_list:
                bar = ("%.2f" % (float(bar_num) / float(list_length) * 100))
                bar_text = {"status": "正在修复系统漏洞{}，耗时较久".format(cve), "percentage": bar}
                public.WriteFile(self.__path + '/repair_bar.txt', bar_text)
                bar_num += 1
                tmp = 0
                for risk in risk_list:
                    if cve == risk["cve_id"]:
                        tmp = 2
                        for soft in risk["soft_name"].keys():
                            if self.upgrade_soft(soft) == 1:
                                tmp = 1
                    if tmp == 1:
                        success.append({"result":{"status":True, "msg":"已修复{}".format(risk["cve_id"]), "type": ""}, "m_name":risk["vuln_name"]})
                        break
                    elif tmp == 2:
                        failed.append({"result":{"status":True, "msg":"已修复{}".format(risk["cve_id"]), "type": ""}, "m_name":risk["vuln_name"]})
                        break
        for m_name in m_name_list:
            bar = ("%.2f" % (float(bar_num) / float(list_length) * 100))
            bar_text = {"status": "正在修复{}".format(m_name), "percentage": bar}
            public.WriteFile(self.__path + '/repair_bar.txt', bar_text)
            bar_num += 1
            result = {"type": ""}
            risk_file = self.__risk + '/' + m_name + '.pl'
            # 检测是否真的是风险项
            if not os.path.exists(risk_file): continue
            if m_name not in is_autofix:
                cannot_automatically.append(m_name)
                continue
            for index, value in enumerate(is_autofix):
                if m_name == value:
                    func = getattr(self, value)
                    result = func()
            try:
                if "type" not in result.keys(): result["type"] = ""
                r_data = {
                    "result": result,
                    "m_name": m_name
                }
                if r_data["result"]["status"]:
                    success.append(r_data)
                    continue
                else:
                    failed.append(r_data)
                    continue
            except Exception as e:
                raise public.PanelError(e)

        data["success"] = success
        data["failed"] = failed
        data["cannot_automatically"] = cannot_automatically

        public.set_module_logs('panelWarning', 'set_security', 1)
        public.WriteFile(self.__path + '/repair_bar.txt',
                         json.dumps({"status": "修复完成", "percentage": "100"}))  # 修复进度100
        return data

    def sw_pip_poison(self):
        '''
        pypi供应链投毒检测
        @return:
        '''
        result = {"status": False, "msg": "pypi供应链投毒检测处理失败,请手动设置"}
        c_result = public.ExecShell(
            "piplist=`btpip freeze | grep -E "
            "\"istrib|djanga|easyinstall|junkeldat|libpeshka|mumpy|mybiubiubiu|nmap-python|openvc"
            "|python-ftp|pythonkafka|python-mongo|python-mysql|python-mysqldb|python-openssl"
            "|python-sqlite|virtualnv|mateplotlib|request=\"`;"
            "for pip in ${piplist[@]};do btpip uninstall ${pip} -y;done")
        if not c_result[1]:
            result["status"] = True
            result["msg"] = "pypi供应链投毒检测处理成功"
        return result

    def sw_docker_mod(self):
        '''
        Docker关键性文件权限检查
        @return:
        '''
        file_list = (
            "/usr/lib/systemd/system/docker.service",
            "/usr/lib/systemd/system/docker.socket",
            "/etc/docker"
        )
        result = {"status": False, "msg": "设置Docker关键性文件权限失败,请手动设置"}
        try:
            for file in file_list:
                if not os.path.exists(file):
                    continue
                if "service" in file or "socket" in file:
                    os.chmod(file, 0o644)
                    os.chown(file, 0, 0)
                else:
                    os.chmod(file, 0o755)
                    os.chown(file, 0, 0)
            result["status"] = True
            result["msg"] = "设置Docker关键性文件权限成功"
        except:
            pass
        return result

    def sw_ftp_root(self):
        '''
        禁止root用户登录FTP
        @return:
        '''
        result = {"status": False, "msg": "设置禁止root用户登录FTP失败,请手动设置"}
        file = "/www/server/pure-ftpd/etc/pure-ftpd.conf"
        f_data = public.readFile(file)
        MinUID = "\nMinUID\\s*([0-9]{1,4})"
        file_result = re.sub(MinUID, "\nMinUID                       100", f_data)
        public.writeFile(file, file_result)
        f_data = public.readFile(file)
        if f_data.find("MinUID                       100"):
            result["status"] = True
            result["msg"] = "设置禁止root用户登录FTP成功"
        return result

    def sw_chmod_stickybit(self):
        '''
        检查临时目录是否有粘滞位
        @return:
        '''
        tmp_path = ('/var/tmp', '/tmp')
        result = {"status": False, "msg": "取消临时目录粘滞位失败,请手动设置"}
        # try:
        for file in tmp_path:
            if not os.path.exists(file):
                continue
            c_result = public.ExecShell("chmod -t {}".format(file))
            print(c_result)
            if c_result[1]: return result
        result["status"] = True
        result["msg"] = "取消临时目录粘滞位成功"
        # except:
        #     pass
        return result

    def sw_telnet_server(self):
        '''
        关闭非加密远程管理telnet
        @return:
        '''
        result = {"status": False, "msg": "取消临时目录粘滞位失败,请手动设置"}
        c_result = public.ExecShell('systemctl disable telnet.socket')
        if not c_result[1]:
            result["status"] = True
            result["msg"] = "取消临时目录粘滞位成功"
        return result

    def sw_strace_backdoor(self):
        '''
        strace获取登录凭证后门检测
        @return:
        '''
        result = {"status": False, "msg": "停止strace进程失败,请手动设置"}
        import psutil
        process_name = "strace"
        all_processes = psutil.process_iter()
        for process in all_processes:
            try:
                if process.name() == process_name:
                    process.terminate()
                    result["status"] = True
                    result["msg"] = "停止strace成功"
                    break
            except:
                pass
        return result

    def sw_mongodb_auth(self):
        import subprocess
        '''
        MongoDB是否开启安全认证
        @return:
        '''
        result = {"status": False, "msg": "MongoDB开启安全认证失败,请手动设置"}
        try:
            __conf_path = '{}/mongodb/config.conf'.format(public.get_setup_path())
            conf = public.readFile(__conf_path)
            conf = re.sub('authorization\s*\:\s*disabled','authorization: enabled',conf)
            public.writeFile(__conf_path,conf)
            subprocess.Popen(["/etc/init.d/mongodb", "restart"])
            # public.ExecShell('/etc/init.d/mongodb restart')
            result["status"] = True
            result["msg"] = "MongoDB开启安全认证成功"
        except:
            pass
        return result

    def sw_system_user(self):
        '''
        系统后门用户检测
        @return:
        '''
        result = {"status": False, "msg": "系统后门用户删除失败,请手动设置"}
        cfile = '/etc/passwd'
        if os.path.exists(cfile):
            f = open(cfile, 'r')
            for i in f:
                i = i.strip().split(":")
                if i[2] == '0' and i[3] == '0':
                    if i[0] == 'root': continue
                    c_result = public.ExecShell("userdel -f {}".format(i[0]))
                    if not c_result[1]:
                        result["status"] = True
                        result["msg"] = "系统后门用户成功"
        return result

    def sw_debug_mode(self):
        '''
        开发者模式检测
        @return:
        '''
        get = public.dict_obj()
        result = self.configs.set_debug(get)
        if result["status"]: result["msg"] = "已禁用开发者模式"
        return result

    def sw_time_out(self):
        '''
        检查是否设置命令行界面超时退出
        @return:
        '''
        result = {"status": False, "msg": "设置命令行界面超时退出失败,请手动设置"}
        filename = "/etc/profile"
        w_result = public.ExecShell("echo \"tmout=600\" >> {}".format(filename))
        if not w_result[1]:
            result["status"] = True
            result["msg"] = "已设置命令行界面超时为600秒退出"
        return result

    def sw_chmod_sid(self):
        '''
        检查拥有suid和sgid权限的文件
        @return:
        '''
        result = {"status": True, "msg": "设置suid和sgid权限成功"}
        file_list = ['/usr/bin/chage', '/usr/bin/gpasswd', '/usr/bin/wall', '/usr/bin/chfn',
                     '/usr/bin/chsh', '/usr/bin/newgrp',
                     '/usr/bin/write', '/usr/sbin/usernetctl', '/bin/mount', '/bin/umount',
                     '/bin/ping', '/sbin/netreport']
        s_successes_list = []
        g_successes_list = []
        s_failed_list = []
        g_failed_list = []
        try:
            for file in file_list:
                if not os.path.exists(file):
                    continue
                s_result = public.ExecShell("chmod u-s {}".format(file))
                g_result = public.ExecShell("chmod g-s {}".format(file))
                s_successes_list.append(file) if not s_result[1] else s_failed_list.append(file)
                g_successes_list.append(file) if not g_result[1] else g_failed_list.append(file)
        except:
            pass

        data = [{
            "successes": {
                "suid_success": len(s_successes_list),
                "sgid_success": len(g_successes_list)
            },
            "set_suid": s_successes_list,
            "set_sgid": g_successes_list
        }, {
            "failed": {
                "suid_failed": len(s_failed_list),
                "sgid_failed": len(g_failed_list)
            },
            "set_suid": s_failed_list,
            "set_sgid": g_failed_list
        }]
        # result["type"] = data
        return result

    def sw_ftp_umask(self):
        '''
        用户FTP访问安全配置
        @return:
        '''
        result = {"status": False, "msg": "设置用户FTP访问安全配置失败,请手动设置"}
        file = "/www/server/pure-ftpd/etc/pure-ftpd.conf"
        f_data = public.readFile(file)
        Umask = "\nUmask\s+.*"
        file_result = re.sub(Umask, "\nUmask                       177:077", f_data)
        public.writeFile(file, file_result)
        f_data = public.readFile(file)
        if f_data.find("177:077"):
            result["status"] = True
            result["msg"] = "用户FTP访问安全配置成功"
        return result

    def sw_ssh_v2(self):
        '''
        是否使用加密的远程管理ssh
        @return:
        '''
        result = {"status": False, "msg": "设置加密的远程管理ssh失败,请手动设置"}
        file = "/etc/ssh/sshd_config"
        f_data = public.readFile(file)
        try:
            if f_data.find("Protocol") != -1:
                Protocol = "\nProtocol\s+."
                file_result = re.sub(Protocol, "\nProtocol 2", f_data)
                public.writeFile(file, file_result)
            else:
                public.ExecShell("echo '\nProtocol 2' >> {}".format(file))
        except:
            pass
        f_data = public.readFile(file)
        if f_data.find("Protocol 2"):
            c_result = public.ExecShell("systemctl restart sshd")
            if not c_result[1]:
                result["status"] = True
                result["msg"] = "设置加密的远程管理ssh成功"
        return result

    def sw_bootloader_mod(self):
        '''
        bootloader配置权限
        @return:
        '''
        files = ["/boot/grub/grub.cfg", "/boot/grub2/grub.cfg"]
        result = {"status": False, "msg": "设置bootloader权限失败,请手动设置"}
        try:
            for file in files:
                if os.path.exists(file):
                    os.chmod(file, 0o600)
                    os.chown(file, 0, 0)
                    result["status"] = True
                    result["msg"] = "设置bootloader权限成功"
        except:
            pass
        return result

    def sw_alias_ls_rm(self):
        '''
        检查别名配置
        @return:
        '''
        result = {"status": False, "msg": "设置安全别名失败,请手动设置"}
        file = "/root/.bashrc"
        ls_result = public.ExecShell("echo \"alias ls='ls -alh'\" >> {}".format(file))
        rm_result = public.ExecShell("echo \"alias rm='rm -i'\" >> {}".format(file))
        if not ls_result[1] and not rm_result[1]:
            result["status"] = True
            result["msg"] = "设置安全别名成功"
        return result

    def sw_tcp_syn_cookie(self):
        '''
        TCP-SYNcookie保护检测
        @return:
        '''
        result = {"status": False, "msg": "设置TCP-SYNcookie保护失败,请手动设置"}
        file = "/etc/sysctl.conf"
        public.ExecShell("sed -i \"/net.ipv4.tcp_syncookies/d\" {}".format(file))
        e_result = public.ExecShell("echo \"net.ipv4.tcp_syncookies=1\" >> {}".format(file))
        public.ExecShell("sysctl -p")
        if not e_result[1]:
            result["status"] = True
            result["msg"] = "设置TCP-SYNcookie保护成功"
        return result

    def sw_ping(self):
        '''
        设置禁ping
        @return:
        '''
        import firewall_new
        firewalls = firewall_new.firewalls()
        get = public.dict_obj()
        get["status"] = 0
        result = firewalls.SetPing(get)
        if result["status"]: result["msg"] = "已开启禁ping"
        return result

    def sw_panel_swing(self):
        '''
        设置面板告警
        @return:
        '''
        keys_list = ("mail", "dingding", "feishu", "weixin", "wx_account", "sms")
        get = public.dict_obj()
        result = {}
        for key in keys_list:
            get["type"] = str(key)
            result = self.configs.set_login_send(get)
            if not result["status"]: continue
            result["type"] = key
            break
        return result

    def sw_ssh_passmin(self):
        '''
        设置SSH密码修改最小时间间隔
        @return:
        '''
        file = "/etc/login.defs"
        result = {"status": False, "msg": "SSH密码修改最小间隔时间设置失败,请手动设置"}
        f_data = public.readFile(file)
        ssh_pass_min_days = "\nPASS_MIN_DAYS.+\d+"
        file_result = re.sub(ssh_pass_min_days, "\nPASS_MIN_DAYS	7", f_data)
        public.writeFile(file, file_result)
        public.ExecShell("chage --mindays 7 root")
        f_data = public.readFile(file)
        if f_data.find("PASS_MIN_DAYS	7") != -1:
            result["status"] = True
            result["msg"] = "已设置SSH密码修改最小间隔时间为7天"
        return result

    def sw_ssh_passmax(self):
        '''
        设置SSH密码过期时间
        @return:
        '''
        file = "/etc/login.defs"
        result = {"status": False, "msg": "SSH密码过期时间设置失败,请手动设置"}
        f_data = public.readFile(file)
        ssh_pass_max_days = "\nPASS_MAX_DAYS.+\d+"
        file_result = re.sub(ssh_pass_max_days, "\nPASS_MAX_DAYS	180", f_data)
        public.writeFile(file, file_result)
        public.ExecShell("chage --maxdays 180 root")
        f_data = public.readFile(file)
        if f_data.find("PASS_MAX_DAYS	180") != -1:
            result["status"] = True
            result["msg"] = "已设置SSH密码过期时间为180天"
        return result

    def sw_ssh_passwarn(self):
        '''
        SSH密码过期提前警告天数
        @return:
        '''
        file = "/etc/login.defs"
        result = {"status": False, "msg": "SSH密码过期提前警告天数设置失败,请手动设置"}
        f_data = public.readFile(file)
        ssh_pass_war_age = "\nPASS_WARN_AGE.+\d+"
        file_result = re.sub(ssh_pass_war_age, "\nPASS_WARN_AGE 7", f_data)
        public.writeFile(file, file_result)
        cmd_result = public.ExecShell("chage --warndays 7 root")
        if cmd_result[1] != "": return result
        f_data = public.readFile(file)
        if f_data.find("PASS_WARN_AGE 7") != -1:
            result["status"] = True
            result["msg"] = "已设置SSH密码过期提前警告天数为7天"
        return result

    def sw_ssh_security(self):
        '''
        SSH密码最小长度设置
        @return:
        '''
        file = "/etc/security/pwquality.conf"
        result = {"status": False, "msg": "SSH密码最小长度设置失败,请手动设置"}
        if not os.path.exists(file): public.ExecShell("apt install libpam-pwquality -y")
        if os.path.exists(file):
            f_data = public.readFile(file)
            ssh_minlen = "\n#?\s*minlen\s*=\s*\d*"
            file_result = re.sub(ssh_minlen, "\nminlen = 9", f_data)
            public.writeFile(file, file_result)
            f_data = public.readFile(file)
            if f_data.find("minlen = 9") != -1:
                result["status"] = True
                result["msg"] = "已设置SSH密码最小长度为9"
        return result

    def sw_ssh_clientalive(self):
        '''
        设置SSH空闲超时时间
        @return:
        '''
        import ssh_security
        ssh_security = ssh_security.ssh_security()
        file = "/etc/ssh/sshd_config"
        result = {"status": False, "msg": "SSH空闲超时时间设置失败,请手动设置"}
        f_data = public.readFile(file)
        ssh_ClientAliveInterval = "\n#?ClientAliveInterval\s+\d+"
        file_result = re.sub(ssh_ClientAliveInterval, "\nClientAliveInterval 900", f_data)
        public.writeFile(file, file_result)
        ssh_security.restart_ssh()
        f_data = public.readFile(file)
        if f_data.find("ClientAliveInterval 900") != -1:
            result["status"] = True
            result["msg"] = "已设置SSH空闲超时时间为900秒"
        return result

    def sw_ssh_maxauth(self):
        '''
        设置SSH最大连接数
        @return:
        '''
        import ssh_security
        ssh_security = ssh_security.ssh_security()
        file = "/etc/ssh/sshd_config"
        result = {"status": False, "msg": "设置SSH最大连接数失败,请手动设置"}
        f_data = public.readFile(file)
        ssh_MaxAuthTries = "\n#?MaxAuthTries\s+\d+"
        file_result = re.sub(ssh_MaxAuthTries, "\nMaxAuthTries 5", f_data)
        public.writeFile(file, file_result)
        ssh_security.restart_ssh()
        f_data = public.readFile(file)
        if f_data.find("MaxAuthTries 5") != -1:
            result["status"] = True
            result["msg"] = "已设置SSH最大连接数为5"
        return result

    def sw_ssh_notpass(self):
        '''
        禁止SSH空密码登录
        @return:
        '''
        import ssh_security
        ssh_security = ssh_security.ssh_security()
        file = "/etc/ssh/sshd_config"
        result = {"status": False, "msg": "SSH禁止空密码登录设置失败,请手动设置"}
        f_data = public.readFile(file)
        ssh_PermitEmptyPasswords = "\n#?PermitEmptyPasswords\s+yes"
        file_result = re.sub(ssh_PermitEmptyPasswords, "\nPermitEmptyPasswords no", f_data)
        public.writeFile(file, file_result)
        ssh_security.restart_ssh()
        f_data = public.readFile(file)
        if f_data.find("PermitEmptyPasswords no") != -1:
            result["status"] = True
            result["msg"] = "SSH禁止空密码登录成功"
        return result

    def sw_panel_control(self):
        '''
        开启面板监控
        @return:
        '''
        get = public.dict_obj()
        get["type"] = "1"
        get["day"] = "30"
        result = {"status": False, "msg": "面板监控开启失败,请手动设置"}
        r_data = self.configs.SetControl(get)
        if r_data["status"]:
            result["status"] = True
            result["msg"] = "面板监控开启成功"
            result["type"] = get["day"]
        return result

    def sw_cve_2021_4034(self):
        '''
        修复CVE-2021-4034 polkit pkexec 本地提权漏洞
        @return:
        '''
        result = {"status": False, "msg": "polkit_pkexec本地提权漏洞修复失败,请手动修复"}
        py_path = "/www/server/panel/pyenv/bin/python3"
        script_path = "/www/server/panel/script/polkit_upgrade.py"
        if os.path.exists(script_path):
            c_result = public.ExecShell("{} {}".format(py_path, script_path))
            if c_result[1] == "":
                result["status"] = True
                result["msg"] = "polkit_pkexec本地提权漏洞修复成功"
        return result

    def sw_php_expose(self):
        '''
        关闭php版本泄露配置
        @return:
        '''
        path = "/www/server/php"
        dirs = os.listdir(path)
        result = {"status": True, "msg": "关闭php版本显示成功", "type": []}
        for dir in dirs:
            if dir in (
                    "52", "53", "54", "55", "56", "70", "71", "72", "73", "74", "80", "81", "82"):
                file_path = path + "/" + dir + "/etc/php.ini"
                if os.path.exists(file_path):
                    php_ini = public.readFile(file_path)
                    r_str = "\nexpose_php\\s*=\\s*(\\w+)"
                    r_result = re.sub(r_str, "\nexpose_php = off", php_ini)
                    public.writeFile(file_path, r_result)
                    f_data = public.readFile(file_path)
                    if f_data.find("expose_php = off") != -1:
                        public.phpReload(str(dir))
                        result["type"].append(dir)
        if len(result["type"]) < 1:
            result["status"] = False
            result["msg"] = "关闭php版本显示失败或无需要关闭的php版本,请手动设置"
        return result

    def sw_files_recycle_bin(self):
        get = public.dict_obj()
        import files
        files = files.files()
        os.system("rm -rf /www/server/panel/data/recycle_bin.pl")
        if not os.path.exists('/www/server/panel/data/recycle_bin.pl'):
            return files.Recycle_bin(get)

    def sw_kernel_space(self):
        result = {"status": False, "msg": "开启地址空间布局随机化失败,请手动设置"}
        file = "/proc/sys/kernel/randomize_va_space"
        if os.path.exists(file):
            c_result = public.ExecShell("echo 2 > {}".format(file))
            if c_result[1] == "":
                result["status"] = True
                result["msg"] = "已开启地址空间布局随机化"
        return result

    def sw_httpd_version_leak(self):
        '''
        Apache 版本泄露
        @return:
        '''
        result = {"status": False, "msg": "Apache 版本泄露修复失败,请手动设置"}
        conf = "/www/server/apache/conf/httpd.conf"
        if os.path.exists(conf):
            try:
                info_data = public.ReadFile(conf)
                if info_data:
                    if not re.search('ServerSignature', info_data) and not re.search(
                            'ServerTokens', info_data):
                        result["status"] = True
                        result["msg"] = "Apache 版本泄露修复成功"
                        return result
                    ServerSignature = "\n\s*ServerSignature\s*on\s*;"
                    ServerTokens = "\n\s*ServerTokens\s*.\s*;"
                    file_result1 = re.sub(ServerSignature, "\nServerSignature Off", info_data)
                    file_result2 = re.sub(ServerTokens, "\nServerTokens Prod", file_result1)
                    public.writeFile(conf, file_result2)
                    if re.search('ServerSignature Off', info_data) and re.search(
                            'ServerTokens Prod', info_data):
                        result["status"] = True
                        result["msg"] = "Apache 版本泄露修复成功"
                        return result
            except:
                return result
        return result

    def sw_nginx_server(self):
        '''
        关闭Nginx版本显示
        @return:
        '''
        file = "/www/server/nginx/conf/nginx.conf"
        result = {"status": False, "msg": "关闭nginx版本显示失败,请手动设置"}
        if os.path.exists(file):
            f_data = public.readFile(file)
            nginx_server_tokens = "\n\s*server_tokens\s*on\s*;"
            file_result = re.sub(nginx_server_tokens, "\n        server_tokens off;", f_data)
            public.writeFile(file, file_result)
            f_data = public.readFile(file)
            public.ServiceReload()
            if f_data.find("        server_tokens off;") != -1:
                result["status"] = True
                result["msg"] = "关闭nginx版本显示成功"
        return result

    def sw_site_spath(self):
        '''
        开启指定网站防跨站攻击
        @return:
        '''

        def SetUserINI():
            result = {"status": True, "msg": "指定网站防跨站攻击开启成功", "type": []}
            import panelSite
            get = public.dict_obj()
            panelSite = panelSite.panelSite()
            site_list = public.M('sites').where('status=? AND project_type=?', (1, 'PHP')).field(
                'name,path,id').select()
            for s in site_list:
                path = get_site_run_path(s['name'], s['path'])
                get["path"] = s['path']
                get["id"] = s["id"]
                filename = path + '/.user.ini'
                if os.path.exists(filename): continue
                u_result = panelSite.SetDirUserINI(get)
                if not u_result["status"]:
                    result["status"] = False
                    result["msg"] = "指定网站防跨站攻击开启失败,请手动设置"
                    return result
                if u_result["status"]:
                    result["type"].append(s['name'])
            if len(result["type"]) < 1:
                result["status"] = False
                result["msg"] = "指定网站防跨站攻击开启失败,请手动设置"
            return result

        def get_site_run_path(siteName, sitePath):
            '''
                @name 获取网站运行目录
                @author hwliang<2020-08-05>
                @param siteName(string) 网站名称
                @param sitePath(string) 网站根目录
                @return string
            '''
            setupPath = '/www/server'
            webserver_type = public.get_webserver()
            path = None
            if webserver_type == 'nginx':
                filename = setupPath + '/panel/vhost/nginx/' + siteName + '.conf'
                if os.path.exists(filename):
                    conf = public.readFile(filename)
                    rep = r'\s*root\s+(.+);'
                    tmp1 = re.search(rep, conf)
                    if tmp1: path = tmp1.groups()[0]

            elif webserver_type == 'apache':
                filename = setupPath + '/panel/vhost/apache/' + siteName + '.conf'
                if os.path.exists(filename):
                    conf = public.readFile(filename)
                    rep = r'\s*DocumentRoot\s*"(.+)"\s*\n'
                    tmp1 = re.search(rep, conf)
                    if tmp1: path = tmp1.groups()[0]
            else:
                filename = setupPath + '/panel/vhost/openlitespeed/' + siteName + '.conf'
                if os.path.exists(filename):
                    conf = public.readFile(filename)
                    rep = r"vhRoot\s*(.*)"
                    path = re.search(rep, conf)
                    if not path:
                        path = None
                    else:
                        path = path.groups()[0]

            if not path:
                path = sitePath

            return path

        return SetUserINI()

    # 取系统版本
    def get_sys_version(self):
        '''
        获取当前系统版本
        :return: string
        '''
        sys_version = "None"
        if os.path.exists("/etc/redhat-release"):
            result = public.ReadFile("/etc/redhat-release")
            if "CentOS Linux release 7" in result:
                sys_version = "centos_7"
            elif "CentOS Linux release 8" in result or "CentOS Stream release 8" in result:
                sys_version = "centos_8"
        elif os.path.exists("/etc/debian_version"):
            result = public.ReadFile("/etc/debian_version")
            if "10." in result:
                sys_version = "debian_10"
            elif "11." in result:
                sys_version = "debian_11"
        elif os.path.exists("/etc/issue"):
            if "Ubuntu 20.04" in public.ReadFile("/etc/issue"):
                sys_version = "ubuntu_20.04"
            elif "Ubuntu 22.04" in public.ReadFile("/etc/issue"):
                sys_version = "ubuntu_22.04"
            elif "Ubuntu 18.04" in public.ReadFile("/etc/issue"):
                sys_version = "ubuntu_18.04"
        return sys_version

    def upgrade_soft(self, soft):
        '''
        升级软件包
        :param soft: 软件包名
        :return: int 2为升级失败，1为成功
        '''
        error_message = ['Couldn\'t find', 'Error', 'Nothing to do', 'already the newest']
        sys_version = self.get_sys_version()
        if "centos" in sys_version:
            # public.ExecShell('yum update -y '+soft+' > '+self.__path+'/log.txt 2>&1')
            public.ExecShell('yum update -y {} 2>&1 |tee -a {}/log.txt'.format(soft, self.__path))
            # subprocess.check_output(['yum', 'update', '-y', soft])
        elif "ubuntu" in sys_version:
            # public.ExecShell('apt install -y '+soft+' > '+self.__path+'/log.txt 2>&1')
            public.ExecShell('apt install -y {} 2>&1 |tee -a {}/log.txt'.format(soft, self.__path))
        elif "debian" in sys_version:
            public.ExecShell('apt install -y {} 2>&1 |tee -a {}/log.txt'.format(soft, self.__path))
        result = public.ReadFile(self.__path + '/log.txt')
        for error in error_message:
            if error in result:
                return 2
        return 1

    def get_repair_bar(self, get):
        '''
        获取修复进度条
        @param get:
        @return: int
        '''
        if not os.path.exists(self.__path + '/repair_bar.txt'):return 0
        data3 = public.ReadFile(self.__path + '/repair_bar.txt')
        if isinstance(data3, str):
            data3 = data3.strip()
            try:
                data = json.loads(data3)
                data["percentage"] = int(data["percentage"])
            except:
                data = 0
            return data
        return 0

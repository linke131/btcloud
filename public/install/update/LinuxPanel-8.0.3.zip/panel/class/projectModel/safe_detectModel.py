# coding: utf-8
# -------------------------------------------------------------------
# 宝塔Linux面板
# -------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# -------------------------------------------------------------------
# Author: lkq <lkq@bt.cn>
# -------------------------------------------------------------------

# ------------------------------
# 安全检测模型
# ------------------------------

import os, sys, re, json, shutil, psutil, time
from projectModel.base import projectBase
import public, firewalls

try:
    from BTPanel import cache
except:
    pass


class mobj:
    port = ps = ''


class main(projectBase):
    _PLUGIN_PATH = "/www/server/panel/config"
    _LIST_FILE = _PLUGIN_PATH + '/scan_webshell_list.json'
    _WHITE_LIST_FILE = _PLUGIN_PATH + '/white_webshell_list.json'
    _WEBSHELl_BACK = "/www/server/panel/data/bt_security/webshell"

    _WEBSHELl_PATH = '/www/server/panel/data/bt_security/logs'
    _total = "/www/server/panel/data/bt_security/logs/total.json"

    def __init__(self):
        if not os.path.exists(self._WEBSHELl_PATH):
            os.makedirs(self._WEBSHELl_PATH, True)
        if not os.path.exists(self._total):
            public.WriteFile(self._total, '{"total":0}')

    def __check_auth(self):
        from pluginAuth import Plugin
        plugin_obj = Plugin(False)
        plugin_list = plugin_obj.get_plugin_list()
        return int(plugin_list['ltd']) > time.time()

    def check_auth(self,get):
        return self.__check_auth()

    # 已处理的文件
    def set_handle_file(self, get):
        '''
        @name 已处理的文件
        @param md5 md5值
        @param path文件路径
        @param type
        '''

        if not 'type' in get: get.type = "remove"

        path = self._WEBSHELl_PATH + "/check.json"
        if not os.path.exists(path):
            return []
        f = open(path, 'r')
        ret = ''
        flag = False
        for i in f:
            try:
                data = json.loads(i)
                if data['md5'] == get.md5 and data['path'] == get.path:
                    flag = True
                    continue
                ret += i
            except:
                continue
        if flag:
            public.WriteFile(path, ret)

        if flag and get.type == "delete":
            if os.path.exists(get.path):
                os.remove(get.path)

        if os.path.exists(self._WEBSHELl_BACK + "/" + get.md5 + ".txt"):
            os.remove(self._WEBSHELl_BACK + "/" + get.md5 + ".txt")
        total = json.loads(public.ReadFile(self._total))
        total["total"] -= 1
        if total["total"] <= 0:
            total["total"] = 0
        public.WriteFile(self._total, json.dumps(total))
        return public.returnMsg(True, '已移除该文件')

    # 文件漏洞扫描
    def get_scan(self, get):
        '''
            @name 漏洞扫描
            @author lkq@bt.cn
            @time 2022-08-20
            @param 无
            @return 返回内容
        '''
        # from projectModel import scanningModel
        # scanningobj = scanningModel.main()
        import PluginLoader
        return PluginLoader.module_run('scanning','startScan',get)
        # if hasattr(scanningobj, 'startScan'):
        #     return scanningobj.startScan(get)
        # else:
        #     return {"info": [], "time": int(time.time()), "is_pay": True}

    def get_service_status(self, get=None):
        '''
            @name 获取服务状态
            @author lkq@bt.cn
            time:2022-08-20
            @return bool
        '''

        if public.ExecShell("ps aux |grep bt_check_shell|grep -v grep")[0]:
            return public.returnMsg(True, '')
        return public.returnMsg(False, '')

    def get_service_status2(self, get=None):
        '''
            @name 获取服务状态
            @author lkq@bt.cn
            time:2022-08-20
            @return bool
        '''

        if public.ExecShell("ps aux |grep bt_check_shell|grep -v grep")[0]:
            return True
        return False

    def start_service(self, get):
        '''
            @name 启动服务
            @author lkq@bt.cn
            time:2022-08-20
            @return dict
        '''
        if self.get_service_status2(): return public.returnMsg(False, '服务已启动!')
        self.wrtie_init()
        shell_info='''#!/www/server/panel/pyenv/bin/python
#coding: utf-8
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: hwliang<hwl@bt.cn>
#-------------------------------------------------------------------
import os,sys
os.chdir('/www/server/panel')
sys.path.insert(0,'class/')
from cachelib import SimpleCache
import pyinotify,public,json,time


class MyEventHandler(pyinotify.ProcessEvent):
    _PLUGIN_PATH = "/www/server/panel/config"
    _LIST_FILE = _PLUGIN_PATH + '/scan_webshell_list.json'
    _WHITE_LIST_FILE=_PLUGIN_PATH+'/white_webshell_list.json'
    _WEBSHELl_PATH ='/www/server/panel/data/bt_security/logs'
    _WEBSHELl_BACK="/www/server/panel/data/bt_security/webshell"
    _total="/www/server/panel/data/bt_security/logs/total.json"
    __cache = None

    __count=0
    def __init__(self):
        if not self.__cache:
            self.__cache = SimpleCache(5000)
        if not os.path.exists(self._WEBSHELl_BACK):
            os.makedirs(self._WEBSHELl_BACK)
        if not os.path.exists(self._WEBSHELl_PATH):
            os.makedirs(self._WEBSHELl_PATH)
        if not os.path.exists(self._total):
            public.WriteFile(self._total,'{"total":0}')


    def get_white_config(self):
        if not os.path.exists(self._WHITE_LIST_FILE): return {"dir":[],"file":[]}
        try:
            config=json.loads(public.ReadFile(self._WHITE_LIST_FILE))
            return config
        except:
            return []

    def check(self,filename):
        try:
            print("check")
            info=public.ReadFile(filename)
            md5=public.md5(info)
            if self.__cache.get(md5):
                return False
            #判断md5文件是否存在
            if os.path.exists(self._WEBSHELl_BACK+"/"+md5+".txt"):return False
            import webshell_check
            webshell = webshell_check.webshell_check()
            res = webshell.upload_file_url2(filename, "http://w-check.bt.cn/check.php")
            print(res)
            self.__cache.set(md5, True, 360)
            if not res:return False
            public.WriteFile(self._WEBSHELl_BACK+"/"+md5+".txt",info)
            ret={}
            ret["path"]=filename
            ret["md5"]=md5
            ret["time"]=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
            ret["md5_file"]=md5+".txt"
            logs_path=self._WEBSHELl_PATH+"/check.json"
            public.WriteFile(logs_path, json.dumps(ret)+ "\\n", "a+")
            try:
                total=json.loads(public.ReadFile(self._total))
                total["total"]+=1
                public.WriteFile(self._total,json.dumps(total))
            except:
                public.WriteFile(self._total, '{"total":0}')
        except:return False

    def process_IN_MODIFY(self, event):
        if type(event.pathname)==str and event.pathname.endswith("php"):
            if self.__cache.get(event.pathname): return False
            self.__cache.set(event.pathname, True, 2)
            if self.__cache.get("white_config"):
                white_config=self.__cache.get("white_config")
            else:
                white_config=self.get_white_config()
                self.__cache.set("white_config", white_config, 60)
            print(event.pathname)
            if len(white_config)>=1:
                if len(white_config['dir'])>0:
                    for i in white_config['dir']:
                        if event.pathname.startswith(i):
                            print("白名单目录")
                            return True
                if len(white_config['file'])>0:

                    if event.pathname in white_config['file']:
                        print("白名单文件")
                        return True
            public.run_thread(self.check,args=(event.pathname,))
            return True

def run():
    watchManager = pyinotify.WatchManager()
    event = MyEventHandler()
    mode = pyinotify.IN_MODIFY
    _list = {}
    try:
        _list = json.loads(public.readFile(event._LIST_FILE))
    except:
        _list={}
    for path_info in _list:
        if not path_info['open']: continue
        try:
            watchManager.add_watch(path_info['path'], mode ,auto_add=True, rec=True)
        except:
            continue
    notifier = pyinotify.Notifier(watchManager, event)
    notifier.loop()

if __name__ == '__main__':
    run()
        '''
        init_file = '/etc/init.d/bt_check_shell'
        public.WriteFile('/www/server/panel/class/projectModel/bt_check_shell', shell_info)
        time.sleep(0.3)
        public.ExecShell("{} start".format(init_file))
        if self.get_service_status2():
            # public.WriteLog('文件监控','启动服务')
            return public.returnMsg(True, '启动成功!')
        return public.returnMsg(False, '启动失败!')

    def stop_service(self, get):
        '''
            @name 停止服务
            @author lkq@bt.cn
            @time 2022-08-20
            @return dict
        '''
        if not self.get_service_status2(): return public.returnMsg(False, '服务已停止!')
        init_file = '/etc/init.d/bt_check_shell'
        public.ExecShell("{} stop".format(init_file))
        time.sleep(0.3)
        if not self.get_service_status2():
            public.WriteLog('文件监控', '停止服务')
            return public.returnMsg(True, '停止成功!')
        return public.returnMsg(False, '停止失败!')

    def wrtie_init(self):
        init_file = '/etc/init.d/bt_check_shell'
        init_info = '''#!/bin/bash
        # chkconfig: 2345 55 25
        # description: bt.cn file hash check

        ### BEGIN INIT INFO
        # Provides:          bt_check_shell
        # Required-Start:    $all
        # Required-Stop:     $all
        # Default-Start:     2 3 4 5
        # Default-Stop:      0 1 6
        # Short-Description: starts bt_check_shell
        # Description:       starts the bt_check_shell
        ### END INIT INFO

        panel_path=/www/server/panel/class/projectModel
        init_file=$panel_path/bt_check_shell
        chmod +x $init_file
        cd $panel_path
        panel_start()
        {
                isStart=$(ps aux |grep bt_check_shell|grep -v init.d|grep -v grep|awk '{print $2}'|xargs)
                if [ "$isStart" == '' ];then
                        echo -e "Starting Bt-check_shell service... \c"
                        nohup $init_file &> $panel_path/service.log &
                        sleep 0.5
                        isStart=$(ps aux |grep bt_check_shell|grep -v init.d|grep -v grep|awk '{print $2}'|xargs)
                        if [ "$isStart" == '' ];then
                                echo -e "\033[31mfailed\033[0m"
                                echo '------------------------------------------------------'
                                cat $panel_path/service.log
                                echo '------------------------------------------------------'
                                echo -e "\033[31mError: Bt-check_shell service startup failed.\033[0m"
                                return;
                        fi
                        echo -e "\033[32mdone\033[0m"
                else
                        echo "Starting  Bt-check_shell service (pid $isStart) already running"
                fi
        }

        panel_stop()
        {
        	echo -e "Stopping Bt-check_shell service... \c";
                pids=$(ps aux |grep bt_check_shell|grep -v grep|grep -v init.d|awk '{print $2}'|xargs)
                arr=($pids)

                for p in ${arr[@]}
                do
                        kill -9 $p
                done
                echo -e "\033[32mdone\033[0m"
        }

        panel_status()
        {
                isStart=$(ps aux |grep bt_check_shell|grep -v grep|grep -v init.d|awk '{print $2}'|xargs)
                if [ "$isStart" != '' ];then
                        echo -e "\033[32mBt-check_shell service (pid $isStart) already running\033[0m"
                else
                        echo -e "\033[31mBt-check_shell service not running\033[0m"
                fi
        }

        case "$1" in
                'start')
                        panel_start
                        ;;
                'stop')
                        panel_stop
                        ;;
                'restart')
                        panel_stop
                        sleep 0.2
                        panel_start
                        ;;
                'reload')
                        panel_stop
                        sleep 0.2
                        panel_start
                        ;;
                'status')
                        panel_status
                        ;;
                *)
                        echo "Usage: /etc/init.d/bt_check_shell {start|stop|restart|reload}"
                ;;
        esac'''
        public.WriteFile(init_file, init_info)
        public.ExecShell("chmod +x {}".format(init_file))

    def restart_service(self, get):
        '''
            @name 重启服务
            @author lkq@bt.cn
            @time 2022-08-20
            @return dict
        '''
        if not self.get_service_status2(): return self.start_service(get)
        self.wrtie_init()
        init_file = '/etc/init.d/bt_check_shell'
        public.ExecShell("{} restart".format(init_file))
        if self.get_service_status2():
            public.WriteLog('文件监控', '重启服务')
            return public.returnMsg(True, '重启成功!')
        return public.returnMsg(False, '重启失败!')

    # 更新病毒库
    def update_virus_lib(self, get):
        '''
            @name 更新病毒库
            @author lkq@bt.cn
            @time 2022-08-22
            @return bool
        '''
        pass

    def get_webshell_total(self, get):
        '''
            @name 获取webshell总数
            @author lkq@bt.cn
            @time 2022-08-22
            @return dict
        '''
        if not os.path.exists(self._total):
            return 0
        else:
            try:
                data = json.loads(public.ReadFile(self._total))
                return data['total']
            except:
                return 0

    '''获取当前用户的日志日期'''

    def get_webshell_logs(self, get):
        path = self._WEBSHELl_PATH
        if not os.path.exists(path): return []
        data = []
        for fname in os.listdir(path):
            if re.search('(\d+-\d+-\d+).txt$', fname):
                tmp = fname.replace('.txt', '')
                data.append(tmp)
        return sorted(data, reverse=True)

    # 木马隔离文件
    def webshell_file(self, get):
        '''
            @name 木马隔离文件
            @author lkq@bt.cn
            @time 2022-08-20
            @param 无
            @return list 木马文件列表
        '''
        if not 'day' in get: get.day = time.strftime("%Y-%m-%d", time.localtime())
        path = self._WEBSHELl_PATH + "/check.json"
        if not os.path.exists(path):
            return []
        f = open(path, 'r')
        a = f.readlines()
        data = a[::-1]
        ret = []
        for i in data:
            try:
                datas = json.loads(i)
                ret.append(datas)
            except:
                continue
        return ret

    # 监控目录
    def get_monitor_dir(self, get):
        '''
            @name 监控目录
            @author lkq@bt.cn
            @time 2022-08-20
            @param 无
            @return list 监控目录列表
            {"index":"Uadasdasd","open": true, "path": "/www/wwwroot/192.168.1.72","ps": "192.168.1.72"}
        '''
        if os.path.exists(self._LIST_FILE):
            try:
                config = json.loads(public.ReadFile(self._LIST_FILE))
                return config
            except:
                public.WriteFile(self._LIST_FILE, '[]')
        return []

    # 添加监控目录
    def add_monitor_dir(self, get):
        '''
            @name 添加监控目录
            @author lkq@bt.cn
            @time 2022-08-20
            @param 无
            @return list 监控目录列表
        '''
        try:
            dirs = get.dirs

        except:
            return public.returnMsg(False, '参数错误!')
        if not os.path.exists(self._LIST_FILE):
            config = []
        else:
            config = self.get_monitor_dir(get)
        flag = False
        flag_list=[]
        for i2 in dirs:
            # 不能添加的目录列表
            white_list = ["/etc", "/boot", "/dev", "/lib", "/lib64", "/proc", "/root", "/sbin", "/usr", "/var"]
            for i in white_list:
                if i2.startswith(i):
                    return public.returnMsg(False, '不能添加该目录!【%s】,包括该目录的子目录' % i)
            if i2 == '/www/' or i2 == '/www':
                return public.returnMsg(False, '不能添加/www目录添加网站根目录!')
            if i2 == '/www/wwwroot/' or i2 == '/www/wwwroot':
                return public.returnMsg(False, '不能添加/www/wwwroot目录,请添加网站根目录!')
            if not os.path.exists(i2): return public.returnMsg(False, '{}目录不存在!'.format(i2))
            if i2 in [i['path'] for i in config]: return public.returnMsg(False, '{}已经存在!'.format(i2))
            flag_list.append(i2)
            flag = True
        if flag:
            for i2 in flag_list:
                paths, file = os.path.split(i2)
                config.append({
                    'index': public.GetRandomString(16),
                    'open': True,
                    'path': i2,
                    'ps': public.xsssec(file)
                })
            self.save_config(config)
        return public.returnMsg(True, '添加成功!')

    # 修改备注
    def edit_monitor_dir(self, get):
        '''
            @name 修改监控目录
            @author lkq@bt.cn
            @time 2022-08-20
            @param 无
            @return list 监控目录列表
        '''
        if not os.path.exists(self._LIST_FILE):
            config = []
        else:
            config = self.get_monitor_dir(get)
        for i in config:
            if i['path'] == get.path.strip():
                i['ps'] = public.xsssec(get.ps)
                break
        public.writeFile(self._LIST_FILE, json.dumps(config))
        return public.returnMsg(True, '修改成功!')

    # 删除监控目录
    def del_monitor_dir(self, get):
        '''
            @name 删除监控目录
            @author lkq@bt.cn
            @time  2022-08-20
            @param 无
            @return list 监控目录列表
        '''
        if not os.path.exists(self._LIST_FILE): return public.returnMsg(False, '目录不存在!')
        config = self.get_monitor_dir(get)
        flag = False
        for i in config:
            if i['path'] == get.path.strip():
                config.remove(i)
                flag = True
                break
        if flag:
            self.save_config(config)
            return public.returnMsg(True, '删除成功!')
        else:
            return public.returnMsg(False, '目录不存在!')

    # 关闭监控目录
    def stop_monitor_dir(self, get):
        if not os.path.exists(self._LIST_FILE): return public.returnMsg(False, '目录不存在!')
        config = self.get_monitor_dir(get)
        for i in config:
            if i['path'] == get.path.strip():
                i['open'] = False
                break
        self.save_config(config)
        return public.returnMsg(True, '关闭成功!')

    # 关闭监控目录
    def start_monitor_dir(self, get):
        if not os.path.exists(self._LIST_FILE): return public.returnMsg(False, '目录不存在!')
        config = self.get_monitor_dir(get)
        for i in config:
            if i['path'] == get.path.strip():
                i['open'] = True
                break
        self.save_config(config)
        return public.returnMsg(True, '开启成功!')

    def save_config(self, data):
        '''
            @name 保存配置
            @author hwliang<2021-10-21>
            @param data<dict_obj>{
                data:<list> 校验列表
            }
            @return void
        '''
        public.writeFile(self._LIST_FILE, json.dumps(data))
        if self.get_service_status2():
            self.restart_service(None)

    # 添加白名单路径
    def add_white_path(self, get):
        '''
            @name 添加白名单路径
            @author lkq@bt.cn
            @time  2022-08-20
            @param path
            @param type
            @return list 白名单路径列表
        '''

        if 'path' not in get:return public.returnMsg(False, '请输入路径!')
        if not os.path.exists(get.path):return public.returnMsg(False, '文件或者目录不存在!')
        if 'type' not in get:
            if os.path.isfile(get.path):
                get.type = 'file'
            else:
                get.type = 'dir'


        if not os.path.exists(self._WHITE_LIST_FILE):
            public.WriteFile(self._WHITE_LIST_FILE, '{"dir":[],"file":[]}')

        config = self.get_white_path(get)

        # 判断是否是dict
        if not isinstance(config, dict):
            config = {"dir": [], "file": []}
        if get.type == 'file':
            if get.path.strip() in config['file']: return public.returnMsg(False, '路径已经存在!')
        elif get.type == "dir":
            if get.path.strip() in config['dir']: return public.returnMsg(False, '路径已经存在!')
        else:
            return public.returnMsg(False, '类型不对!')
        config[get.type].append(get.path.strip())
        public.WriteFile(self._WHITE_LIST_FILE, json.dumps(config))
        return public.returnMsg(True, '添加成功!')

    def get_white_path(self, get):
        '''
            @name 获取白名单路径
            @author lkq@bt.cn
            @time 2022-08-20
            @param 无
            @return list 白名单路径列表
        '''
        if not os.path.exists(self._WHITE_LIST_FILE): return []
        try:
            config = json.loads(public.ReadFile(self._WHITE_LIST_FILE))
            return config
        except:
            return []

    def del_white_path(self, get):
        '''
            @name 删除白名单路径
            @author lkq@bt.cn
            @time 2022-08-20
            @param path
            @param type
            @return list 白名单路径列表
        '''
        if not os.path.exists(self._WHITE_LIST_FILE): return public.returnMsg(False, '路径不存在!')
        config = self.get_white_path(get)
        # 判断是否是dict
        if not isinstance(config, dict):
            config = {"dir": [], "file": []}
        if get.type == 'file':
            if not get.path.strip() in config['file']: return public.returnMsg(False, '路径不存在!')
        elif get.type == "dir":
            if not get.path.strip() in config['dir']: return public.returnMsg(False, '路径不存在!')
        else:
            return public.returnMsg(False, '类型不对!')
        config[get.type].remove(get.path.strip())
        public.WriteFile(self._WHITE_LIST_FILE, json.dumps(config))
        return public.returnMsg(True, '删除成功!')

    # 添加所有网站
    def add_all_site(self, get):
        '''
            @name 添加所有网站
            @author lkq@bt.cn
            @time  2022-08-20
        '''
        data = public.M("sites").select()
        ret = []
        if data:
            for i in data:
                if os.path.isdir(i['path']):
                    ret.append(i['path'])
        return ret

    # 递归目录返回文件名列表
    def gci(self, filepath):
        '''
            @name 递归目录返回文件名列表
            @author lwh@bt.cn
            @time  2023-08-08
        '''
        filename = []
        try:
            files = os.listdir(filepath)
            for fi in files:
                # 未知目录
                if fi == "X11":
                    continue
                fi_d = os.path.join(filepath, fi)
                if os.path.isdir(fi_d):
                    filename = filename + self.gci(fi_d)
                else:
                    filename.append(os.path.join(filepath, fi_d))
            return filename
        except:
            return filename

    # 分析字符串是否包含反弹shell或者恶意下载执行的特征
    def check_shell(self, content):
        '''
            @name 分析字符串是否包含反弹shell或者恶意下载执行的特征
            @author lwh@bt.cn
            @time  2023-08-08
        '''
        try:
            # 反弹shell类
            if (('bash' in content) and (('/dev/tcp/' in content) or ('telnet ' in content) or ('nc ' in content) or (
                    ('exec ' in content) and ('socket' in content)) or ('curl ' in content) or ('wget ' in content) or (
                                                 'lynx ' in content) or ('bash -i' in content))) or (
                    ".decode('base64')" in content) or ("exec(base64.b64decode" in content):
                return content
            elif ('/dev/tcp/' in content) and (('exec ' in content) or ('ksh -c' in content)):
                return content
            elif ('exec ' in content) and (('socket.' in content) or (".decode('base64')" in content)):
                return content
            # 下载执行类
            elif (('wget ' in content) or ('curl ' in content)) and (
                    (' -O ' in content) or (' -s ' in content)) and (
                    ' http' in content) and (
                    ('php ' in content) or ('perl' in content) or ('python ' in content) or ('sh ' in content) or (
                    'bash ' in content)):
                return content
            return False
        except:
            return False

    # 分析文件是否包含恶意特征、反弹shell特征
    # 存在返回恶意特征
    # 不存在返回空
    def analysis_file(self, file):
        '''
            @name 分析文件是否包含恶意特征、反弹shell特征
            @author lwh@bt.cn
            @time  2023-08-08
            @return string
        '''
        try:
            if not os.path.exists(file): return ""
            if os.path.isdir(file): return ""
            if (os.path.getsize(file) == 0) or (round(os.path.getsize(file) / float(1024 * 1024)) > 10): return ""
            strings = os.popen("strings %s 2>/dev/null" % file).read().splitlines()
            if len(strings) > 200: return ""
            time.sleep(0.01)
            for str in strings:
                if self.check_shell(str):
                    return u"反弹shell类：%s" % str
            return ""
        except:
            return ""

    # 分析一串字符串是否包含反弹shell。
    # 匹配成功则返回恶意特征信息
    # 否则返回空
    def analysis_strings(self, contents):
        try:
            content = contents.replace('\n', '')
            # 反弹shell类
            if self.check_shell(content):
                return u"反弹shell类：%s" % content
            return ""
        except:
            return ""

    # 服务器安全扫描
    def get_safe_scan(self, get):
        '''
            @name 服务器安全扫描
            @author lkq@bt.cn
            @time 2022-08-20
            @param 无
            @return 返回服务器扫描项
        '''
        if not '_ws' in get: return public.returnMsg(False, '只允许websocket连接!')
        get.security_count=100
        self.get_sys_user(get)
        self.get_sshd_config(get)
        self.get_file_attr(get)
        self.get_soft_detect(get)
        self.get_web_perm(get)
        self.get_other_detect(get)
        self.get_backdoor_detect(get)
        self.get_proc_detect(get)
        self.get_history_detect(get)
        self.get_log_detect(get)
        self.get_rootkit_detect(get)
        data={"time": int(time.time()),"security_count":get.security_count}
        public.WriteFile("/www/server/panel/data/safe_detect.json", json.dumps(data))

    def get_safe_count(self, get):
        if not  os.path.exists("/www/server/panel/data/safe_detect.json"):
            msg={"pay":self.__check_auth(),"msg":"未检测到安全扫描数据"}
            return public.returnMsg(False, msg)
        data=json.loads(public.ReadFile("/www/server/panel/data/safe_detect.json"))
        data["pay"]=self.__check_auth()
        return public.returnMsg(True, data)

    # 系统用户扫描
    def get_sys_user(self, get):
        '''
            @name 系统用户扫描
            @author lkq@bt.cn
            @time 2022-08-20
            @param 超级用户  空口令用户  新增的用户  账户密码策略
            @return 返回系统用户扫描项
        '''

        def check_run():
            '''
                @name 开始检测
                @author lkq<2021-01-12>
                @return tuple (status<bool>,msg<string>)
            '''
            ret = []
            cfile = '/etc/passwd'
            if os.path.exists(cfile):
                f = open(cfile, 'r')
                for i in f:
                    i = i.strip().split(":")
                    if i[2] == '0' and i[3] == '0':
                        if i[0] == 'root': continue
                        ret.append(i[0])
            if ret:
                return False, '存在后门用户%s' % '、'.join(ret)
            return True, '当前未发现存在后门用户'

        flag, msg = check_run()
        time.sleep(0.1)
        if flag:
            get._ws.send({"progress": 1, "topic": "system_account", "item": "super_user", "name": "后门用户", "status": 1,
                          "operation": "", "info": ""})
        else:
            get.security_count-=30
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 1, "topic": "system_account","points":30,"item": "super_user", "name": "后门用户", "status": 3,
                          "operation": "", "info": msg})
        time.sleep(0.2)

        def check_run():
            '''
                @name 开始检测
                @author lkq<2021-01-12>
                @return tuple (status<bool>,msg<string>)
            '''
            ret = []
            cfile = '/etc/shadow'
            if os.path.exists(cfile):
                f = open(cfile, 'r')
                for i in f:
                    i = i.strip().split(":")
                    if len(i) > 4:
                        if i[1] == '':
                            ret.append(i[0])
            if ret:
                return False, '存在空口令用户%s' % ''.join(ret)
            return True, '当前未发现存在空口令用户'

        flag, msg = check_run()
        if flag:
            get._ws.send({"progress": 2, "topic": "system_account", "item": "super_user", "name": "空口令用户", "status": 1,
                          "operation": "", "info": ""})
        else:
            get.security_count-=3
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 2, "topic": "system_account","points":3, "item": "super_user", "name": "空口令用户", "status": 2,
                          "operation": "删除用户或者给用户设置密码", "info": msg})

        time.sleep(0.1)
        get._ws.send({"progress": 3, "topic": "system_account", "item": "super_user", "name": "用户权限检测", "status": 1,
                      "operation": "", "info": ""})

        time.sleep(0.2)

        def check_run():
            try:
                p_file = '/etc/login.defs'
                p_body = public.readFile(p_file)
                if not p_body: return True, '无风险'
                tmp = re.findall("\nPASS_MIN_LEN\s+(.+)", p_body, re.M)
                if not tmp: return True, '无风险'
                maxdays = tmp[0].strip()
                # 7-14
                if int(maxdays) < 7:
                    return False, '【%s】文件中把PASS_MIN_LEN 参数设置为大于等于7' % p_file
                return True, '无风险'
            except:
                return True, '无风险'

        flag, msg = check_run()
        if flag:
            get._ws.send({"progress": 4, "topic": "system_account", "item": "super_user", "name": "账户密码策略", "status": 1,
                          "operation": "", "info": ""})
        else:
            get.security_count-=3
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 4, "topic": "system_account","points":3, "item": "super_user", "name": "账户密码策略", "status": 2,
                          "operation": "", "info": msg})

        time.sleep(0.3)
        get._ws.send({"progress": 5, "topic": "system_account", "item": "super_user", "name": "账户密码复杂度", "status": 1,
                      "operation": "", "info": ""})

        # 检测sudo权限异常账户
        def check_run():
            flag, msg = True, '无风险'
            try:
                if os.path.exists('/etc/sudoers'):
                    shell_process3 = public.ExecShell(
                        "cat /etc/sudoers 2>/dev/null |grep -v '#'|grep 'ALL=(ALL)'|awk '{print $1}'").read().splitlines()
                    for user in shell_process3:
                        if user.replace("\n", "") != 'root' and user[0] != '%':
                            msg = '用户 【{}】 可通过sudo命令获取特权\nvi /etc/sudoers #更改sudo设置'.format(user.strip())
                            flag = False
                return flag, msg
            except:
                return flag, msg
        flag, msg = check_run()
        if flag:
            get._ws.send({"progress": 6, "topic": "system_account", "item": "super_user", "name": "sudo权限异常账户", "status": 1,
                      "operation": "", "info": ""})
        else:
            get.security_count -= 3
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 6, "topic": "system_account", "points":3, "item": "super_user", "name": "sudo权限异常账户",
                          "status": 2, "operation": "", "info": msg})

        # 检测免密登录账户公钥
        def check_run():
            flag, msg = True, '无风险'
            for dir in os.listdir('/home/'):
                file = os.path.join('%s%s%s' % ('/home/', dir, '/.ssh/authorized_keys'))
                try:
                    if os.path.exists(file):
                        shell_process = os.popen("cat " + file + " 2>/dev/null |awk '{print $3}'").read().splitlines()
                        if len(shell_process):
                            authorized_key = ' & '.join(shell_process).replace("\n", "")
                            msg = '用户{}存在免密登录的证书，证书客户端名称：{}\n处理方案：vi {} 删除证书设置'.format(dir, authorized_key, file)
                        flag = False
                    return flag, msg
                except:
                    return flag, msg
        flag, msg = check_run()
        if flag:
            get._ws.send({"progress": 7, "topic": "system_account", "item": "super_user", "name": "免密登录账户", "status": 1,
                      "operation": "", "info": ""})
        else:
            get.security_count -= 3
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 7, "topic": "system_account","points":3, "item": "super_user", "name": "免密登录账户",
                          "status": 2, "operation": "", "info": msg})

    # SSHD配置扫描
    def get_sshd_config(self, get):
        '''
            @name SSHD配置扫描
            @author lkq@bt.cn
            @time 2022-08-20
            @param SSHD服务端口 SSHD可登录用户 STFP子系统服务  SSH协议版本 远程访问策略
            @return 返回SSHD配置扫描项
        '''

        def get_port():
            try:
                file = '/etc/ssh/sshd_config'
                conf = public.readFile(file)
                if not conf: conf = ''
                rep = r"#*Port\s+([0-9]+)\s*\n"
                tmp1 = re.search(rep, conf)
                if tmp1:
                    port = tmp1.groups(0)[0]
                    return port
                return '0'
            except:
                return '0'

        if get_port() == '22':
            time.sleep(0.1)
            get.security_count-=5
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 8, "topic": "sshd_service", "item": "super_user","points":5, "name": "SSHD服务端口", "status": 2,
                          "operation": "", "info": "当前默认端口为：22 ，建议修改！"})
        else:
            time.sleep(0.2)
            get._ws.send({"progress": 8, "topic": "sshd_service", "item": "super_user", "name": "SSHD服务端口", "status": 1,
                          "operation": "", "info": ""})
        time.sleep(0.3)
        get._ws.send({"progress": 9, "topic": "sshd_service", "item": "super_user", "name": "SSHD可登录用户", "status": 1,
                      "operation": "", "info": ""})
        time.sleep(0.1)
        get._ws.send({"progress": 10, "topic": "sshd_service", "item": "super_user", "name": "SFTP子系统服务", "status": 1,
                      "operation": "", "info": ""})
        time.sleep(0.1)
        get._ws.send({"progress": 11, "topic": "sshd_service", "item": "super_user", "name": "SSH协议版本", "status": 1,
                      "operation": "", "info": ""})
        time.sleep(0.3)

        def check_run():
            '''
                @name 检测禁止SSH空密码登录
                @author lkq<2020-08-10>
                @return tuple (status<bool>,msg<string>)
            '''

            if os.path.exists('/etc/ssh/sshd_config'):
                try:
                    info_data = public.ReadFile('/etc/ssh/sshd_config')
                    if info_data:
                        if re.search('PermitEmptyPasswords\s+no', info_data):
                            return True, '无风险'
                        else:
                            return False, 'SSH存在空密码登录 当前配置文件/etc/ssh/sshd_config 【PermitEmptyPasswords】配置为：yes，请设置为no'
                except:
                    return True, '无风险'
            return True, '无风险'

        flag, msg = check_run()
        if flag:
            get._ws.send(
                {"progress": 15, "topic": "sshd_service", "item": "super_user", "name": "SSH空密码登录", "status": 1,
                 "operation": "", "info": ""})
        else:
            get.security_count-=5
            if get.security_count<0:get.security_count=0
            get._ws.send(
                {"progress": 15, "topic": "sshd_service","points":5, "item": "super_user", "name": "SSH空密码登录", "status": 2,
                 "operation": "", "info": msg})

    # 重要文件权限及其属性
    def get_file_attr(self, get):
        '''
            @name 重要文件权限及其属性
            @author lkq@bt.cn
            @time 2022-08-20
            @param /etc/passwd   /etc/shadow  /etc/gshadow  /var/log/messages
            @return 返回重要文件权限及其属性扫描项
        '''
        time.sleep(0.1)

        file_attr = public.get_mode_and_user("/etc/passwd")
        if file_attr['user'] != 'root':
            get.security_count-=5
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 20, "topic": "file_mode", "points":5, "item": "passwd", "name": "/etc/passwd", "status": 2,
                          "operation": "", "info": "当前文件所有者为：" + file_attr['user'] + "，建议修改为root"})
        elif file_attr['mode'] == '755' or file_attr['mode'] == '777':
            get.security_count-=4
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 20, "topic": "file_mode","points":4, "item": "passwd", "name": "/etc/passwd", "status": 2,
                          "operation": "", "info": "当前文件权限为：" + file_attr['mode'] + "，建议修改为644"})
        else:
            get._ws.send({"progress": 20, "topic": "file_mode", "item": "passwd", "name": "/etc/passwd", "status": 1,
                          "operation": "", "info": ""})

        time.sleep(0.3)
        file_attr = public.get_mode_and_user("/etc/shadow")
        if file_attr['user'] != 'root':
            get.security_count-=4
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 25, "topic": "file_mode","points":4, "item": "shadow", "name": "/etc/shadow", "status": 2,
                          "operation": "", "info": "当前文件所有者为：" + file_attr['user'] + "，建议修改为root"})
        elif file_attr['mode'] == '755' or file_attr['mode'] == '777':
            get.security_count-=5
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 25, "topic": "file_mode","points":5, "item": "shadow", "name": "/etc/shadow", "status": 2,
                          "operation": "", "info": "当前文件权限为：" + file_attr['mode'] + "，建议修改为640"})
        else:
            get._ws.send({"progress": 25, "topic": "file_mode", "item": "shadow", "name": "/etc/shadow", "status": 1,
                          "operation": "", "info": ""})
        time.sleep(0.1)

        file_attr = public.get_mode_and_user("/etc/group")
        if file_attr['user'] != 'root':
            get.security_count-=4
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 28, "topic": "file_mode","points":4, "item": "group", "name": "/etc/group", "status": 2,
                          "operation": "", "info": "当前文件所有者为：" + file_attr['user'] + "，建议修改为root"})
        elif file_attr['mode'] == '755' or file_attr['mode'] == '777':
            get.security_count-=5
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 28, "topic": "file_mode","points":5, "item": "group", "name": "/etc/group", "status": 2,
                          "operation": "", "info": "当前文件权限为：" + file_attr['mode'] + "，建议修改为644"})
        else:
            get._ws.send({"progress": 28, "topic": "file_mode", "item": "shadow", "name": "/etc/group", "status": 1,
                          "operation": "", "info": ""})

        time.sleep(0.3)

        file_attr = public.get_mode_and_user("/etc/gshadow")
        if file_attr['user'] != 'root':
            get.security_count-=5
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 30, "topic": "file_mode","points":5, "item": "gshadow", "name": "/etc/gshadow", "status": 2,
                          "operation": "", "info": "当前文件所有者为：" + file_attr['user'] + "，建议修改为root"})
        elif file_attr['mode'] == '755' or file_attr['mode'] == '777':
            get.security_count-=5
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 30, "topic": "file_mode","points":5, "item": "gshadow", "name": "/etc/gshadow", "status": 2,
                          "operation": "", "info": "当前文件权限为：" + file_attr['mode'] + "，建议修改为600"})
        else:
            get._ws.send({"progress": 30, "topic": "file_mode", "item": "shadow", "name": "/etc/gshadow", "status": 1,
                          "operation": "", "info": ""})
        time.sleep(0.1)

        # file_attr = public.get_mode_and_user("/etc/gshadow")
        # if file_attr['user'] != 'root':
        #     get.security_count-=5
        #     if get.security_count<0:get.security_count=0
        #     get._ws.send({"progress": 34, "topic": "file_mode","points":5, "item": "gshadow", "name": "/etc/gshadow", "status": 2,
        #                   "operation": "", "info": "当前文件所有者为：" + file_attr['user'] + "，建议修改为root"})
        # elif file_attr['mode'] == '755' or file_attr['mode'] == '777':
        #     get.security_count-=5
        #     if get.security_count<0:get.security_count=0
        #     get._ws.send({"progress": 34, "topic": "file_mode","points":5, "item": "gshadow", "name": "/etc/gshadow", "status": 2,
        #                   "operation": "", "info": "当前文件权限为：" + file_attr['mode'] + "，建议修改为600"})
        # else:
        #     get._ws.send(
        #         {"progress": 35, "topic": "file_mode", "item": "shadow", "name": "/var/log/messages", "status": 1,
        #          "operation": "", "info": ""})

        def check_system_integrity():
            suspicious, malice = False, False

            system_file = ["depmod", "fsck", "fuser", "ifconfig", "ifdown", "ifup", "init", "insmod", "ip", "lsmod",
                           "modinfo", "modprobe", "nologin", "rmmod", "route", "rsyslogd", "runlevel", "sulogin",
                           "sysctl", "awk", "basename", "bash", "cat", "chmod", "chown", "cp", "cut", "date", "df", "dmesg",
                           "echo", "egrep", "env", "fgrep", "find", "grep", "kill", "logger", "login", "ls", "mail",
                           "mktemp", "more", "mount", "mv", "netstat", "ping", "ps", "pwd", "readlink", "rpm", "sed", "sh",
                           "sort", "su", "touch", "uname", "gawk", "mailx", "adduser", "chroot", "groupadd", "groupdel",
                           "groupmod", "grpck", "lsof", "pwck", "sestatus", "sshd", "useradd", "userdel", "usermod", "vipw",
                           "chattr", "curl", "diff", "dirname", "du", "file", "groups", "head", "id", "ipcs", "killall",
                           "last", "lastlog", "ldd", "less", "lsattr", "md5sum", "newgrp", "passwd", "perl", "pgrep",
                           "pkill", "pstree", "runcon", "sha1sum", "sha224sum", "sha256sum", "sha384sum", "sha512sum",
                           "size", "ssh", "stat", "strace", "strings", "sudo", "tail", "test", "top", "tr", "uniq", "users",
                           "vmstat", "w", "watch", "wc", "wget", "whereis", "which", "who", "whoami", "test"]
            binary_list = ['/usr/bin/', '/usr/sbin/', '/usr/local/sbin/', '/usr/local/bin/']
            try:
                for dir in binary_list:
                    if not os.path.exists(dir): continue
                    for file in self.gci(dir):
                        filename = os.path.basename(file)
                        if not filename in system_file: continue
                        malware = self.analysis_file(file)
                        if malware:
                            get.security_count -= 5
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send(
                                {"progress": 38, "topic": "file_mode", "points": 5, "item": "file", "name": file,
                                 "status": 3, "operation": "", "info": "发现文件{}存在恶意特征\n建议排查文件内容，删除恶意代码".format(file)})
                            malice = False
                        else:
                            get._ws.send(
                                {"progress": 38, "topic": "file_mode", "item": "file", "name": file,
                                 "status": 1,
                                 "operation": "", "info": ""})
                return suspicious, malice
            except:
                return suspicious, malice
        check_system_integrity()

        # 检查所有临时目录文件
        def check_tmp():
            suspicious, malice = False, False
            tmp_list = ['/tmp/', '/var/tmp/', '/dev/shm/']
            try:
                for dir in tmp_list:
                    if not os.path.exists(dir): continue
                    for file in self.gci(dir):
                        malware = self.analysis_file(file)
                        if malware:
                            get.security_count -= 5
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send(
                                {"progress": 40, "topic": "file_mode","points": 5, "item": "file", "name": file,
                                 "status": 3, "operation": "", "info": "发现文件{}存在恶意特征\n建议排查文件内容，删除恶意代码".format(file)})
                            malice = False
                        else:
                            get._ws.send(
                                {"progress": 40, "topic": "file_mode", "item": "file", "name": file,
                                 "status": 1,
                                 "operation": "", "info": ""})
                return suspicious, malice
            except:
                return suspicious, malice
        check_tmp()

    # 重点软件检测
    def get_soft_detect(self, get):
        '''
            @name 重点软件检测
            @author lkq@bt.cn
            @time 2022-08-20
            @param Apache Nginx MySQL PHP Redis FTP
            @return 返回重点软件检测扫描项
        '''

        # Apache
        time.sleep(0.1)
        if os.path.exists("/www/server/apache/bin/httpd"):
            get._ws.send(
                {"progress": 42, "topic": "software", "item": "apache", "name": "Apache", "status": 1, "operation": "",
                 "info": ""})
        else:
            get._ws.send(
                {"progress": 42, "topic": "software", "item": "apache", "name": "Apache", "status": -1, "operation": "",
                 "info": ""})

        # Nginx
        time.sleep(0.2)
        if os.path.exists("/www/server/nginx/conf/nginx.conf"):
            # Nginx 版本泄露
            def check_run():
                '''
                    @name 检测nginx版本泄露
                    @author lkq<2020-08-10>
                    @return tuple (status<bool>,msg<string>)
                '''
                if os.path.exists('/www/server/nginx/conf/nginx.conf'):
                    try:
                        info_data = public.ReadFile('/www/server/nginx/conf/nginx.conf')
                        if info_data:
                            if re.search('server_tokens off;', info_data):
                                return True, '无风险'
                            else:
                                return False, '当前Nginx存在版本泄露请在Nginx配置文件中添加或者修改参数server_tokens 为off;，例：server_tokens off;'
                    except:
                        return True, '无风险'
                return True, '无风险'

            flag,msg=check_run()
            if flag:
                get._ws.send(
                    {"progress": 44, "topic": "software", "item": "nginx", "name": "Nginx", "status": 1, "operation": "",
                     "info": ""})
            else:
                get.security_count -= 5
                if get.security_count < 0: get.security_count = 0
                get._ws.send(
                    {"progress": 44, "topic": "software","points":5, "item": "nginx", "name": "Nginx", "status": 2, "operation": "",
                     "info": msg})
        else:
            get._ws.send(
                {"progress": 44, "topic": "software", "item": "nginx", "name": "Nginx", "status": -1, "operation": "",
                 "info": ""})



        time.sleep(0.2)
        if os.path.exists("/www/server/redis/redis.conf"):
            #检测redis是否开启保护模式
            def check_run():
                '''
                    @name 开始检测
                    @author hwliang<2020-08-03>
                    @return tuple (status<bool>,msg<string>)
                '''

                p_file = '/www/server/redis/redis.conf'
                p_body = public.readFile(p_file)
                if not p_body: return True, '无风险'
                tmp = re.findall(r"^\s*requirepass\s+(.+)", p_body, re.M)
                if tmp:
                    redis_pass = tmp[0].strip()
                    pass_info = public.ReadFile("/www/server/panel/config/weak_pass.txt")
                    if not pass_info: return True, '无风险'
                    pass_list = pass_info.split('\n')
                    for i in pass_list:
                        if i == redis_pass:
                            return False, '当前Redis密码【%s】为弱密码，请修改密码' % redis_pass

                tmps = re.findall(r"^\s*bind\s+(0\.0\.0\.0)", p_body, re.M)
                if tmps:
                    tmp = re.findall(r"^\s*requirepass\s+(.+)", p_body, re.M)
                    if not tmp: return False, 'Reids允许外网连接，但未设置Redis密码，极度危险，请立即处理'
                return True, '无风险'

            flag,msg=check_run()
            if flag:
                get._ws.send({"progress": 47, "topic": "software", "item": "redis", "name": "Redis", "status": 1, "operation": "",
                     "info": ""})
            else:
                get.security_count -= 20
                if get.security_count < 0: get.security_count = 0
                get._ws.send({"progress": 47, "topic": "software","points":20, "item": "redis", "name": "Redis", "status": 3,
                              "operation": "",
                              "info": msg})
        else:
            get._ws.send({"progress": 47, "topic": "software", "item": "Redis", "name": "Redis", "status": -1, "operation": "","info": ""})


        time.sleep(0.1)
        #ftp
        def check_run():
            """检测FTP弱口令
                @author linxiao<2020-9-19>
                @return (bool, msg)
            """
            pass_info = public.ReadFile("/www/server/panel/config/weak_pass.txt")
            if not pass_info: return True, '无风险'
            pass_list = pass_info.split('\n')
            data = public.M("ftps").select()
            ret = ""
            for i in data:
                if i['password'] in pass_list:
                    ret += "FTP：" + i['name'] + "存在弱口密码：" + i['password'] + "\n"
            if ret:
                return False, ret
            else:
                return True, '无风险'

        flag,msg=check_run()
        if flag:
            get._ws.send({"progress": 50, "topic": "software", "item": "FTP", "name": "FTP", "status": 1, "operation": "",
                          "info": ""})
        else:
            get.security_count-=10
            if get.security_count<0:get.security_count=0
            get._ws.send({"progress": 50, "topic": "software","points":10, "item": "FTP", "name": "FTP", "status": 3, "operation": "",
                          "info": msg})

        time.sleep(0.3)
        get._ws.send({"progress": 50, "topic": "software", "item": "MongoDB", "name": "MySQL/MongoDB", "status": 1,
                      "operation": "",
                      "info": ""})

    # 网站权限检测
    def get_web_perm(self, get):
        '''
            @name 网站权限检测
            @author lkq@bt.cn
            @time 2022-08-20
            @param Web服务  分析网站目录的权限以及ACL规则
            @return 返回网站权限检测扫描项
        '''
        time.sleep(0.1)
        #检测WEB服务是否启动
        data=public.get_webserver()
        if data=="nginx":
            if public.is_nginx_process_exists():
                get._ws.send({"progress": 52, "topic": "website_permissions", "item": "web", "name": "Web 服务", "status": 1,
                              "operation": "",
                              "info": ""})
            else:
                get.security_count -= 5
                if get.security_count < 0: get.security_count = 0
                get._ws.send(
                    {"progress": 52, "topic": "website_permissions","points":5, "item": "web", "name": "Web 服务", "status": 2,
                     "operation": "",
                     "info": "Nginx未启动"})
        elif data=="apache":
            if public.is_httpd_process_exists():
                get._ws.send({"progress": 52, "topic": "website_permissions", "item": "web", "name": "Web 服务", "status": 1,
                              "operation": "",
                              "info": ""})
            else:
                get.security_count -= 5
                if get.security_count < 0: get.security_count = 0
                get._ws.send(
                    {"progress": 52, "topic": "website_permissions","points":5, "item": "web", "name": "Web 服务", "status": 2,
                     "operation": "",
                     "info": "Apache未启动"})
        time.sleep(0.2)
        #检测网站目录权限
        data = public.M('sites').field('id,name,path').select()
        count=0
        for i in data:
           count+=1
           if count>30:break
           if os.path.isdir(i['path']):
                file_attr = public.get_mode_and_user(i['path'])
                if file_attr['mode']=="777":
                    get.security_count -= 3
                    if get.security_count < 0: get.security_count = 0
                    get._ws.send({"progress": 53, "topic": "website_permissions","points":3, "item": "permissions", "name": "分析网站%s目录权限"%i['name'],
                                  "status": 2,
                                  "operation": "", "info": "网站%s目录权限为777 请修改为755"%i['name']})
                else:
                    get._ws.send({"progress": 53, "topic": "website_permissions", "item": "permissions",
                                  "name": "分析网站%s目录权限" % i['name'],
                                  "status": 1,
                                  "operation": "", "info": ""})

    # 其他项目检测
    def get_other_detect(self, get):
        '''
            @name 其他项目检测
            @author lkq@bt.cn
            @time 2022-08-20
            @param 系统默认防火墙  日志审计  umask设置 入侵防御  系统启动项 定时任务
            @return 返回其他项目检测扫描项
        '''
        time.sleep(0.1)
        is_firewalld=public.get_firewall_status()
        if is_firewalld==0:
            get.security_count -= 3
            if get.security_count < 0: get.security_count = 0
            get._ws.send(
                {"progress": 55, "topic": "other", "item": "firewall","points":3, "name": "系统默认防火墙保护", "status": 2, "operation": "",
                 "info": "防火墙未启动"})
        elif is_firewalld==1:
            get._ws.send(
                {"progress": 55, "topic": "other", "item": "firewall", "name": "系统默认防火墙保护", "status": 1,
                 "operation": "",
                 "info": ""})

        time.sleep(0.3)
        get._ws.send(
            {"progress": 56, "topic": "other", "item": "firewall", "name": "日志审计", "status": 1, "operation": "",
             "info": ""})


        time.sleep(0.1)

        def check_runs():
            # 判断是否存在/etc/profile文件
            # if os.path.exists("/etc/bashrc"):
            #     # 读取文件内容
            #     profile = public.ReadFile("/etc/bashrc")
            #     # 判断是否存在umask设置
            #     if re.search("\s+umask 0", profile):
            #         # 判断是否设置为027
            #         if re.search("\s+umask 022", profile):
            #             return True, "无风险"
            #         else:
                        return True, "无风险"
                        # return False,"/etc/bashrc umask 022 设置不正确 请修改为umask 027"
                # else:
                #     return True, "无风险"

        flag,msg=check_runs()
        if flag:
            get._ws.send(
                {"progress": 57, "topic": "other", "item": "firewall", "name": "/etc/bashrc Umask设置", "status": 1, "operation": "",
                 "info": ""})
        else:
            get.security_count -= 3
            if get.security_count < 0: get.security_count = 0
            get._ws.send(
                {"progress": 57, "topic": "other","points":3, "item": "firewall", "name": "/etc/bashrc Umask设置", "status": 2, "operation": "",
                 "info": msg})

        time.sleep(0.2)
        def check_run():
            # 判断是否存在/etc/profile文件
            if os.path.exists("/etc/profile"):
                # 读取文件内容
                profile = public.ReadFile("/etc/profile")
                # 判断是否存在umask设置
                if re.search("\s+umask 0", profile):
                    # 判断是否设置为027
                    if re.search("\s+umask 022", profile):
                        return True, "无风险"
                    else:
                        return True, "无风险"
                        return False,"/etc/profile umask 022 设置不正确 请修改为umask 027"
                else:
                    return True, "无风险"
        flag,msg=check_run()
        if flag:
            get._ws.send(
                {"progress": 58, "topic": "other", "item": "firewall", "name": "/etc/profile Umask设置", "status": 1, "operation": "",
                 "info": ""})
        else:
            get.security_count -= 3
            if get.security_count < 0: get.security_count = 0
            get._ws.send(
                {"progress": 58, "topic": "other","points":3, "item": "firewall", "name": "/etc/profile Umask设置", "status": 2,
                 "operation": "",
                 "info": msg})

        time.sleep(0.1)
        get._ws.send(
            {"progress": 59, "topic": "other", "item": "firewall", "name": "系统启动项", "status": 1, "operation": "",
             "info": ""})


        time.sleep(0.1)
        get._ws.send(
            {"progress": 59, "topic": "other", "item": "firewall", "name": "已有定时任务", "status": 1, "operation": "",
             "info": ""})

    def get_backdoor_detect(self, get):
        # ld.so.preload后门检测
        def check_ld_so_preload():
            suspicious, malice = False, False
            try:
                if not os.path.exists('/etc/ld.so.preload'): return suspicious, malice
                with open('/etc/ld.so.preload') as f:
                    for line in f:
                        if not len(line) > 3: continue
                        if line[0] != '#':
                            content = self.analysis_strings(line)
                            if content:
                                get.security_count -= 3
                                if get.security_count < 0: get.security_count = 0
                                get._ws.send({"progress": 62, "topic": "backdoor", "points": 3, "item": "backdoor", "name": "/etc/ld.so.preload",
                                              "status": 3, "operation": "", "info": "/etc/ld.so.preload存在存在后门\n建议删除所有so设置"})
                                malice = True
                                break
                    if malice:
                        get._ws.send({"progress": 62, "topic": "backdoor", "item": "backdoor",
                                      "name": "/etc/ld.so.preload", "status": 1, "operation": "", "info": ""})

                return suspicious, malice
            except:
                return suspicious, malice
        check_ld_so_preload()

        # 分析cron定时任务后门
        def check_cron():
            try:
                cron_dir_list = ['/var/spool/cron/', '/etc/cron.d/', '/etc/cron.daily/', '/etc/cron.weekly/',
                                 '/etc/cron.hourly/', '/etc/cron.monthly/']
                for cron in cron_dir_list:
                    suspicious, malice = False, False  # 默认没有恶意代码
                    for file in self.gci(cron):
                        if not os.path.exists(file): continue
                        if os.path.isdir(file): continue
                        for i in open(file, 'r'):
                            content = self.analysis_strings(i)
                            if content:
                                get.security_count -= 3
                                if get.security_count < 0: get.security_count = 0
                                get._ws.send({"progress": 64, "topic": "backdoor", "points": 3, "item": "backdoor",
                                              "name": "{}定时任务后门".format(file), "status": 3, "operation": "",
                                              "info": "{}文件存在后门代码\n建议删除该定时任务"})
                                malice = True
                                break
                        if not malice:
                            get._ws.send({"progress": 64, "topic": "backdoor", "item": "backdoor",
                                          "name": "{}定时任务后门".format(file), "status": 1, "operation": "",
                                          "info": ""})
            except:
                pass
        check_cron()

        # 分析SSH后门
        def check_SSH():
            suspicious, malice = False, False
            try:
                infos = os.popen(
                    "netstat -ntpl 2>/dev/null |grep -v ':22 '| awk '{if (NR>2){print $7}}'").read().splitlines()
                for info in infos:
                    pid = info.split("/")[0]
                    if os.path.exists('/proc/%s/exe' % pid):
                        if 'sshd' in os.readlink('/proc/%s/exe' % pid):
                            get.security_count -= 3
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 66, "topic": "backdoor", "points": 3, "item": "backdoor",
                                          "name": "排查进程{}".format(info), "status": 3, "operation": "",
                                          "info": "发现非22端口的sshd服务，进程pid：{}\n建议执行【kill {}】关闭异常sshd进程".format(pid, pid)})
                        else:
                            get._ws.send({"progress": 66, "topic": "backdoor", "item": "backdoor",
                                          "name": "排查进程{}".format(info), "status": 1, "operation": "",
                                          "info": ""})
                            malice = True
                return suspicious, malice
            except:
                return suspicious, malice
        # check_SSH()

        # 分析SSH Server wrapper 后门
        def check_SSHwrapper():
            suspicious, malice = False, False
            try:
                infos = os.popen("file /usr/sbin/sshd 2>/dev/null").read().splitlines()
                if not len(infos): return suspicious, malice
                if ('ELF' not in infos[0]) and ('executable' not in infos[0]):
                    get.security_count -= 3
                    if get.security_count < 0: get.security_count = 0
                    get._ws.send({"progress": 68, "topic": "backdoor", "item": "backdoor",
                                  "name": "SSHwrapper后门", "status": 3, "operation": "",
                                  "info": "/usr/sbin/sshd被篡改\n建议删除文件，并重新安装ssh服务"})
                else:
                    get._ws.send({"progress": 68, "topic": "backdoor", "item": "backdoor",
                                  "name": "SSHwrapper后门", "status": 1, "operation": "",
                                  "info": ""})
                    malice = True
                return suspicious, malice
            except:
                return suspicious, malice
        check_SSHwrapper()

        # 分析inetd后门
        def check_inetd():
            suspicious, malice = False, False
            try:
                if not os.path.exists('/etc/inetd.conf'): return suspicious, malice
                with open('/etc/inetd.conf') as f:
                    get._ws.send({"progress": 70, "topic": "backdoor", "item": "backdoor",
                                  "name": "inetd后门", "status": 1, "operation": "",
                                  "info": ""})
                    for line in f:
                        content = self.analysis_strings(line)
                        if content:
                            get.security_count -= 3
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 70, "topic": "backdoor", "points":3, "item": "backdoor",
                                          "name": "inetd后门", "status": 3, "operation": "",
                                          "info": "/etc/inetd.conf为后门文件\n建议删除文件"})
                            malice = True
                            break
                return suspicious, malice
            except:
                return suspicious, malice
        check_inetd()

        # 分析xinetd后门
        def check_xinetd():
            suspicious, malice = False, False
            try:
                if not os.path.exists('/etc/xinetd.conf/'): return suspicious, malice
                for file in os.listdir('/etc/xinetd.conf/'):
                    malice = False
                    with open(os.path.join('%s%s' % ('/etc/xinetd.conf/', file))) as f:
                        for line in f:
                            content = self.analysis_strings(line)
                            if content:
                                get.security_count -= 3
                                if get.security_count < 0: get.security_count = 0
                                malice = True
                    if malice:
                        get._ws.send({"progress": 73, "topic": "backdoor", "points": 3, "item": "backdoor",
                                      "name": "xinetd后门{}".format(file), "status": 3, "operation": "",
                                      "info": "{}为后门文件\n建议删除文件".format(file)})
                    else:
                        get._ws.send({"progress": 73, "topic": "backdoor", "item": "backdoor",
                                      "name": "xinetd后门{}".format(file), "status": 1, "operation": "",
                                      "info": ""})
                return suspicious, malice
            except:
                return suspicious, malice
        check_xinetd()

        # 分析setuid后门
        def check_setuid():
            exist_list = []
            # 列出重要文件，先判断是否存在
            file_list = ['/usr/bin/chage', '/usr/bin/gpasswd', '/usr/bin/wall', '/usr/bin/chfn', '/usr/bin/chsh',
                         '/usr/bin/newgrp', '/usr/bin/find', '/usr/bin/write', '/usr/sbin/usernetctl', '/bin/mount',
                         '/bin/umount', '/bin/ping', '/sbin/netreport']
            for fl in file_list:
                if os.path.exists(fl):
                    exist_list.append(fl)
            # find命令-perm 判断是否有suid或guid，有则返回该文件名
            try:
                for f in exist_list:
                    result_path = public.ExecShell('find {} -type f -perm /04000 -o -perm /02000'.format(f))[0].strip()
                    if result_path:
                        get.security_count -= 5
                        if get.security_count < 0: get.security_count = 0
                        get._ws.send({"progress": 75, "topic": "backdoor", "points":5, "item": "backdoor",
                                      "name": "{}文件suid特权".format(f), "status": 3, "operation": "",
                                      "info": "文件{}被设置sid属性\n执行【chmod u-s {}】去掉sid权限".format(f, f)})
                    else:
                        get._ws.send({"progress": 75, "topic": "backdoor", "item": "backdoor",
                                      "name": "{}文件suid特权".format(f), "status": 1, "operation": "",
                                      "info": ""})
            except:
                pass
        check_setuid()

        # 系统启动项检测
        def check_startup():
            suspicious, malice = False, False
            try:
                init_path = ['/etc/init.d/', '/etc/rc.d/', '/etc/rc.local', '/usr/local/etc/rc.d',
                             '/usr/local/etc/rc.local', '/etc/conf.d/local.start', '/etc/inittab',
                             '/etc/systemd/system']
                for path in init_path:
                    if not os.path.exists(path): continue
                    if os.path.isfile(path):
                        content = self.analysis_file(path)
                        if content:
                            get.security_count -= 3
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 78, "topic": "backdoor", "points":3, "item": "backdoor",
                                          "name": "{}启动文件".format(path), "status": 3, "operation": "",
                                          "info": "启动文件{}存在恶意代码\n建议删除文件".format(path)})
                            malice = True
                        else:
                            get._ws.send({"progress": 78, "topic": "backdoor", "item": "backdoor",
                                          "name": "{}启动文件".format(path), "status": 1, "operation": "",
                                          "info": ""})
                    else:
                        for file in self.gci(path):
                            suspicious, malice = False, False
                            content = self.analysis_file(file)
                            if content:
                                get.security_count -= 3
                                if get.security_count < 0: get.security_count = 0
                                get._ws.send({"progress": 78, "topic": "backdoor", "points": 3, "item": "backdoor",
                                              "name": "{}启动文件".format(file), "status": 3, "operation": "",
                                              "info": "启动文件{}存在恶意代码\n建议删除文件".format(file)})
                            else:
                                get._ws.send({"progress": 78, "topic": "backdoor", "item": "backdoor",
                                              "name": "{}启动文件".format(file), "status": 1, "operation": "",
                                              "info": ""})
                return suspicious, malice
            except:
                return suspicious, malice
        check_startup()

    def get_proc_detect(self, get):
        # 判断进程的可执行文件是否具备恶意特征
        def exe_analysis():
            suspicious, malice = False, False
            try:
                if not os.path.exists('/proc/'): return suspicious, malice
                for file in os.listdir('/proc/'):
                    if file.isdigit():
                        filepath = os.path.join('%s%s%s' % ('/proc/', file, '/exe'))
                        if (not os.path.islink(filepath)) or (not os.path.exists(filepath)): continue
                        malware = self.analysis_file(filepath)
                        if malware:
                            lnstr = os.readlink(filepath)
                            get.security_count -= 3
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 82, "topic": "proc", "points":3, "item": "proc",
                                          "name": "{}进程文件".format(filepath), "status": 3, "operation": "",
                                          "info": "进程文件{}存在恶意代码\n执行【kill {}】关闭恶意进程".format(filepath, lnstr)})
                        else:
                            get._ws.send({"progress": 82, "topic": "proc", "item": "proc",
                                          "name": "{}进程文件".format(filepath), "status": 1, "operation": "",
                                          "info": ""})
                            malice = True
                return suspicious, malice
            except:
                return suspicious, malice
        exe_analysis()

        # 检测隐藏进程
        def check_hide_pro():
            suspicious, malice = False, False
            try:
                # ps获取所有pid
                p = public.ExecShell("ps -ef 2>/dev/null |awk 'NR>1{print $2}'")[0]
                pid_process = p.splitlines()
                # 所有/proc目录的pid
                if not os.path.exists('/proc/'): return suspicious, malice
                for file in os.listdir('/proc/'):
                    if file.isdigit():
                        if file not in pid_process:
                            get.security_count -= 3
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 84, "topic": "proc", "points": 3, "item": "proc",
                                      "name": "扫描进程ID{}".format(file), "status": 3, "operation": "",
                                      "info": "进程ID【{}】隐藏了进程信息，未出现在进程列表中\n建议排查后【umount /proc/{} & kill {}".format(file, file, file)})
                            malice = True
                        else:
                            get._ws.send({"progress": 84, "topic": "proc", "item": "proc",
                                          "name": "扫描进程ID{}".format(file), "status": 1, "operation": "",
                                          "info": ""})
                return suspicious, malice
            except:
                return suspicious, malice
        check_hide_pro()

        # 查询挖矿进程、黑客工具、可疑进程名称
        def keyi_analysis():
            suspicious, malice = False, False
            try:
                p = public.ExecShell("ps -efwww 2>/dev/null |grep -E 'minerd|r00t|sqlmap|nmap|hydra|aircrack'|grep -v "
                                     "'grep'|awk '{print $1\" \"$2\" \"$3\" \"$8}'")
                process = p.splitlines()
                if process:
                    for pro in process:
                        pro_info = pro.strip().split(' ', 3)
                        get.security_count -= 10
                        if get.security_count < 0: get.security_count = 0
                        get._ws.send({"progress": 86, "topic": "proc", "points": 10, "item": "proc",
                                          "name": "扫描挖矿进程及恶意进程", "status": 3, "operation": "",
                                          "info": "发现恶意进程{}\n建议执行【kill {}】关闭恶意进程".format(pro_info[3], pro_info[1])})
                else:
                    get._ws.send({"progress": 86, "topic": "proc", "item": "proc",
                                  "name": "扫描挖矿进程及恶意进程", "status": 1, "operation": "",
                                  "info": ""})
                return suspicious, malice
            except:
                return suspicious, malice
        keyi_analysis()

        # 过滤反弹shell特征
        def shell_analysis():
            suspicious, malice = False, False
            try:
                p = public.ExecShell("ps -efwww 2>/dev/null |grep -v 'grep'|awk '{print $1\" \"$2\" \"$3\" \"$8}'")[0].strip()
                process = p.splitlines()
                if process:
                    for pro in process:
                        pro_info = pro.strip().split(' ', 3)
                        if self.check_shell(pro_info[3]):
                            get.security_count -= 5
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 88, "topic": "proc", "points": 5, "item": "proc",
                                          "name": "反弹shell类进程扫描", "status": 3, "operation": "",
                                          "info": "发现反弹shell进程{}\n建议执行【kill {}】关闭恶意进程".format(pro_info[3], pro_info[1])})
                            malice = True
                else:
                    get._ws.send({"progress": 88, "topic": "proc", "item": "backdoor",
                                  "name": "反弹shell类进程扫描", "status": 1, "operation": "",
                                  "info": ""})
                return suspicious, malice
            except:
                return suspicious, malice
        shell_analysis()

    def get_history_detect(self, get):
        try:
            # 待检测的目录和文件
            file_path = ['/home/', '/root/.bash_history']
            for path in file_path:
                suspicious, malice = False, False
                if not os.path.exists(path): continue
                # 目录类，获取目录下的.bash_history文件
                if os.path.isdir(path):
                    for dir in os.listdir(path):
                        file = os.path.join('%s%s%s' % (path, dir, '/.bash_history'))
                        if not os.path.exists(file):continue
                        with open(file) as f:
                            for line in f:
                                contents = self.analysis_strings(line)
                                if not contents: continue
                                malice = True
                                break
                        if malice:
                            get.security_count -= 3
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 90, "topic": "history", "points": 3, "item": "history",
                                          "name": "扫描{}用户历史操作".format(dir), "status": 3, "operation": "",
                                          "info": "发现{}中存在恶意命令{}".format(file, contents.replace('"', "”"))})
                        else:
                            get._ws.send({"progress": 90, "topic": "history", "item": "history",
                                          "name": "扫描{}用户历史操作".format(dir), "status": 1, "operation": "",
                                          "info": ""})
                # 文件类，进行文件的操作分析
                else:
                    suspicious, malice = False, False
                    with open(path) as f:
                        for line in f:
                            contents = self.analysis_strings(line)
                            if not contents: continue
                            malice = True
                            break
                        if malice:
                            get.security_count -= 5
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 92, "topic": "history", "points": 5, "item": "history",
                                          "name": "扫描root用户历史操作", "status": 3, "operation": "",
                                          "info": "发现{}中存在恶意命令{}".format(path, contents.replace('"', "”"))})
                        else:
                            get._ws.send({"progress": 92, "topic": "history", "item": "history",
                                          "name": "扫描root用户历史操作", "status": 1, "operation": "",
                                          "info": ""})
        except:
            pass

    def get_log_detect(self, get):
        # 排查secure SSH的爆破记录
        def check_sshlog():
            files = [os.path.join('/var/log/', i) for i in os.listdir('/var/log/') if
                     (not os.path.isdir(i)) and ('secure' in i)]
            if not files:
                get._ws.send({"progress": 94, "topic": "log", "item": "log",
                                  "name": "{}日志排查".format("secure"), "status": -1, "operation": "", "info": ""})
            for log in files:
                msg = []
                suspicious, malice = False, False
                try:
                    correct_baopo_infos = attack_detect(log)
                    if len(correct_baopo_infos) > 0:
                        for info in correct_baopo_infos:
                            user = info['user']
                            time = os.popen("date -d '" + info['time'] + "' '+%Y-%m-%d %H:%M:%S' 2>/dev/null").read().splitlines()[0]
                            ip = info['ip']
                            msg.append("主机SSH被外部爆破且成功登陆，时间：{}，攻击IP：{}，登录用户：{}".format(time, ip, user))
                            # get._ws.send({"progress": 94, "topic": "log", "points": 2, "item": "log",
                            #                   "name": "{}日志排查".format(log), "status": 2, "operation": "",
                            #                   "info": "主机SSH被外部爆破且成功登陆，时间：{}，攻击IP：{}，登录用户：{}".format(time, ip, user)})
                            malice = True
                except:
                    pass
                if malice:
                    get.security_count -= 2
                    if get.security_count < 0: get.security_count = 0
                    get._ws.send({"progress": 94, "topic": "log", "points": 2, "item": "log",
                                  "name": "{}日志排查".format(log), "status": 2, "operation": "",
                                  "info": '\n'.join(msg)})
                else:
                    get._ws.send({"progress": 94, "topic": "log", "item": "log",
                                  "name": "{}日志排查".format(log), "status": 1, "operation": "", "info": ""})

        def attack_detect(log):
            # 单IP错误的次数，超过此错误代表发生了爆破行为
            ip_failed_count=50
            # IP C端错误的次数，超过此错误代表发生了爆破行为
            ips_failed_count=200
            # 记录爆破成功的信息
            correct_baopo_infos = []
            # 账户错误特征
            username_error = 'Invalid user'
            # 账户正确密码错误特征
            username_correct = 'Failed password for'
            # 成功登陆
            username_password_correct = 'Accepted password for'
            # 所有错误登陆日志ip
            failed_ip = []
            # 登陆成功日志
            correct_infos = []
            # C端ip登陆错误日志
            failed_c_ips = []
            filename = os.path.basename(log)
            year = ''
            if 'secure-' in filename and len(filename) == 15:
                year = filename[7:11]
            # 打开日志文件
            f = open(log, 'r')

            for i in f:
                if (username_error in i) and ('from' in i) and ('sshd' in i):
                    try:
                        failed_ip.append(i.split(': ')[1].split()[4])
                    except:
                        continue
                elif (username_correct in i) and ('from' in i) and ('sshd' in i):
                    try:
                        failed_ip.append(i.split(': ')[1].rsplit()[-4])
                    except:
                        continue
                elif username_password_correct in i and ('sshd' in i):
                    ip = i.split(': ')[1].split()[5]
                    user = i.split(': ')[1].split()[3]
                    # time = i.split(' sshd[')[0]
                    time = ' '.join(i.replace('  ', ' ').split(' ', 4)[:3]) + " " + year
                    # 获取所有登陆成功的记录
                    correct_infos.append({'ip': ip, 'user': user, 'time': time})
            # 记录登陆失败攻击源IP地址和尝试次数
            # 1.1 判断是否发生了爆破行为,failed_ip_dict为存在爆破的失败ip列表:次数
            failed_ip_dict = filter(dict(Counter(failed_ip)), ip_failed_count)

            # 1.2 判断是否发生了C端类的爆破行为，
            for key in failed_ip:
                failed_c_ips.append(key.rsplit('.', 1)[0])
            failed_c_ips_dict = filter(dict(Counter(failed_c_ips)), ips_failed_count)

            # 2、判断爆破行为是否成功，
            for correct_info in correct_infos:
                for failed in failed_ip_dict:
                    if correct_info['ip'] in failed: correct_baopo_infos.append(correct_info)
                for failed in failed_c_ips_dict:
                    if correct_info['ip'].rsplit('.', 1)[0] in failed: correct_baopo_infos.append(correct_info)

            correct_baopo_infos = reRepeat(correct_baopo_infos)
            return correct_baopo_infos
        # 数组去重
        def reRepeat(old):
            new_li = []
            for i in old:
                if i not in new_li:
                    new_li.append(i)
            return new_li
        def filter(old, count):
            new_li = []
            for key in old:
                if old[key] > count:
                    new_li.append({key: old[key]})
            return new_li
        # 实现counter函数，由于某些版本不支持，又不想过多引入库
        def Counter(old):
            count_dict = dict()
            for item in old:
                if item in count_dict:
                    count_dict[item] += 1
                else:
                    count_dict[item] = 1
            return count_dict
        check_sshlog()

    def get_rootkit_detect(self, get):
        # 检测恶意so文件
        def check_bad_LKM():
            suspicious, malice = False, False
            LKM_BADNAMES = ['adore.o', 'bkit-adore.o', 'cleaner.o', 'flkm.o', 'knark.o', 'modhide.o', 'mod_klgr.o',
                            'phide_mod.o', 'vlogger.o', 'p2.ko', 'rpldev.o', 'xC.o', 'strings.o', 'wkmr26.o']
            try:
                if not os.path.exists('/lib/modules/'): return suspicious, malice
                infos = os.popen(
                    'find /lib/modules/ -name "*.o" 2>/dev/null').read().splitlines()
                if not infos:
                    get._ws.send({"progress": 98, "topic": "rootkit", "item": "rootkit",
                                          "name": "LKM内核模块", "status": 1, "operation": "",
                                          "info": ""})
                for file in infos:
                    for lkm in LKM_BADNAMES:
                        if lkm == os.path.basename(file):
                            get.security_count -= 5
                            if get.security_count < 0: get.security_count = 0
                            get._ws.send({"progress": 98, "topic": "rootkit", "points": 5, "item": "rootkit",
                                          "name": "LKM内核模块{}".format(file), "status": 3, "operation": "",
                                          "info": "匹配文件{}具有恶意特征{}\n执行【rm {}】删除rootkit文件".format(file, lkm, file)})
                        else:
                            get._ws.send({"progress": 98, "topic": "rootkit", "item": "rootkit",
                                          "name": "LKM内核模块{}".format(file), "status": 1, "operation": "",
                                          "info": ""})
            except:
                pass
        check_bad_LKM()
        # get._ws.send({"progress": 100, "topic": "rootkit", "item": "rootkit",
        #               "name": "LKM内核模块{}".format(".ko"), "status": 1, "operation": "",
        #               "info": ""})
        # get._ws.send({"progress": 100, "topic": "rootkit", "item": "rootkit",
        #               "name": "检测完毕", "status": 1, "operation": "",
        #               "info": ""})


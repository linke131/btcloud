--[[
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: 黄文良 <287962566@qq.com>
# Author: 梁凯强 <1249648969@qq.com>
#-------------------------------------------------------------------

#----------------------
# WAF防火墙 for apache
#----------------------
]]--
require 'apache2'
s=require "socket"
local cpath = "/www/server/btwaf/"
local jpath = cpath .. "rule/"
local cpath2 = "/dev/shm/"
local json = require "cjson"
local cmspath = cpath .. "cms/"
local memcached = require "memcached"
local uri,ip,ipn,request_uri,method,request_user_agent,localtime,today,cycle,endtime,limit,retry,retry_time,cache
local retry_cycle,site_cc,port_request_args,uri_request_args,server_name,site_config,config,error_rule,httpd

function read_file(name)
    fbody = read_file_body(jpath .. name .. '.json')
    if fbody == nil then
        return {}
    end
    return json.decode(fbody)
end

function cms_read_file(name,get)
    fbody = read_file_body(cmspath .. name .. '_' .. get .. '.json')
    if fbody == nil then
        return {}
    end
    return json.decode(fbody)
end


function read_file_body(filename)
	fp = io.open(filename,'r')
	if fp == nil then
        return nil
    end
	fbody = fp:read("*a")
    fp:close()
    if fbody == '' then
        return nil
    end
	return fbody
end

function get_apache_cpu()
	return tonumber(read_file_body("/dev/shm/apache.txt"))
end


function read_file_body_test(filename)
	fp = io.open(filename,'r')
	return filename
	
end

function write_file2(filename,body)
	fp = io.open(filename,'a+')
	if fp == nil then
        return nil
    end
	fp:write(body)
	fp:flush()
	fp:close()
	return true
end
function write_file(filename,body)
	fp = io.open(filename,'w')
	if fp == nil then
        return nil
    end
	fp:write(body)
	fp:flush()
	fp:close()
	return true
end

function is_ipaddr(client_ip)
	local cipn = split(client_ip,'.')
	
	if arrlen(cipn) < 4 then return false end
	for _,v in ipairs({1,2,3,4})
	do
		local ipv = tonumber(cipn[v])
		if ipv == nil then return false end
		if ipv > 255 or ipv < 0 then return false end
	end
	return true
end




function compare_ip_block(ips)
	if not ips then return false end
	if string.find(ips,':') then return false end
	ips = arrip(ips)
	if not is_max(ips,arrip("127.0.0.255")) then return false end
	if not is_min(ips,arrip("127.0.0.1")) then return false end
	return true
end


function get_client_ip()
	local client_ip = "unknown"
	if site_config[server_name] then
		if site_config[server_name]['cdn'] then
			for _,v in ipairs(site_config[server_name]['cdn_header'])
			do
				if httpd.headers_in[v] ~= nil and httpd.headers_in[v] ~= "" then
					client_ip = split(httpd.headers_in[v],',')[1]
					if not client_ip then client_ip = httpd.useragent_ip end 
					if compare_ip_block(client_ip) then
						if tostring(httpd.useragent_ip) == tostring(client_ip) then
							client_ip = httpd.useragent_ip
						else
							client_ip = httpd.useragent_ip
						end
						break;
					end
					break;
				end
			end	
		end
	end
	if (string.match(client_ip,"^%d+%.%d+%.%d+%.%d+$") == nil and string.match(client_ip,"^[%w:]+$") == nil) or client_ip == 'unknown'  then
		client_ip = httpd.useragent_ip
		if client_ip == nil then
			client_ip = "unknown"
		end
	end
	return client_ip
end

function split( str,reps )
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function(w)
        table.insert(resultStrList,w)
    end)
    return resultStrList
end

function arrip(ipstr)
	

	if type(ipstr) == "string" then
		if string.find(ipstr,':') then return ipstr end
	end
	if ipstr == 'unknown' then return {0,0,0,0} end
	iparr = split(ipstr,'.')
	iparr[1] = tonumber(iparr[1])
	iparr[2] = tonumber(iparr[2])
	iparr[3] = tonumber(iparr[3])
	iparr[4] = tonumber(iparr[4])
	return iparr
end

config = json.decode(read_file_body(cpath .. 'config.json'))
site_config = json.decode(read_file_body(cpath .. 'site.json'))

function join(arr,e)
	result = ''
	length = arrlen(arr)
	for k,v in ipairs(arr)
	do
		if length == k then e = '' end
		result = result .. v .. e
	end
	return result
end

function arrlen(arr)
	if not arr then return 0 end
	count = 0
	for _,v in ipairs(arr)
	do
		count = count + 1
	end
	return count
end

function select_rule(rules)
	if not rules then return {} end
	new_rules = {}
	for i,v in ipairs(rules)
	do 
		if v[1] == 1 then
			table.insert(new_rules,v[2])
		end
	end
	return new_rules
end

function is_site_config(cname)
	if site_config[server_name] ~= nil then
		if cname == 'cc' then
			return site_config[server_name][cname]['open']
		else
			return site_config[server_name][cname]
		end
	end
	return true
end

function get_boundary()
    local header = httpd.headers_in["content-type"]
    if not header then return nil end
    if type(header) == "table" then
        header = header[1]
    end

    local m = string.match(header, ";%s*boundary=\"([^\"]+)\"")
    if m then
        return m
    end
    return string.match(header, ";%s*boundary=([^\",;]+)")
end

function http_status(status)
	if status == 444 then status = 416 end
	httpd.status = status
end

function is_min(ip1,ip2)
	
	n = 0
	for _,v in ipairs({1,2,3,4})
	do
		if ip1[v] == ip2[v] then
			n = n + 1
		elseif ip1[v] > ip2[v] then
			break
		else
			return false
		end
	end
	return true
end

function is_max(ip1,ip2)
	n = 0
	for _,v in ipairs({1,2,3,4})
	do
		if ip1[v] == ip2[v] then
			n = n + 1
		elseif ip1[v] < ip2[v] then
			break
		else
			return false
		end
	end
	return true
end

function compare_ip(ips)
    if ip == 'unknown' then return true end
	if string.find(ip,':') then return false end
	if not is_max(ipn,ips[2]) then return false end
	if not is_min(ipn,ips[1]) then return false end
	return true
end


function write_log(name,rule)
	if not cache then cache = memcached.Connect("localhost", 11211) end
	local count = cache:get('safe_sum_'..ip)
	if count then
		cache:incr('safe_sum_'..ip,1)
	else
		cache:set('safe_sum_'..ip,1,retry_cycle)
	end
	if config['log'] ~= true or is_site_config('log') ~= true then return false end
	if error_rule then 
		rule = error_rule
		error_rule = nil
	end
	
	local logtmp = {localtime,ip,method,request_uri,request_user_agent,name,rule}
	local logstr = json.encode(logtmp) .. "\n"
	local count = cache:get('safe_sum_'..ip)
	
	if count > retry and name ~= 'cc' then
		local safe_count = cache:get('drop_sum_'..ip)
		if not safe_count then
			cache:set('drop_sum_'..ip,1,86400)
			safe_count = 1
		else
			cache:incr('drop_sum_'..ip,1)
		end
		local lock_time = retry_time * safe_count
		if lock_time > 86400 then lock_time = 86400 end
		logtmp = {localtime,ip,method,request_uri,request_user_agent,name,retry_cycle .. '秒以内累计超过'..tostring(retry)..'次以上非法请求,封锁'.. tostring(lock_time) ..'秒'}
		logstr = logstr .. json.encode(logtmp) .. "\n"
		cache:set('drop_ip_'..ip,retry + 1,lock_time)
		write_drop_ip('inc',lock_time)
	end
	write_to_file(logstr)
	inc_log(name,rule)
end

function write_drop_ip(is_drop,drop_time)
	local filename = cpath .. 'drop_ip.log'
	local fp = io.open(filename,'ab')
	if fp == nil then return false end
	local logtmp = {os.time(),ip,server_name,request_uri,drop_time,is_drop}
	local logstr = json.encode(logtmp) .. "\n"
	fp:write(logstr)
	fp:flush()
	fp:close()
	return true
end


function split2(input, delimiter)
    input = tostring(input)
    delimiter = tostring(delimiter)
    if (delimiter=='') then return false end
    local pos,arr = 0, {}
    for st,sp in function() return string.find(input, delimiter, pos, true) end do
        table.insert(arr, string.sub(input, pos, st - 1))
        pos = sp + 1
    end
    table.insert(arr, string.sub(input, pos))
    return arr
end


function inc_log(name,rule)
	local total_path = cpath .. 'total.json'
	local tbody = cache:get(total_path)
	if not tbody then
		tbody = read_file_body(total_path)
		if not tbody then return false end
	end
	local total = json.decode(tbody)
	if not total['sites'] then total['sites'] = {} end
	if not total['sites'][server_name] then total['sites'][server_name] = {} end
	if not total['sites'][server_name][name] then total['sites'][server_name][name] = 0 end
	if not total['rules'] then total['rules'] = {} end
	if not total['rules'][name] then total['rules'][name] = 0 end
	if not total['total'] then total['total'] = 0 end
	total['total'] = total['total'] + 1
	total['sites'][server_name][name] = total['sites'][server_name][name] + 1
	total['rules'][name] = total['rules'][name] + 1
	local total_log = json.encode(total)
	if not total_log then return false end
	cache:set(total_path,total_log)
	if not cache:get('b_btwaf_timeout') then
		write_file(total_path,total_log)
		cache:set('b_btwaf_timeout',1,5)
	end
end

function write_to_file(logstr)
	local filename = config["logs_path"] .. '/' .. server_name .. '_' .. today .. '.log'
	local fp = io.open(filename,'ab')
	if fp == nil then return false end
	fp:write(logstr)
	fp:flush()
	fp:close()
	return true
end

function drop_abroad()
	if ip == 'unknown' then return false end
	if not config['drop_abroad']['open'] or not is_site_config('drop_abroad') then return false end
	local cnlist = json.decode(read_file_body(cpath .. '/rule/cn.json'))
	for _,v in ipairs(cnlist)
	do
		if compare_ip(v) then return false end
	end
	http_status(config['drop_abroad']['status'])
	return true
end

function drop()
	local count = cache:get('drop_ip_'..ip)
	if not count then return false end
	if count > retry then
		http_status(config['cc']['status'])
		return true
	end
	return false
end

function cc()
	if not config['cc']['open'] or not site_cc then return false end
	local token = httpd:md5(ip .. '_' .. httpd.the_request)
	local count = cache:get(token)
	if count then
		if count > limit then
			local safe_count = cache:get('drop_sum_'..ip)
			if not safe_count then
				cache:set('drop_sum_'..ip,1,86400)
				safe_count = 1
			else
				cache:incr('drop_sum_'..ip,1)
			end
			local lock_time = (endtime * safe_count)
			if lock_time > 86400 then lock_time = 86400 end
			cache:set('drop_ip_'..ip,retry+1,lock_time)
			write_log('cc',cycle..'秒内累计超过'..limit..'次请求,封锁' .. lock_time .. '秒')
			write_drop_ip('cc',lock_time)
			http_status(config['cc']['status'])
			if not server_name then
				insert_ip_list(ip,lock_time,os.time(),'1111')
			else
				insert_ip_list(ip,lock_time,os.time(),server_name)
			end
			return true
		else
			cache:incr(token,1)
		end
	else
		cache:set(token,1,cycle)
	end
	return false
end

function return_html22(status,html)
	local html = html
	httpd.content_type = "text/html;charset=utf-8"
	httpd.status = status
	httpd:write(html)
    return apache2.DONE
end


function cc2()
	if not config['cc']['open'] or not site_cc then return false end
	if not site_config[server_name] then return false end
	if not site_config[server_name]['cc']['increase'] then return false end
	local token_cc2 = httpd:md5(ip .. '_' .. server_name)
	if cache:get(token_cc2) then  return false end
	if cc_uri_white() then
		cache:delete(token_cc2 .. '_key')
		cache:set(token_cc2,1,1)
		return false 
	end

	if security_verification(token_cc2) then return false end
	send_check_heml(token_cc2)
end

function security_verification(token_cc2)
	if not uri_request_args['btwaf'] then return false end
	check_key = cache:get(token_cc2 .. '_key')
	if uri_request_args['btwaf'] then
		cache:delete(token_cc2 .. '_key')
		cache:set(token_cc2,1,86400)
		cache:delete('drop_sum111_'..ip)
		return true
	end
	return false
end

function Sleep(n)
   local t0 = os.clock()
   while os.clock() - t0 <= n do end
end

function send_check_heml(token_cc2)
	local check_key = tostring(math.random(10000000,99999999))
	cache:set(token_cc2 .. '_key',check_key,3)
	local vargs = '&btwaf='
	local sargs = string.gsub(request_uri,'.?btwaf=.*','')
	if not string.find(sargs,'?',1,true) then vargs = '?btwaf=' end
	local safe_count = cache:get('drop_sum111_'..ip)
	if not safe_count then
		cache:set('drop_sum111_'..ip,1,endtime)
		safe_count = 1
	else
		cache:incr('drop_sum111_'..ip,1)
		safe_count = safe_count +1
	end

	if site_config[server_name]['retry'] then
		retry22=site_config[server_name]['retry'] 
	else
		retry22=6
	end

	local check_html=[[<!DOCTYPE html>
	<html>
	    <head>
	        <meta charset="utf-8" />
	        <title>正在安全检测中...</title>
	    </head>
		<style>
			#dotting{font-size:100px;width:72px;margin:10% auto 0;line-height:80px;height:80px;}
		</style>
	    <body>
			<div id="dotting"></div>
	        <div style="text-align: center; margin-top: 3%;font-size: 30px;">正在检测上网环境，即将跳转到您访问的页面</div>
	    </body>
	</html>
	<script type="text/javascript">
	window.location.href ="]] .. sargs .. vargs .. check_key .. [[";
	</script>]]
	httpd.content_type = "text/html;charset=utf8"
	httpd.status = 200
	httpd:wswrite(check_html)
	httpd:wsclose()

	if safe_count >= retry22*2 then
		
		local safe_count2,_ = cache:get('drop_ip_'..ip)
		if not safe_count2 then safe_count2=1 end
		local lock_time = (endtime * safe_count2)
		if lock_time > 86400 then lock_time = 86400 end
		if not server_name then
			insert_ip_list(ip,lock_time,os.time(),'1111')
		else
			insert_ip_list(ip,lock_time,os.time(),server_name)
		end
		cache:set('drop_ip_'..ip,retry+1,lock_time)
		write_log('cc',cycle..'秒内累计超过'..limit..'次请求,封锁' .. lock_time .. '秒')
		write_drop_ip('cc',lock_time)
		http_status(config['cc']['status'])

		return true
	-- write_log('cc','累计超过'..retry22..'次验证失败,封锁' .. endtime .. '秒')
		-- write_drop_ip('cc',endtime)
	end
end


function scan_black()
	if not config['scan']['open'] or not is_site_config('scan') then return false end
	local scan_black_rules = read_file('scan_black')
	if is_match(scan_black_rules['cookie'],httpd.headers_in['cookie'],false) then
		write_log('scan','regular')
		http_status(config['scan']['status'])
		return true
	end
	if is_match(scan_black_rules['args'],request_uri,false) then
		write_log('scan','regular')
		http_status(config['scan']['status'])
		return true
	end

	if is_match(scan_black_rules['header'],httpd.headers_in['user-agent'],false) then
		write_log('scan','regular')
		http_status(config['scan']['status'])
		return true
	end
	return false
end

function ip_black()
	local ip_black_rules = read_file('ip_black')
	for _,rule in ipairs(ip_black_rules)
	do
		if compare_ip(rule) then 
			http_status(config['cc']['status'])
			return true 
		end
	end
	return false
end

function ip_white()
	local ip_white_rules = read_file('ip_white')
	for _,rule in ipairs(ip_white_rules)
	do
		if compare_ip(rule) then 
			return true 
		end
	end
	return false
end

function url_white()
	if httpd.document_root=='/www/server/phpmyadmin' then return true end
	local url_white_rules = read_file('url_white')
	if is_match(url_white_rules,request_uri,false) then
		url_data=split2(request_uri,'?')
        if not url_data then url_data=request_uri end 
        if not url_data[1] then 
            url_data=request_uri 
        else
            url_data=url_data[1]
        end
        if httpd:regex(url_data,'/\\.\\./',0x01) then return false end 
        return true
	end
	if site_config[server_name] ~= nil then
		if is_match(site_config[server_name]['url_white'],request_uri,false) then
			url_data=split2(request_uri,'?')
	        if not url_data then url_data=request_uri end 
	        if not url_data[1] then 
	            url_data=request_uri 
	        else
	            url_data=url_data[1]
	        end
	        if httpd:regex(url_data,'/\\.\\./',0x01) then return false end 
			return true
		end
	end

	return false
end

function url_black()
	local url_black_rules = read_file('url_black')
	if is_match(url_black_rules,request_uri,false) then
		http_status(config['get']['status'])
		return true
	end
	return false
end

function head()
	if method ~= 'HEAD' then return false end
	local head_white_rules = read_file('head_white')
	for _,v in ipairs(head_white_rules)
	do
		if httpd:regex(uri,v,0x01) then
			return false
		end
	end
	spiders = {'spider','bot'}
	for _,v in ipairs(spiders)
	do
		if httpd:regex(httpd.headers_in['user-agent'],v,0x01) then
			return false
		end
	end
	write_log('head','禁止HEAD请求')
	cache:set(ip,retry,endtime)
	write_drop_ip('head',endtime)
	http_status(416)
end

function user_agent()
	if not config['user-agent']['open'] or not is_site_config('user-agent') then return false end
	local user_agent_rules = select_rule(read_file('user_agent'))
	if is_match(user_agent_rules,httpd.headers_in['user-agent'],'user_agent') then
		write_log('user_agent','regular')
		return_html(config['user-agent']['status'],'user-agent')
		return true
	end
	return false
end

function post()
	if not config['post']['open'] or not is_site_config('post') then return false end	
	if method ~= "POST" then return false end
	local post_rules = select_rule(read_file('post'))
	if is_match(post_rules,port_request_args,'post') then
		write_log('post','regular')
		return_html(config['post']['status'],'post')
		return true
	end
	return false
end



function post_data()
	if method ~= "POST" then return false end
	content_length=tonumber(httpd.headers_in['content-length'])
	if not content_length then return false end
	max_len = 256 * 1024
	if content_length > max_len then return false end
	local boundary = get_boundary()
	if boundary then
		if not port_request_args then return false end
		local tmp = httpd:regex(port_request_args,[[filename=\"(.+)\.(.*)\"]],0x01)
		if not tmp then return false end
		if not tmp[2] then return false end
		disable_upload_ext(tmp[2])
	end
	return false
end

function cookie()
	if not config['cookie']['open'] or not is_site_config('cookie') then return false end
	if not httpd.headers_in['cookie'] then return false end
	local cookie_rules = select_rule(read_file('cookie'))
	request_cookie = string.lower(httpd.headers_in['cookie'])
	if is_match(cookie_rules,request_cookie,'cookie') then
		write_log('cookie','regular')
		return_html(config['cookie']['status'],'cookie')
		return true
	end
	return false
end

function args()
	if not config['get']['open'] or not is_site_config('get') then return false end
	local args_rules = select_rule(read_file('args'))
	if is_match(args_rules,uri_request_args,'args') then
		write_log('args','regular')
		return_html(config['get']['status'],'get')
		return true
	end
	return false
end

function url()
	if not config['get']['open'] or not is_site_config('get') then return false end
	local url_rules = select_rule(read_file('url'))
	if is_match(url_rules,uri,'url') then
		write_log('url','regular')
		return_html(config['get']['status'],'get')
		return true
	end
	return false
end

function php_path()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['disable_php_path'])
	do
		if httpd:regex(uri,rule .. ".*\\.php$",0x01) then
			write_log('php_path','regular')
			return_html(config['other']['status'],'other')
			return true
		end
	end
	return false
end

function url_path()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['disable_path'])
	do
		if httpd:regex(uri,rule,0x01) then
			write_log('path','regular')
			return_html(config['other']['status'],'other')
			return true
		end
	end
	return false
end

function url_ext()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['disable_ext'])
	do
		if httpd:regex(uri,"\\."..rule.."$",0x01) then
			write_log('url_ext','regular')
			return_html(config['other']['status'],'other')
			return true
		end
	end
	return false
end

function url_rule_ex()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['url_rule'])
	do
		if httpd:regex(uri,rule[1],0x01) then
			if is_match(rule[2],uri_request_args,false) then
				write_log('url_rule','regular')
				return_html(config['other']['status'],'other')
				return true
			end
			
			if method == "POST" and port_request_args ~= nil then 
				if is_match(rule[2],port_request_args,'post') then
					write_log('post','regular')
					return_html(config['other']['status'],'other')
					return true
				end
			end
		end
	end
	return false
end

function url_tell()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['url_tell'])
	do
		if httpd:regex(uri,rule[1],0x01) then
			if uri_request_args[rule[2]] ~= rule[3] then
				write_log('url_tell','regular')
				return_html(config['other']['status'],'other')
				return true
			end
		end
	end
	return false
end

 
function continue_key(key)
	key = tostring(key)
	if string.len(key) > 64 then return false end;
	local keys = {"content","contents","body","msg","file","files","img","newcontent","message","subject",""}
	for _,k in ipairs(keys)
	do
		if k == key then return false end;
	end
	return true;
end

function is_match(rules,sbody,rule_name)
	if rules == nil or sbody == nil or type(sbody) == "boolean" then return false end
	if type(sbody) == "table" then
		if str_json_decode(json.encode(sbody)) then
			for k,body in pairs(sbody)
				do
					if continue_key(k) then
						for i,rule in ipairs(rules)
						do
							if site_config[server_name] and rule_name then
								local n = i - 1
								for _,j in ipairs(site_config[server_name]['disable_rule'][rule_name])
								do
									if n == j then
										rule = ""
									end
								end
							end
							
							if (#k) >500 then
							error_rule = "参数名超过500已被系统拦截"
							return true
							end
							
							if (#body) >7000 then
							
							error_rule = k.."参数值超过7000已被系统拦截"
							return true
							end
							
							
							if body and rule ~="" then
								if type(body) =="table" then
									for _,v2 in ipairs(body) 
									do
										if httpd:regex(httpd:unescape(v2),rule,0x01) then
											error_rule = rule .. ' >> ' ..k .. ':'..v2
											return true
										end
									end
								end
								if type(body) == "string" then
									if string.find(body,'\n') then
								   		body= string.gsub(body,'\n',' ')
									end
									if httpd:regex(body,rule,0x01) then
										error_rule = rule .. ' >> ' .. k .. ':' .. body
										return true
									end
								end
								if type(k) == "string" then
									if httpd:regex(httpd:unescape(k),rule,0x01) then
										error_rule = rule .. ' >> ' .. k
										return true
									end
								end
							end
						end
					end
				end
			end
	else	
		if type(sbody) == "string" then
			sbody = {sbody}
		end
		
		
		if type(rules) == "string" then
			rules = {rules}
		end
		
		for k,body in pairs(sbody)
		do

			if continue_key(k) then
				for i,rule in ipairs(rules)
				do
					if site_config[server_name] and rule_name then
						local n = i - 1
						for _,j in ipairs(site_config[server_name]['disable_rule'][rule_name])
						do
							if n == j then
								rule = ""
							end
						end
					end
					
					if body and rule ~="" then
						if type(body) =="table" then
							for _,v2 in ipairs(body) 
							do
								if httpd:regex(httpd:unescape(v2),rule,0x01) then
									error_rule = rule .. ' >> ' ..k .. ':'..v2
									return true
								end
							end
						end
						
						
						if type(body) == "string" then
									if string.find(body,'\n') then
								   		body= string.gsub(body,'\n',' ')
									end
									if httpd:regex(body,rule,0x01) then
										error_rule = rule .. ' >> ' .. k .. ':' .. body
										return true
									end
						end
						if type(k) == "string" then
							if httpd:regex(httpd:unescape(k),rule,0x01) then
								error_rule = rule .. ' >> ' .. k
								return true
							end
						end
					end
				end
			end
		end
	end
	return false
end

function is_key(keys,values)
	if keys == nil or values == nil then return false end
	if type(values) == "string" then
		values = {values}
	end
	
	if type(keys) == "string" then
		keys = {keys}
	end
	
	for _,value in pairs(values)
	do
		if type(value) == "boolean" or value == "" then return false end
		sval = string.lower(httpd:unescape(value))
		for _,v in ipairs(keys)
        do
			if v == sval then
				return true
			end
        end
	end
	return false
end

function get_return_state(rstate,rmsg)
	result = {}
	result['status'] = rstate
	result['msg'] = rmsg
	return result
end

function get_btwaf_drop_ip()
	if not uri_request_args['ip'] or not is_ipaddr(uri_request_args['ip']) then return get_return_state(true,'格式错误') end
	local data =  cache:get('drop_ip_'..uri_request_args['ip'])
	return data
end

function remove_btwaf_drop_ip()
	if not uri_request_args['ip'] or not is_ipaddr(uri_request_args['ip']) then return get_return_state(true,'格式错误') end
	cache:delete('drop_ip_'..uri_request_args['ip'])
	cache:delete('safe_sum_'..uri_request_args['ip'])
	cache:delete('drop_sum_'..uri_request_args['ip'])
	return get_return_state(true,uri_request_args['ip'] .. '已解封')
end

function min_route()
	if httpd.useragent_ip ~= '127.0.0.1' then return false end
	if uri == '/get_btwaf_drop_ip' then
		return_message(200,get_btwaf_drop_ip())
		return true
	elseif uri == '/remove_btwaf_drop_ip' then
		return_message(200,remove_btwaf_drop_ip())
		return true
	end
	return false
end
  



function return_message(status,msg)
	httpd.content_type = "application/json;charset=utf-8"
	httpd.status = status
	httpd:write(json.encode(msg))
    return apache2.DONE
end


function return_html(status,rname)
	local html = read_file_body(config["reqfile_path"] .. '/' .. config[rname]["reqfile"])
	httpd.content_type = "text/html;charset=utf-8"
	httpd.status = status
	httpd:write(html)
    return apache2.DONE
end

function get_server_name()
	local c_name = httpd.server_name
	local my_name = cache:get(c_name)
	if my_name then return my_name end
	local tmp = read_file_body(cpath .. '/domains.json')
	if not tmp then return c_name end
	local domains = json.decode(tmp)
	for _,v in ipairs(domains)
	do
		for _,d_name in ipairs(v['domains'])
		do
			if c_name == d_name then
				cache:set(c_name,v['name'],3600)
				return v['name']
			end
		end
	end

	local tconf = httpd:activeconfig()
	if not tconf then return c_name end
	local tmp = split(tconf[1].file,'/')
	return string.gsub(tmp[arrlen(tmp)],'.conf$','')
end

function init_mem()
	method = httpd.method
	uri = httpd.uri
	ip = get_client_ip()
	ipn = arrip(ip)
	request_uri = httpd:unescape(httpd.unparsed_uri)
	method = httpd.method
	request_user_agent = tostring(httpd.headers_in['user-agent'])
	localtime = os.date("%Y-%m-%d %X")
	today = os.date("%Y-%m-%d")
	error_rule = nil
	
	cycle = config['cc']['cycle']
	endtime = config['cc']['endtime']
	limit = config['cc']['limit']
	retry = config['retry']
	retry_time = config['retry_time']
	retry_cycle = config['retry_cycle']
	site_cc = is_site_config('cc')
	if site_config[server_name] and site_cc then
		cycle = site_config[server_name]['cc']['cycle']
		endtime = site_config[server_name]['cc']['endtime']
		limit = site_config[server_name]['cc']['limit']
	end

	if site_config[server_name] then
		retry = site_config[server_name]['retry']
		retry_time = site_config[server_name]['retry_time']
		retry_cycle = site_config[server_name]['retry_cycle']
	end
end

function str_json_decode( str )
    local ok, t = pcall(_json_decode, str)
    if not ok then
      return nil
    end
    return t
end

function get_content_type222()
    local header = httpd.headers_in["content-type"]
    if not header then return false end
    if type(header) == "table" then
        header = header[1]
    end
	local tmp = httpd:regex(header,'application/json',0x01)
	if tmp then 
			
		return true
	end
	return false
end
function body_chekc222(data)
	ret22={}
	local ff = split(data,'=')
	local ee = ""
	local key = '1'
	for i,k in ipairs(ff)
	do
		local dd = "="
		if i ~= 1 then
			if i == 2 then dd = "" end
			ee = ee .. dd .. k
		else
			key = k
		end
	end
	table.insert(ret22,key)
	table.insert(ret22,ee)
	return ret22
end

function post_chekc_data(data)
	local boundary = get_boundary()
	if boundary then return false end
	if type(data) == 'table' then return false end
	if not data then return false end
	if not get_content_type222() then
	ret={}
	liang=split(data,"&")
	for i,v in ipairs(liang)
		do	
			liang2=body_chekc222(v)
			if ret[liang2[1]] ~= nil then
					if type(ret[liang2[1]])=='table' then
						if liang2[2] == nil then
							table.insert(ret[liang2[1]],'111')
						else
							table.insert(ret[liang2[1]],liang2[2])
						end
					else
						ret2={}
						if type(ret[liang2[1]])=='string' then table.insert(ret2,ret[liang2[1]]) end
						if liang2[2] == nil then
							table.insert(ret2,'111')
						else
							table.insert(ret2,liang2[2])
						end
						ret[liang2[1]]=ret2
					end
			else
				if liang2[2] == nil then
					ret[liang2[1]]=111
				else
					ret[liang2[1]]=liang2[2]	
				end
			end
		end
	end
	return ret
end

local function _json_decode(str)
  return json.decode(str)
end

function str_json_decode( str )
    local ok, t = pcall(_json_decode, str)
    if not ok then
      return nil
    end
    return t
end

function post_c(body)
    body=httpd:unescape(body)
	if post_data2222(body) then return apache2.DONE end
	local post_rules = select_rule(read_file('post'))
	if  not get_content_type222() then 
		body_data=post_chekc_data(body)
		if body_data then
			body=body_data
		end
	end
	if is_match(post_rules,body,'post') then
		write_log('post','regular')
		return_html(config['post']['status'],'post')
		return true
	end
	return false

end



function disable_upload_ext(ext)
	if not ext then return false end
	ext = string.lower(ext)
	if not site_config[server_name] then return false end
	if is_key(site_config[server_name]['disable_upload_ext'],ext) then
		write_log('upload_ext','上传扩展名黑名单')
		return_html('416','other')
		return true
	end
	return false 
end

function chekc_data(body)
	if is_match('<?php',body,false) then
		return true
	end
	if is_match('language=\"php',body,false) then
		return true
	end
	return false
end

function post_data2222(body)
	if method ~= "POST" then return false end
	content_length=tonumber(httpd.headers_in['content-length'])
	if not content_length then return false end
	max_len = 256 * 10240000
	if content_length > max_len then return false end
	local boundary = get_boundary()
	if boundary then
		if not body then return false end
		local tmp = httpd:regex(body,[[filename=\"(.+)\.(.*)\"]],0x01)
		if not tmp then return false end
		if not tmp[2] then return false end
		if disable_upload_ext(tmp[2]) then
			return apache2.DECLINED
		end
		if chekc_data(body) then
			write_log('upload_ext','上传可疑文件')
			return apache2.DECLINED
		end
	end
	return false
end


function  post_cms(body)
    server_name = string.gsub(get_server_name(),'_','.')
    local return_cms_str=return_cms(server_name)
	local get='post'
	if return_cms_str ~= null then
        local cms_path=cms_read_file(return_cms_str,get)
        if arrlen(cms_path) ~= 0 then
            if return_cms_str ~=nil or return_cms_str ~=0 then
                    local cms_rule = select_rule(cms_read_file(return_cms_str,get))
                    if is_match(cms_rule,body,'post') then
                        write_log('post','regular')
                        return_html(config['post']['status'],'post')
                        return true
                    end
                    return false
                end
                return false
            end
            return false
    end
    return false
end

function return_cms(server_name)
	local cms_list = read_file_body(cpath .. '/domains2.json')
	if cms_list then
		local cms_json = json.decode(cms_list)
		for v,k in ipairs(cms_json)
		do 	
			for _,k2 in ipairs(k["domains"])
				do
				if server_name == k2
					then
					return k["cms"]
				end
			end

		end
	end
end


function cms_continue_key(key)
	key = tostring(key)
	if string.len(key) > 64 then return false end;
	local keys = {"content","contents","body","msg","file","files","img","newcontent","message","subject",""}
	for _,k in ipairs(keys)
	do
		if k == key then return false end;
	end
	return true;
end



function is_is_ngx_match(rules,sbody,rule_name)
	if rules == nil or sbody == nil then return false end
	if type(sbody) == "string" then
		sbody = {sbody}
	end
	
	if type(rules) == "string" then
		rules = {rules}
    end
    
	for k,body in pairs(sbody)
    do  
		if cms_continue_key(k) then
			for i,rule in ipairs(rules)
			do
				if site_config[server_name] and rule_name then
					local n = i - 1
					for _,j in ipairs(site_config[server_name]['disable_rule'][rule_name])
					do
						if n == j then
							rule = ""
						end
					end
				end
				
				if body and rule ~="" then
					if type(body) == "string" then
						if httpd:regex(httpd:unescape(body),rule,0x01) then
							error_rule = rule .. ' >> ' .. k .. ':' .. body
							return true
						end
					end
					if type(k) == "string" then
						if httpd:regex(httpd:unescape(k),rule,0x01) then
							error_rule = rule .. ' >> ' .. k
							return true
						end
					end
				end
			end
		end
	end
	return false
end


function cms_rule(name,get)
    if not config['get']['open'] or not is_site_config('get') then return false end
    local cms_rule = select_rule(cms_read_file(name,get))
    if referer() then return true end 
	if is_match(cms_rule,uri_request_args,'args') then
	    write_log('cms_rule_args','regular')
		return_html(config['get']['status'],'get')
		return true
	end
	return false
end



function post_referer()
	local args_rules = select_rule(read_file('referer'))
	if is_match(args_rules,httpd.headers_in['Referer'],'post') then
		write_log('referer','regular')
		return_html(config['get']['status'],'get')
		return true
	end

	return false
end

function referer()
	if not config['get']['open'] or not is_site_config('get') then return false end
	local args_rules = select_rule(read_file('referer'))
	if is_match(args_rules,httpd.headers_in['Referer'],'args') then
		write_log('referer','regular')
		return_html(config['get']['status'],'get')
		return true
	end
	return false
end

function get_zhizu_list()
	fbody=read_file_body(cpath .. 'zhi.json')
	if fbody == nil then
        return nil
    end
    return json.decode(fbody)
end

function ua_whilie(ua)
		ua_list2=get_zhizu_list() 
		if ua_list2 ~= nil then
			for _,k in ipairs(ua_list2['continue'])
			do
					if k ~= nil then
						local ua=string.find(tostring(ua),tostring(k))
						if ua ~= nil then
							return true
						end
					end
			end
		end
end

function  host_pachong(ip,id,ua_key)
	if  ip==nil then return 33 end
	if id==nil then return 33 end
	if ua_key == nil then return 33 end
	key_id=cache:get(id..'__lock_____1111')
	if key_id == nil then 
		cache:set(id..'__lock_____1111',1)
		data11111=s.dns.tohostname(tostring(ip))
		if not data11111 then 
			cache:delete(id..'__lock_____1111')
			return 33
		end
		types=string.find(string.lower(data11111),string.lower(ua_key))
		if types~=nil then
			pachong=get_zhizu_json(id)
			pachong=json.decode(pachong)
			table.insert(pachong,ip)
			save_data_on(id,pachong)
			cache:delete(id..'__lock_____1111')
			return 2
		else
			cache:delete(id..'__lock_____1111')
			return 33
		end
		cache:delete(id..'__lock_____1111')
	else
		return 1
	end
	
end


function zhizu_ua_chkec(ua)
	ua_list=cache:get('zhi_list')
	if not ua_list  then get_zhizu_list() end

	ua_list2=cache:get('zhi_list')
	if ua_list2 ~= nil then
		ua_list2 = json.decode(ua_list2)
		for _,k in ipairs(ua_list2['types'])
		do
				if k['ua_key'] ~= nil then
					local fa=string.find(string.lower(tostring(ua)),string.lower(tostring(k['ua_key'])))
					if fa ~= nil then
						return k['id']
					end
				end
		end
	end
end

function fei_zhizu_check(ip)
	ret=cache:get('fei_pachong'..ip)
	if not ret then
		return false
	else
		return true
	end
end


function get_zhizu_json(name)
	data = read_file_body(cpath .. tostring(name) ..'.json')
	if not data then 
			data={}
	end 
	return data
end


function save_data_on(name,data)
	local extime=18000
	data=json.encode(data)
	cache:set(cpath .. name,data,extime)
	if not cache:get(cpath .. name .. '_lock') then
		cache:set(cpath .. name .. '_lock',1,5) 
		write_file(cpath .. name .. '.json',data)
	end
end

function get_ua_key(id)
	zhizu_list=get_zhizu_list()
	if not zhizu_list then return false end
	for _,k in ipairs(zhizu_list['types'])
	do 	

		if tostring(id) == tostring(k['id']) then
			return k['host_key']
		end
	end

end

function zhizu_chekc(name,ip)
	data=get_zhizu_json(name)
	cache:set(cpath .. name,data,1800)
	for _,k in ipairs(json.decode(data))
	do
		if tostring(k) == tostring(ip) then 
			return true
		end
	end
end


function reptile_entrance(ua,ip)
	ua_whilie_check=ua_whilie(ua)
	if  ua_whilie_check then return 14 end
	reptile_id=zhizu_ua_chkec(ua)
	if not reptile_id then return 4 end 
	get_ua_key22=get_ua_key(reptile_id)
	if not get_ua_key22 then return 16 end
	if fei_zhizu_check(ip) then return 33 end
	if tonumber(reptile_id) == 3 then 
		if zhizu_chekc(reptile_id,ip) then
			return 2 
		else
			return 33
		end
	end
	-- 查看是否是蜘蛛
	if zhizu_chekc(reptile_id,ip) then
		return 2
	else
		ret=host_pachong(ip,reptile_id,get_ua_key22)
		return ret
	end
end


function select_rule_cms(rules)
	if not rules then return {} end
	new_rules = {}
	for i,v in ipairs(rules)
	do 	
	    print(v[1])
		new_rules[v[1]] = v[2]
		
	end
	return new_rules
end

-- CMS白名单
function  cms_url_white(cms)
	fbody = read_file_body('/www/server/btwaf/cms/'.. cms ..'_white.json')
    if fbody == nil then
        return {}
	end
	if is_match(json.decode(fbody) ,request_uri,false) then
		return true
	end
end


function cms_is_ngx_match(cms_rules,uri,request_args,rules)
	if cms_rules == nil or uri == nil  or request_args == nil or rules == nil then return false end
    if type(rules) == "string" then
		rules = {rules}
    end
    if type(request_args) == "string" then
		request_args = {request_args}
	end
    --uri=ngx.unescape_uri(uri)
    if cms_rules[uri] ~= nil then
        
        for _,body in pairs(split(cms_rules[uri],'|'))
        do  
            if request_args[body] ~= nil then
                for _,v in pairs(rules)
                do 
                	for k,value in pairs(request_args) 
                	do 
                		if k == body then
                			--return return_message(200,v) 
                			if httpd:regex(httpd:unescape(request_args[body]),v,0x01) then
	                        	return true
	                    	end
                		end
	               
	                end
                	
                end
            end
                
        end
    end   
    return false
end

function rules_cms_read_file(name)
    fbody = read_file_body('/www/server/btwaf/cms/'.. name ..'.json')
    if fbody == nil then
        return {}
    end
    return fbody
end 


function is_chekc_table(data,strings)
	if type(data) ~= 'table' then return 1 end 
	if not data then return 1 end
	data=chekc_ip_timeout(data)
	for k,v in pairs(data)
    do
        if strings ==v['ip'] then
            return 3
        end
    end
    return 2
end

-- 判断该IP 是否已经过期
function chekc_ip_timeout(ip_data)
	resutl=false
	local ret_time=os.time()-180
	for k,v in pairs(ip_data)
	do
		if (v['time']+v['timeout'])<ret_time then
			table.remove(ip_data,k)
			result=true
		end
	end
	if result then
		local extime=18000
		name='stop_ip'
		data=json.encode(ip_data)
		cache:set(cpath2 .. name,data,extime)
		locak_file=read_file_body(cpath2 .. 'stop_ip2.lock')
		if not locak_file then
				write_file(cpath2 .. 'stop_ip2.lock','1')
		end
	end
	return ip_data
end

function insert_ip_list(ip,time,timeout,server_name)
		if time == nil then time=60 end
		if time<=10 then return false end
        if not cache:get(cpath2 .. 'stop_ip') then
            ip_data=json.decode(read_file_body(cpath2..'stop_ip.json'))
            if not ip_data then return false end
     		result=is_chekc_table(ip_data,ip)
     		if result ==1 then 
     			local myAlldataList={}
                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
                ip_data={}
                table.insert(ip_data,testData2)
                save_ip_on(ip_data)
                --data=json.encode(ip_data)
            	--write_file(cpath..'stop_ip.json',data)

     		elseif result==2 then 
     			local myAlldataList={}
                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
                table.insert(ip_data,testData2)
                save_ip_on(ip_data)
           	elseif result ==3 then
            	for k,v in pairs(ip_data)
			    do
			        if ip ==v['ip'] then 
			            v['time']=time
			            v['timeout']=timeout
			        end
				end
			    save_ip_on(ip_data)
     		end

        else
        	ret=cache:get(cpath2 .. 'stop_ip')
        	ip_data=json.decode(ret)
        	result=is_chekc_table(ip_data,ip)
        	if result ==1 then 
         			local myAlldataList={}
	                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
	                ip_data={}
	                table.insert(ip_data,testData2)
	                save_ip_on(ip_data)

        	elseif  result==2 then 
         			local myAlldataList={}
	                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
	                table.insert(ip_data,testData2)
	                save_ip_on(ip_data)

	        elseif result == 3 then
	            	for k,v in pairs(ip_data)
				    do
				        if ip ==v['ip'] then 
				            v['time']=time
				        end
				    end
				  	save_ip_on(ip_data)
         	end
		end	
end

function save_ip_on(data)
	locak_file=read_file_body(cpath2 .. 'stop_ip.lock')
	if not locak_file then
			write_file(cpath2 .. 'stop_ip.lock','1')
	end
	name='stop_ip'
	local extime=18000
	data=json.encode(data)
	cache:set(cpath2 .. name,data,extime)
	if not cache:get(cpath2 .. name .. '_lock') then
		cache:set(cpath2 .. name .. '_lock',1,0.5)
		write_file(cpath2 .. name .. '.json',data)
	end
end


local cc_uri_white_rules = read_file('cc_uri_white')
function cc_uri_white()
	if cc_increase_static() then return true end
	if is_match(cc_uri_white_rules,uri,false) then
		return true
	end
	return false
end

function cc_increase_static()
	local keys = {"css","js","png","gif","ico","jpg","jpeg","bmp","flush","swf","pdf","rar","zip","doc","docx","xlsx"}
	for _,k in ipairs(keys)
	do
		local aa="/?.*\\."..k.."$"
		if httpd:regex(uri,aa,0x01) then
			return true
		end
	end
	return false
end



function get_config_ua_white()
   local char_string=config['ua_white']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
   -- body
end


function get_config_ua_black()
   local char_string=config['ua_black']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
   -- body
end


-- CC UA 白名单
function ua_white()
	local ua=httpd.headers_in['user-agent']
	local get_ua_list=get_config_ua_white()
	if get_ua_list then
		for __,v in pairs(get_ua_list)
		do
			if string.find(ua,v) then 

				return true
			end
		end
	end
	return false
end

-- CC UA 黑名单
function ua_black()
	local ua=httpd.headers_in['user-agent']
	local get_ua_list=get_config_ua_black()
	if get_ua_list then
		for __,v in pairs(get_ua_list)
		do
			if string.find(ua,v) then 
				http_status(config['cc']['status'])
				return true
			end
		end
	end
	return false
end







function input_filter(request_httpd)
	if request_httpd.method ~= 'POST' then return end
	httpd = request_httpd
	cache = memcached.Connect("127.0.0.1", 11211)
	if not cache then return apache2.DECLINED end
	server_name = string.gsub(get_server_name(),'_','.')
	if ua_white() then return apache2.DECLINED  end
	if ua_black() then return  apache2.DONE  end 
	if not config['open'] or not is_site_config('open') then return end
	if not config['post']['open'] or not is_site_config('post') then return end
	init_mem()
	if min_route() then return apache2.DONE end
	if ip_white() then return apache2.DECLINED end
	if ip_black() then return apache2.DONE end
	if url_white() then return apache2.DECLINED end
	if url_black() then return apache2.DONE end
	if drop() then return apache2.DONE end
	if drop_abroad() then return apache2.DONE end
	if cc() then return apache2.DONE end
	if cc2() then return apache2.DONE end
	if user_agent() then return apache2.DONE end

	if site_config[server_name] then
			if php_path() then return apache2.DONE end
			if url_path() then return apache2.DONE end
			if url_ext() then return apache2.DONE end
			if url_rule_ex() then return apache2.DONE end
			if url_tell() then return apache2.DONE end
	end
    coroutine.yield()
    while bucket do
		if post_c(bucket) then
			coroutine.yield("")
		else
			coroutine.yield(bucket)
		end
    end
    coroutine.yield("")
end



function run_btwaf(request_httpd)
	httpd = request_httpd
	cache = memcached.Connect("127.0.0.1", 11211)
	if not cache then return apache2.DECLINED end
	server_name = string.gsub(get_server_name(),'_','.')
	if ua_white() then return apache2.DECLINED  end
	if ua_black() then return  apache2.DONE  end 
	if not config['open'] or not is_site_config('open') then return apache2.DECLINED end
	uri_request_args = httpd:parseargs();
	init_mem()
	if min_route() then return apache2.DONE end
	if ip_white() then return apache2.DECLINED end
	if ip_black() then return apache2.DONE end
	if url_white() then return apache2.DECLINED end
	if url_black() then return apache2.DONE end
	if drop() then return apache2.DONE end
	if drop_abroad() then return apache2.DONE end
	ret=reptile_entrance(httpd.headers_in['user-agent'],get_client_ip())
	if ret == 2 then
		return apache2.DECLINED
	end
	if cc() then return apache2.DONE end
	if cc2() then return apache2.DONE end
	if user_agent() then return apache2.DONE end
    local return_cms_str=return_cms(server_name)
    local get='get'
    if return_cms_str == '0' then
        if referer() then return apache2.DONE end
        if cookie() then return apache2.DONE end
    else
        if return_cms_str ~= null and return_cms_str ~=0  then
            local cms_path=select_rule(cms_read_file(return_cms_str,get))
            cms_rules = select_rule_cms(json.decode(rules_cms_read_file(return_cms_str)))
            if arrlen(cms_path) ~= 0 then
            -- cms 特定规则
                if cms_is_ngx_match(cms_rules,uri,uri_request_args,cms_path) then 
                    write_log('cms_rule_args1','regular')
                    return_html(config['get']['status'],'get')
                    return apache2.DONE
                end
                if cms_url_white(return_cms_str) then return apache2.DECLINED end
                if return_cms_str ~=nil or return_cms_str ~=0 then

					if cms_rule(return_cms_str,get) then 
						return apache2.DONE
                    else
						if referer() then return apache2.DONE end
						if cookie() then return apache2.DONE end
                    end
                else
					if referer() then return apache2.DONE end
					if cookie() then return apache2.DONE end
                end
            else
				if referer() then return apache2.DONE end
				if cookie() then return apache2.DONE end
			end
		end
	end

	if args() then return apache2.DONE end
	if url() then return apache2.DONE end
	if scan_black() then return apache2.DONE end
	if site_config[server_name] then
		if php_path() then return apache2.DONE end
		if url_path() then return apache2.DONE end
		if url_ext() then return apache2.DONE end
		if url_rule_ex() then return apache2.DONE end
		if url_tell() then return apache2.DONE end
	end
	--return return_message(200,ua_black())
	return apache2.DECLINED
end

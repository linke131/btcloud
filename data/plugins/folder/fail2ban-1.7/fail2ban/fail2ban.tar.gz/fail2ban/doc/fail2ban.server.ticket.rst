fail2ban.server.ticket module
=============================

.. automodule:: fail2ban.server.ticket
    :members:
    :undoc-members:
    :show-inheritance:

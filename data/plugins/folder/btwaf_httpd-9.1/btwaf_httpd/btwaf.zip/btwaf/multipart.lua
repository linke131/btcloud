local find = string.find
local sub = string.sub
--local json = require "cjson"


function ReadFileHelper(str)
	 if type(str)~='string' then return str end
	 res = string.gsub(str, "\r", "")
	 res = string.gsub(res, "\n", "")
    return res
end


local _M = {}
local mt = { __index = _M }
local match_table = {}


local function get_boundary(header,httpd)
  if type(header) == "table" then
      header = header[1]
  end

  match_table[1] = nil
  match_table[2] = nil
  local m, err = httpd:regex(header,
                  [[;\s*boundary\s*=\s*(?:"([^"]+)"|([-|+*$&!.%'`~^\#\w]+))]],
                          "0x01", nil, match_table)
  if m then
      return m[1] or m[2]
  end
  if err then
      return nil, "bad regex: " .. err
  end
  return nil
end


function _M.new(body, content_type,httpd)
   if not content_type then
       return nil, "no Content-Type header specified"
   end

   local boundary, err = get_boundary(content_type,httpd)
   if not boundary then
      if err then
         return nil, err
      end
      return nil, "no boundary defined in Content-Type"
   end

  return setmetatable({
      start = 1,
      boundary = "--" .. boundary,
      boundary2 = "\r\n--" .. boundary,
      body = body,
      httpd=httpd,
  }, mt)
end

function _M.get_bo(self)
    return self.boundary..'--'
end 

function _M.parse_part(self)
  local start = self.start
  local body = self.body
    
  if start == 1 then
      local fr, to = find(body, self.boundary, 1, true)
      if not fr then
         return nil
      end
      -- ignore the preamble
      start = to + 1
  end
    body_data=self.body
  -- parse headers
  local fr, to = find(body_data, "\r\n\r\n", start, true)
  if not fr then
      self.start = start
      return nil, "missing header"
  end
  local header = sub(body_data, start, fr + 2)
  if self.httpd:regex(header,self.boundary,0x01) then  return true, true, true, true,true,true  end 
  start = to + 1
  match_table[1] = nil
  match_table[2] = nil
  local m, err = self.httpd:regex(header,[[Content-Disposition:.*?;\s*name\s*=\s*(?:"([^"]+)"|([-'\w]+))]], 0x01, nil, match_table)
  local name
  if m then
      name = m[1] or m[2]
  end
  
  m, err = self.httpd:regex(header,[[Content-Disposition:.*?;\s*filename\s*=\s*(?:"?([^"]+)"?|([-'\w]+))]],0x01, nil, match_table)
  local filename
  if m then
      filename = m[1] or m[2]
  end
  if not filename then 
     if not self.httpd:regex(header,'^Content-Disposition: form-data; name=".+"; filename=""') then 
         name_data=string.match(string.lower(header),[[name=(.+)]])
        if name_data then 
             if string.match(string.lower(name_data),[[name=(.+)]]) or string.match(string.lower(name_data),[[filename=(.+)]]) then 
                 return true, true, true, true,true,true  end
        end
    end 
  else
     name_data=string.match(string.lower(header),[[filename=(.+)]])
    if name_data then 
         if string.match(string.lower(name_data),[[name=(.+)]]) or string.match(string.lower(name_data),[[filename=(.+)]])  then  return true, true, true, true,true,true  end
    end
  end 
  
  local is_filename
  if not is_filename then
      is_filename = ReadFileHelper(header)
  end
  local fr, to = self.httpd:regex(header, [[^Content-Type:\s*([^;\s]+)]], 0x01)
  local mime
  if fr then
      mime = sub(header, fr, to)
  end
  fr, to = find(body_data,self.boundary2,start,true)
    
  if not fr then
      
      self.start = start
      return nil
  end
  
  local part_body = sub(body_data, start, fr - 1)
  self.start = to + 3
  --logs("\nself.start:  "..json.encode(self.start).."  \n")
  
  return part_body, name, mime, filename,is_filename,false
end

return _M
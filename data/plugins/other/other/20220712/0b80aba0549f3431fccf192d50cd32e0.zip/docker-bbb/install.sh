#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/docker_bbb

#安装
Install() {
    echo "success"
}

#卸载
Uninstall() {
    /www/server/panel/pyenv/bin/python /www/server/panel/plugin/docker_bbb/uninstall.py
    rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ]; then
    Install
elif [ "${1}" == 'uninstall' ]; then
    Uninstall
else
    echo 'Error!'
fi

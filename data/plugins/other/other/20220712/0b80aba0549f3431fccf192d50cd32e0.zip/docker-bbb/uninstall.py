import os
import json
if("inactive" in os.popen("systemctl status docker").read()):
    os.popen("systemctl start docker").read()
if(os.path.exists("/www/server/panel/plugin/docker_bbb/main.json")):
    configFile = open('/www/server/panel/plugin/docker_bbb/main.json', 'r')
    configDict = json.loads(configFile.read())
    os.popen("docker stop "+configDict['containerId'])
    os.popen("docker rm -f "+configDict['containerId'])
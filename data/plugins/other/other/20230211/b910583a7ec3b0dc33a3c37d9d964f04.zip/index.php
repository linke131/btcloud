<?php
require 'vendor/autoload.php';
//网址推送插件 v2.5
//@author 阿修罗<610176732@qq.com>
require  'common.php';
require  'SQLite.php';
require  'Log.php';
require  'sync.php';
require 'tool.php';
use QL\QueryList;
use QL\Ext\AbsoluteUrl;
use QL\Ext\Baidu;
use UAParser\Parser;
use app\Time;
use think\facade\Db;
define('CHUNK',100);
/**
 * Class bt_main
 * 宝塔实现的默认方法
 * _post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
 * 可通过_version()函数获取面板版本
 * 可通过_post('client_ip') 来获取访客IP
 * 常量说明：
 * PLU_PATH 插件所在目录
 * PLU_NAME 插件名称
 * PLU_FUN  当前被访问的方法名称
 */
class bt_main extends Common{
    use UrlTool;
	//不允许被面板访问的方法请不要设置为公有方法
    const DS = '/';
    public  function checkPhp(){
        $this->success('success');
    }
    //不允许被面板访问的方法请不要设置为公有方法
    protected $dataPath;
    protected $config;
    public $ds_file;
    public $ds_main_file;
    protected $ds_log;
    protected $config_json;
    public  $chunk;
    protected  $urls_log;
    protected  $db;
    public     $log;
    public     $post;
    public     $get;
    public     $tool;
    public  function  __construct()
    {
        $this->dataPath = PLU_PATH.'/static/';
        $this->urls_log = PLU_PATH."/static/urls.log";
        @chmod($this->dataPath,0777);
        @chmod($this->urls_log,0777);
        @chmod($this->urls_log,0777);
        @chmod(RUNTIME_DIR,0777);
        $this->ds_file =  PLU_PATH.'/console.php';
        $this->ds_main_file = PLU_PATH.'/mainconsole.php';
        $this->ds_log  =  PLU_PATH.'/static/console.log';
        $this->config_json = PLU_PATH.'/static/config.json';
        //常量定义
        define('PLUGIN_DB', __DIR__ . '/web.db');
        define('PLUGIN_NAME', 'urlpush');
        $this->db = new SQLite(PLUGIN_DB);
        //分批数量
        $this->chunk = CHUNK;
        $this->log  =  new Log();
        //注入请求
        $this->post = _post();
        $this->get =  _get();
        $this->tool = new tool();
//        $cache = new FileCache();
//        $mark = $cache->get('mark');
//        if($mark == false ){
//            $cache->set('mark',1,3);
//        }else{
//            $this->get_info();
//        }
        config_db();
    }
    function post()
    {
        return _post();
    }
    function get_gen_list()
    {
        try {
            $web =  bt_db()->select('domain','*');
            foreach ($web as $key=>$v){
                $res = db()->select('web','*',[
                    'host'=>$v['name']
                ]);
                if(!empty($res)){
                    unset($web[$key]);
                }
            }
            $web = array_values($web);
            if(empty($web)){
                throw  new Exception('本服务器域名全部配置完成，不过您可以在下面自行加入非本服务器的【自定义域名】');
            }
            $this->success('读取成功,会自动排除掉已经配置的域名哦！',$web);
        }catch(\Exception $e) {
            $this->error($e->getMessage());
        }
    }
    function get_web_list()
    {
        $this->get_info();
        $web =  bt_db()->select('domain','*');
        $this->success('success',$web);
    }
    function get_real_list()
    {
        $web =  bt_db()->select('domain','*');
        foreach ($web as $k=>$v){
            $file = LOG_PATH."/".$v['name'].'.log';
            $file1 = LOG_PATH."/".$v['name'].'-access.log';
            $res = file_exists($file)||file_exists($file1);
            if($res == false){
                unset($web[$k]);
            }
        }
        $this->success('success',$web);
    }
    function xq(){
        $param = $this->post;
        $table = 'access_log';
        $info =  db()->get($table,'*',[
           'id'=> $param['id']
        ]);
        $info['time_local'] = date('Y-m-d H:i:s',$info['time_local']);
        $ua_type = strtolower($info['ua_type']);
        $info['ua_type'] = $ua_type;
        if(preg_match("/yahoo/",$ua_type) ||  preg_match("/spider/",$ua_type) || preg_match("/bot/",$ua_type) ){
            $info['ua_type'] = $ua_type.' <a class="btlink"><i class="fa fa-bug"></i>蜘蛛爬虫</a>';
        }
        if($info['http_user_agent'] == '-'){
            $info['http_user_agent'] = '直接访问';
        }
        $this->success('success',$info);
    }
    //获取网站日志
    function fetch_detail()
    {
        $param = $this->post;
        $day = $param['day'];
        $time = new Time();
        $where['host'] = $param['host'];
        $where["ORDER"] = [
            'time_local'=>"ASC"
        ];
        switch ($day){
            case 1:
                $where["time_local[<>]"] = $time::today();
                break;
            case 2:
                $where["time_local[<>]"] = $time::yesterday();
                break;
            case 3:
                $where["time_local[<>]"] = $time::dayToNow(2);
                break;
        }
        $log =  db()->select('access_log','*',$where);
        //手动同步数据
        $sync = new Sync();
        $sync->one($param['host'],60);
        /*--end--*/
        $filename = LOG_PATH.'/'.$param['host'].'.log';
        $da = [];
        foreach ($log as $v){
            $hour = date('m月d日H',$v['time_local']);
            $da[$hour][] =$v['host'];
        }
        $dx = [];
        $x = [];
        $y = [];
        foreach ($da as $k1=>$v1){
            $x[] = $k1.':00';
            $y[] =  count($v1);
            $dx[$k1] = count($v1);
        }
        $this->success('success',[
            'x'=>$x,
            'y'=>$y
        ]);
    }
    public function get_real_path(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            $this->error('请安装php>=7.1');
        }
//        $php_version_str = substr(PHP_VERSION,0,3);
//        $php_version = str_replace('.','',$php_version_str);
        if(PHP_OS == 'Linux'){
            $os = 'Linux';
            $php_path = PLU_PATH."/../../../php/$php_version/bin/php";
        }else{
            $os = 'windows';
            $php_path = PLU_PATH."/../../../php/$php_version/php.exe";
        }

        return realpath($php_path);
    }
    function add_sync_task(){
        $path = $this->get_real_path();
        $shell = $path." ".PLU_PATH."/cron_sync.php";
        //判断是否存在定时任务
        $res =  bt_db()->select('crontab',"*",[
            'name'=>'[网址推送插件网站日志同步任务]'
        ]);
        if(!empty($res)){
            $this->error('已经存在定时任务!');
        }
        $this->success('success',[
            'shell'=>$shell
        ]);
    }
    function get_logs(){
        $param = $this->post;
        $p= $param['p'];
        $host = $param['host'];
        //手动同步数据
//        $sync = new Sync();
//        $sync->one($host,60);
        /*--end--*/
        $pageSize = 8;
        $day = $param['day'];
        $time = new Time();
        $where['host'] = $param['host'];
        switch ($day){
            case 1:
                $where["time_local[<>]"] = $time::today();
                break;
            case 2:
                $where["time_local[<>]"] = $time::yesterday();
                break;
            case 3:
                $where["time_local[<>]"] = $time::dayToNow(2);
                break;
        }
        $count = db()->count('access_log','*',$where);
//        if ( isset($param['p']) && $param['p'] >1) {
//            $pageVal = $param['p'];
//        }else {
//            $pageVal = 1;
//        }
        $start = ($p-1)*$pageSize;
        $totalPage   = ceil($count/$pageSize);
        $data = db()->select('access_log','*',[
            'AND'=>$where,
            'LIMIT' => [$start, $pageSize],
            "ORDER" => [
                'time_local'=>'DESC'
            ]
        ]);
        foreach ($data as &$v){
            $v['time_local'] =  date('Y-m-d H:i:s',$v['time_local'] );
            $ua_type = strtolower($v['ua_type']);
            if(preg_match("/yahoo/",$ua_type) ||  preg_match("/spider/",$ua_type) || preg_match("/bot/",$ua_type) ){
                $v['ua_type'] = $v['ua_type'].' <a class="btlink"><i class="fa fa-bug"></i></a>';
            }
        }
        $span = '<a class="Pnum" onclick="get_logs(1)" >首页</a>';
        $span .= $this->page($totalPage,$p);
        $span .= '<a class="Pnum" onclick="get_logs('.$totalPage.')" >尾页</a>';
        $span .= '<span class="Pcount">共'.$count.'条</span>';
        $this->success('success',[
            'data'=>$data,
            'page'=>$span
        ]);
    }
    /**
     * [page description]  分页
     * @param  [type] $sum     [总页数]
     * @param  [type] $pagenum [页数]
     * @return [type]          [description]
     */
    function page($sum,$pagenum){
        $span = "";
        if($sum > 0){
            if($pagenum <=0){$pagenum = 1;}
            if($pagenum >= $sum){$pagenum = $sum;}

            $k = $pagenum-1 <= 0 ? 1:$pagenum-1;
            $m = $sum - 6 <= 0 ?1:$sum-6;
            $pageM = $pagenum == 1?$pagenum+2:$pagenum + 1;

            if($sum - $pagenum >= 6){
                for($i = $k; $i <= $pageM; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_logs('.$i.')">'.$i.'</a>';
                }
                $span .= '<a class="Pnum"  >....</a>';
                for($i = $sum - 3; $i <= $sum; $i++){
                    $span .= '<a class="Pnum" onclick="get_logs('.$i.')" >'.$i.'</a>';
                }
            }else{
                for($i = $m; $i <= $sum; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_logs('.$i.')">'.$i.'</a>';
                }
            }
        }
        return $span;
    }

    //推送网址上的链接
    public function tsMain(){
       $param = $this->trim_arr(_post());
       $host = $param['host'];
       $url =  $param['mainurl'];
       if(empty($param['host']) || empty($param['mainurl'])){
           $this->error('域名或网址为空');
       }
       try{
           $urls = $this->getMainUrls($url);
           if(empty($urls)){
               throw new \Exception('插件爬虫无法爬取目标网址，可能被防火墙拦截或者目标网址协议不对，请到目标服务器配置防火墙或者网站的强制Https选项');
           }
           $msg =  $this->fenPush($host,$urls,false);
       }catch (\Exception $e){
           $this->error($e->getMessage());
       }
       
       if(empty($msg)){
           $this->error('抓取异常');
       }
       $this->success($msg);
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        $txt = file_get_contents(__DIR__.'/static/ms');
        if( $this->je() ){
            $this->error(base64_decode($txt),2);
        }
        if($sm<time() && $sm !== 0   ){
            $this->error(base64_decode($txt),2);
        }
    }
    function je()
    {
        @$fl =  file_get_contents(__DIR__.'/../../config/config.json');
        $fl = json_decode($fl,true);
        $kx = file_get_contents(__DIR__.'/static/je.json');
        $kx = json_decode($kx,true);
        if($fl[base64_decode($kx['k'])] == base64_decode($kx['lv']) ){
            return true;
        }
        return false;
    }
    //抓取链接
    function getMainUrls($url){
        try{
            $ql = QueryList::getInstance();
            $ql->use(AbsoluteUrl::class,'absoluteUrl','absoluteUrlHelper');
            $urls = $ql->get($url,[],[
                'Referer' => 'https://www.waytomilky.com/',
                'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1',
            ])
                ->absoluteUrl($url)
                ->find('a')
                ->attrs('href');
            return $urls->all();
        }catch (\Exception $e){
            return [];
        }
    }
    
    public function getMainPath(){
        $this->json([
            'path'=>$this->ds_main_file,
            'dir'=> PLU_PATH
        ]);
    }
    
    public function getPath(){
        $this->json([
            'path'=>$this->ds_file,
            'dir'=> PLU_PATH,
            'php_path'=>$this->get_php_path()
        ]);
    }
    //获取域名列表
    public function  get_hosts(){
        $this->get_info();
        $config =  $this->get_config_json();
        $str = '';
        foreach ($config as  $key=> $v){
            if(empty($v)){
                continue;
            }
            $str .= "<option value='".$key."'>".$key."</option>";
        }
        $this->success('success', ['options'=>$str]);
    }
    //获取json数据
    public function json($data){
        echo json_encode($data);
        exit;
    }
    protected function success($msg = 'success',$data = null){
        $this->json([
            'code'=>0,
            'msg'=>$msg,
            'data'=>$data
        ]);
    }
    protected function error($msg,$code = -1){
        $this->json([
            'code'=>$code,
            'msg'=>$msg,
        ]);
    }
    function getHtml($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    
    function switchXml2arr($sitemap_url){
        //$content =  $this->getHtml($sitemap_url);
        $content =  $this->getHtml($sitemap_url);
        //$obj = new SimpleXMLElement($content);
        $xml = simplexml_load_string($content , 'SimpleXMLElement' , LIBXML_NOCDATA );
        $jsonStr = json_encode($xml);
        $xml_data = json_decode($jsonStr,true);
    
        foreach ($xml_data['url'] as $key => $value) {
            $urls[] =  $value['loc'];
        }
        return $urls;
    }

    function  mpush(){
        $param =  _post();
        if(empty($param['host']) || empty($param['sitemap_url']) ){
            $this->error('请选择域名和输入sitemap远程地址');
        }

        $urls = [];
        //$content = file_get_contents($param['sitemap_url']);
        $urls = $this->switchXml2arr($param['sitemap_url']);
        if(empty($urls)){
            $this->error('请检查sitemap.xml格式是否合法');
        }

//        try{
//
//        }catch (\Exception $e){
//            $this->error('非规范xml地图格式');
//        }
      
        //分批推送
        $msg = $this->fenPush($param['host'],(array)$urls);
        $this->success($msg);
    }
    
    
    //写入urls.log
    function save_urls_log($host,array $urls){
        file_put_contents($this->dataPath."/".$host,serialize($urls) );
    }
    
    //获取推送过的地址
    function get_urls_arr($host){
        $info = file_get_contents($this->dataPath."/".$host);
        return unserialize($info);
    }
    
    
    //是否上次推送
    function get_last_push($host){
        if(!file_exists($this->dataPath."/".$host))
            return [];
        return json_decode(file_get_contents($this->dataPath."/".$host),true);
    }
    
    //处理重复网址
    function handle_repeat_urls($host,$urls){
        $last_urls = $this->get_last_push($host);
        if( empty($last_urls) )
            return $urls;
        $new_arr  = [];
        foreach ($urls as $val){
            if ( !in_array($val,$last_urls) )
                $new_arr[] = $val;
        }
        return $new_arr;
    }
    
    function write_urls($host,$urls){
        $last_push_urls = $this->get_last_push($host);
        $no_history = [];
        if(empty($last_push_urls)){
            file_put_contents($this->dataPath.self::DS.$host,json_encode($urls));
            return;
        }
        foreach ($urls as $val){
            if(!in_array($val,$last_push_urls)){
                $no_history[] = $val;
            }
        }
        if(empty($urls)){
            return;
        }
        $urls = array_merge($no_history,$last_push_urls);
        file_put_contents($this->dataPath.self::DS.$host,json_encode($urls));
    }
    function get_nei($host,$urls){
        $arr = [];
        foreach ($urls as $url){
            if(preg_match("/$host/",$url)){
                $arr[] = $url;
            }
        }
        return $arr;
    }
    function get_gl_url($host,$urls){
        $config  = $this->get_config_json();
        $new_arr = [];
        if(preg_match("/#/",$config[$host]['gl'])) {
            $gl_arr = explode("#",$config[$host]['gl']);
            foreach ($gl_arr as $val){
                foreach ($urls as $v){
                    if(preg_match("/".$val."/",$v)){
                        $new_arr[] = $v;
                    }
                }
            }
        }else{
            foreach ($urls as $v){
                if(preg_match("/".$config[$host]['gl']."/",$v)){
                    $new_arr[] = $v;
                }
            }
        }
        
        return $new_arr;
        
    }
    
    //智能推送,分批推送
    function fenPush($host,$urls,$isLog = false){
        $urls = array_unique($urls);
        //内链过滤
        $urls = $this->get_nei($host,$urls);
        
        //去重
        $config  = $this->get_config_json();
        if($config[$host]['is_push_last'] == 1){
            $urls = $this->handle_repeat_urls($host,$urls);
        }
//        if(!empty($config[$host]['gl'])){
//            $urls = $this->get_gl_url($host,$urls);
//        }
        $urls = $this->format_url($host,$urls);

        if(empty($urls)){
            return "<div class='red'>插件警告:<br>1.推送的链接全部为重复网址或者过滤后无有效网址.<br>2.请尝试修改该域名的[网址去重]和[网址过滤]设置进行调整.</div>";
        }
        
        
        
        $chunk = $this->chunk;
        $msg   = '';
        if(count($urls)>$chunk){
            $msg .= '推送总数:'.count($urls);
            $url_chunk = array_chunk($urls,$chunk);
            $i  =  0;
            foreach ($url_chunk as $value){
                $i ++;
                $msg .= "<br><b>-------------网址数量大于".$chunk.",自动启用分批推送,每批".$chunk."条,当前第".$i."批--------------</b>".$this->push_all($host,$value,true);
            }
        }else{
            $msg = $this->push_all($host,$urls,true);
        }
        
        $msg .= "<br>----------------------------我是分隔线,觉得好的话还请给个五星好评-----------------------------<br>推送网址列表:<br>";
        foreach ($urls as $url ){
            $msg.= $url."<br>";
        }
        $this->write_urls($host,$urls);
        //写入日志
        //$this->log->write_log('手动推送',$host,$urls);
       
        return $msg;
    }
    
    
    //手动推送
    function sdpush(){
        $param =  _post();
        $sd_hosts = $param['sd_hosts'];
        $config  = $this->get_config_json();
        if(empty($param['host']) || empty($sd_hosts)){
            $this->error('请选择域名和输入网址');
        }
        $sd_hosts = trim($sd_hosts);
        $host_config = $config[$param['host']];
        $urls = explode("\n",$sd_hosts);
        $msg = '';
        
        try{
            $msg = $this->fenPush($param['host'],$urls);
            $this->success($msg);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }


    }
    function baidu_push($host,$urls){
//        $token = $this->config['baidu_token'];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['zhu'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER=>0,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch),true);
    }
    function mip_push($host,$urls){
//        $token = $this->config['baidu_token'];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token."&type=mip";
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['mip'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch),true);
    }
    function sm_push($host,$urls){
//        $token  =  $this->config['sm_token'];
//        $email  =  $this->config['sm_email'];
//        $api = 'http://data.zhanzhang.sm.cn/push?site='.$host.'&user_name='.$email.'&resource_name=mip_add&token='.$token;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['shenma'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER=>0,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    function  xpush($host,$urls){
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['xiong'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    
    function tian($host,$urls){
//        $result = [
//            'success'=>10,
//            'remain'=>9,
//            "success_daily"=>1,
//            "remain_daily"=>9
//        ];
//        return $result;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['tian'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    
    
    function getlog(){
        $log =  file_get_contents($this->dataPath.'/p.log');
        return $this->success($log);
    }
    //清空日志
    function rmlog(){
        $log =  file_put_contents($this->dataPath.'/p.log','');
        return $this->success();
    }
    //保存host
    function  saveHost(){
        $param = _post();
        if(empty($param['host']) || empty($param['sitemap']) ){
            $this->error('域名或sitemap.xml地址为空');
        }
    }

    //保存host_config
    function save_host_config(){
        $data  = $this->get_config_json();
        $post = $this->trim_arr(_post());
        if(empty($post['zhu'])  || empty($post['host'] )){
            $this->error('【域名】与【百度普通收录API】不能为空');
        }
        if(!empty($post['tian']) && empty($post['xian'])){
            $this->error('百度快速收录必须填写限制数量!');
        }
        if(!empty($post['is_cron'] == '开启') &&  empty($post['url_list'] ) ){
            $this->error('开启批量任务，需要填写【抓取网址】!');
        }
        if(!empty($post['host']) && !empty($post['zhu']) || !empty($post['bing_token']) || !empty($post['xiong']) || !empty($post['shenma'])  || !empty($post['tian']) ){
            $post['host'] = str_replace(" ",'',$post['host']);
            $post['tian'] = str_replace(" ",'',$post['tian']);
            $post['zhu'] = str_replace(" ",'',$post['zhu']);
            $post['shenma'] = str_replace(" ",'',$post['shenma']);
            $post['bing_token'] = str_replace(" ",'',$post['bing_token']);
            $post['tt_cookie'] = str_replace(" ",'',$post['tt_cookie']);
            try {
                $post['create_time'] = time();
                $res = db()->select('web','*',['host[=]'=>$post['host']  ]);
                if(!empty($post['tt_cookie'])){
                    $this->sync_tt($post['tt_cookie']);
                    $jxx = TtsiteModel::where('host',$post['host'] )->find();
                    if(empty($jxx)){
                        throw new Exception('您输入的头条cookie与您的站点并未绑定，请核对！');
                    }
                }
                if(empty($res)){
                    db()->insert('web',$post);
                }
                db()->update('web',$post,[
                    'host[=]'=>$post['host']
                ]);
            }catch (\Exception $e){
                $this->error($e->getMessage());
            }
            $this->success('保存成功!');
        }
        $this->error('请输入必要数据');
    }


    public function get_pro_config(){
        $this->get_info();
        $config = $this->get_config_json();
        if(!is_array($config) && !empty($config)){
            $this->error('配置文件格式错误！请点击【配置管理】按钮，删除配置！');
        }
        //<tr><th >已配置域名</th><th >类型</th><th width='150'>操作栏【<a class='btlink' onclick='daochu()'>配置管理</a>】</th></tr>
        //【<a class='btlink' onclick='daochu()'>配置管理</a>】
        $table = "<table class='table table-hover' >
          <thead>
          <tr><th >已配置域名</th> <th>协议</th> <th >去重开关</th> <th >今日额度(推送后显示)</th>  <th>批量任务</th>  <th width='150'>操作栏</th></tr>
            </thead><tbody>
        ";
        if(!empty($config)){
            $config =  array_reverse($config);
            foreach ($config as $k=>$v){
                $type_str =  $v['is_push_last'] == 1?'开启':'关闭';
                $class = $v['is_cron']=="开启"?'btlink':'red';
                $table.= "<tr>
<td>$k</td>
<td>{$v['xieyi']}</td>
<td>$type_str</td>
<td>百度普通：".$v['zhu_remain']." 必应：{$v['bing_remain']}</td>
<td> <a style='cursor: grab' class='{$class}' onclick='sw_cron(".$v['id'].")'> 已".$v['is_cron']." </a></td>
<td>
<button onclick=bianji('".$k."') class='btn btn-primary btn-sm'>编辑</button>&nbsp;<button onclick=del('".$k."') class='btn  btn-sm btn-danger'>删除</button></td></tr>";
            }
        }
        $table .= "</tbody></table>";
        $this->success('success',['table'=>$table]);
    }


    function get_config_json(){
        $arr = db()->select('web','*');
        $data = [];
        foreach ($arr as $v){
            $host = $v['host'];
            $data[$host] = $v;
        }
        return $data;
        //return json_decode(file_get_contents($this->config_json),true);
    }

    function trim_arr($arr){
        if(empty($arr)){
            return $arr;
        }
        foreach ($arr as &$val){
            $val = trim($val);
        }
        return $arr;
    }

    function bianji(){
        $post = _post();
        $host = trim($post['host']);
        $config = $this->get_config_json();
        $this->success('success',$config[$host]);
    }

    function del(){
        $post = _post();
        $host = trim($post['host']);
        $config = $this->get_config_json();
        if(!empty($host)){
            //unset($config[$host]);
            //file_put_contents($this->config_json,json_encode($config));
            db()->delete('web', [
                "AND" => [
                    "host" => $host
                ]
            ]);
            $this->success('删除成功');
        }
    }

    function edit(){
        $post = _post();
        $host = trim($post['host']);
        $config = $this->get_config_json();
        $this->success('success',$config[$host]);
    }
    
    
    function  push_all($host,$urls,$is_log = false){
        $config  = $this->get_config_json();
        $host_config = $config[$host];
        //百度普通推送
        $msg = '';
        $log_arr = [];
        if( !empty($host_config['zhu']) ){
            $res =  $this->baidu_push($host,$urls);
            $res['not_valid'] =  count($res['not_valid']);
            if(isset($res['success'])){
                @$msg .= '<a class="btlink big-size">百度普通收录推送成功:'.$res['success'].'条,今日剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</a>';
                $log_arr['baidu'] =  $res;
                $arr2 = (!empty($res['not_same_site']) && is_array($res['not_same_site']))?$res['not_same_site']:[];
                $arr3 = (!empty($res['not_valid']) && is_array($res['not_valid']))?$res['not_valid']:[];
                $left_urls = array_diff($urls,$arr2,$arr3);
                //更新额度
//                $this->tool->add_history($host,'zhu',$urls);
                //$this->tool->add_history($host,'zhu',$left_urls);
                //更新额度
                $this->tool->update_remain($host_config['host'],'zhu_remain',$res['remain']);
            }else{
                $log_arr['baidu'] = null;
                if(preg_match("/token is not valid/",$res['message'])){
                    $res['message'] = '百度普通收录api错误，请仔细核对';
                }
                if(preg_match("/over quota/",$res['message'])){
                    $res['message'] = '百度普通收录额度超过，请明天再试';
                }
                $msg .= '<a class="red">百度普通收录推送失败:'.(isset($res['message'])?$res['message']:'').'</a>';
            }
        }
        //百度mip推送
//        if( !empty($host_config['mip'])){
//            $res =  $this->mip_push($host,$urls);
//            $res['not_valid'] =  count($res['not_valid']);
//            if(isset($res['success_mip'])){
//                if($res['success_mip'] == 0){
//                   $msg .= '百度mip推送警告:您百度mip接口没有推送额度';
//                }else{
//                    @$msg .= '<br><a class="big-size btlink">百度mip推送成功:'.$res['success_mip'].'条,今日剩余额度'.(int)$res['reamin_mip'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</a>';
//                }
//            }else{
//                $msg .= '<br>百度mip推送失败,'.(isset($res['message'])?$res['message']:'');
//            }
//        }
        
        //神马推送
        if( !empty($host_config['shenma']) ){
            $smres =  $this->sm_push($host,$urls);
            if($smres['returnCode']==200){
//                $this->tool->add_history($host,'shenma',$urls);
                $msg .= '<br><a class="btlink big-size">神马mip推送成功:'.count($urls).'条(神马官方不提供额度返回)</a>';
                $log_arr['sm'] =  count($urls);
            }else{
                $msg .= '<br><a class="red">神马mip推送失败:配置错误,'.(isset($smres['returnCode'])?$smres['returnCode']:'').'</a>';
                $log_arr['sm'] =  null;
            }
        }

        if(!empty($host_config['tian'])){
            $xian = $host_config['xian'];
            list($offset,$length) = explode('#',$xian);
            $urls = array_slice($urls,$offset,$length);
            $str = "(目标网址从第".$offset."开始,共".$length."条)";
            $tt = $this->tian($host,$urls);
            if(isset($tt['success'])){
                $msg .= '<br><a class="btlink big-size">百度快速收录推送成功:'.$tt['success'].'条'.$str.',剩余'.$tt['remain'].'条</a>';
                $msg .= "<br>快速收录推送目标网址如下:";
                foreach ($urls as $url){
                    $msg .= "<br>".$url;
                }
                if($tt['not_valid']){
                    $msg.= "<a class=btlink big-size>,其中不合法网址".count($tt['not_valid']).'条,网址如下:</a>';
                    foreach ($tt['not_valid'] as $v){
                        $msg .= "<p style='color: red'>".$v."</p>";
                    }
                }
                $log_arr['tian'] =  $tt['success_daily'];
            }else{
                $log_arr['tian'] = null;
                $msg .= '<br>百度快速收录推送失败,API配置错误或者超额 '.(isset($tt['message'])?$tt['message']:'');
            }

        }

        //必应推送
        if( !empty($host_config['bing_token']) ){
            $bing_res =  $this->bing_push($host_config,$urls);
            if($bing_res['d'] == null  && $bing_res['ErrorCode'] !== 3){
                $msg .= '<br><a class="btlink big-size">必应推送成功:'.count($urls).'条,今日剩余额度'.$bing_res['quota']['DailyQuota'].'条</a>';
                $log_arr['bing'] =  count($urls);
//                $this->tool->add_history($host_config['host'],'bing_token',$urls);
                //更新额度
                $this->tool->update_remain($host_config['host'],'bing_remain',$bing_res['quota']['DailyQuota']);
            }else{
//                if($bing_res['quota']['DailyQuota']  = 0){
//                    $msg .= '<br><a class="red">必应推送成功失败:api配置错误</a>';
//                }else{
//                    $msg .= '<br><a class="red">必应推送成功失败:今日推送额度已用完</a>';
//                }
                $bing_msg =  $bing_res['Message'];
                $msg .= '<br><a class="red">必应推送失败:api配置错误或者今日额度已用完。接口返回:'.$bing_msg.'</a>';
                $log_arr['bing'] =  null;
            }
        }

        if(!empty($host_config['tt_cookie'])){
            $tt_res = $this->tt_push($host_config,$urls);
            if($tt_res['code'] == 0){
                $msg .= '<br> <a class="btlink big-size">头条推送成功:'.count($urls).'条 </a>';
            }else{
                $msg .= '<br><a class="red">可能原因:cookie配置错误、今日额度已用完、超过每次推送数量。具体接口返回:'.$tt_res['message'].'</a>';
            }
        }
        
        if(empty($msg)){
            $this->error('至少开启一个推送类型');
        }
        
        if($is_log){
            file_put_contents($this->dataPath.'/p.log',"【手动推送】<br>推送域名:".$host."<br>推送时间:".date('Y-m-d H:i:s')."<br>推送结果:<br>".$msg.'<br>-----------------------------------------------------------------<br>',FILE_APPEND);
            
        }
        //todo 日志需要更详细的记录
        //$this->log->record('手动推送',$host,$log_arr,$urls);
        return $msg;
    }
    function  tt_push($host_config,$urls)
    {
        $url = 'https://zhanzhang.toutiao.com/webmaster/api/link/create';
        $site = TtsiteModel::where('host',$host_config['host'])->find();
        $client = new GuzzleHttp\Client();
        $data = [
            'site_id'=> $site->site_id,
            'urls'=>$urls,
            'frequency'=>86400,
            'submitMethods'=>'url'
        ];
        $res = $client->request('POST', $url, [
            'headers' => [
                'User-Agent' => UA,
                'Cookie'=>$host_config['tt_cookie'],
                'Content-Type'=>'application/json'
            ],
            'verify'=>false,
            'body'=>json_encode($data)
        ])
            ->getBody()
            ->getContents();

        return json_decode($res,true);
    }
    /**
     * Notes:  bing_push
     * Author: wenhainan
     * DateTime: 2021/4/23
     * Email: whndeweilai@gmail.com
     */
    function bing_push($host_config,$urls){
        $req_url = "https://ssl.bing.com/webmaster/api.svc/json/SubmitUrlBatch?apikey=".$host_config['bing_token'];
        $siteUrl = 'http://'.$host_config['host'];
        if(preg_match("/https/",$urls[0])){
            $siteUrl = 'https://'.$host_config['host'];
        }
        $data = [
            'siteUrl'=>$siteUrl,
            'urlList'=>$urls
        ];
        $data = json_encode($data);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $req_url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data)
            )
        );
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $res = json_decode($response,true);
        $quota = $this->get_bing_quota($siteUrl,$host_config['bing_token']);
        $res['quota'] = $quota['d'];

        return $res;
    }

    function http_post($req_url,$data,$is_json = true)
    {
        if($is_json){
            $data = json_encode($data);
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $req_url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data)
            )
        );
        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response,true);
    }
    function http_get($req_url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $req_url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8'
            )
        );
        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response,true);
    }

    function get_bing_quota($siteUrl,$bing_token)
    {
        $req_url = "https://ssl.bing.com/webmaster/api.svc/json/GetUrlSubmissionQuota?siteUrl=".$siteUrl."&apikey=".$bing_token;
        $res =  $this->http_get($req_url);
        return $res;
    }

    function about(){
        try{
            @$json = json_decode(file_get_contents('http://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    
    /**
     * @action 快速收录
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/10/12
     */
    function  ks_push_action(){
        $param =  _post();
        $sd_hosts = $param['ks_url'];
        $config  = $this->get_config_json();
        if(empty($param['host']) || empty($sd_hosts)){
            $this->error('请选择域名和输入网址');
        }
        $sd_hosts = trim($sd_hosts);
        $host_config = $config[$param['host']];
        $urls = explode("\n",$sd_hosts);
        $msg = '';
    
        //$msg = $this->fenPush($param['host'],$urls);

        $urls = array_unique($urls);
        $chunk = $this->chunk;
        
        if(empty($host_config['tian'])){
            $this->error('该域名未配置快速推送API，请前往【域名配置】配置该域名的快速推送API');
        }
        
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $host_config['tian'],
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        $result = json_decode($result,true);
        
        if( !empty($result['success']) ){
            $this->success("<b>推送成功【".$result['success']."】条,剩余额度【".$result['remain']."】条</b> <br>快速收录额度珍贵，建议推送重要网址，留意额度消耗！");
        }else{
            $this->error("【超出今日限额】或者【网址与域名不配】，请留意！".$result['message']);
        }
       
    }
    /**
     * des    收录查询
     * auther wenhainan
     * qq     610176732
     * date   2020-10-14
     */
    function slcx_action()
    {
//        $param  =  _post();
//        $keyword = 'site:'.$param['host'];
//        $ql = QueryList::getInstance();
//        $ql->use(Baidu::class);
//        $baidu = $ql->baidu(10);
//        $searcher = $baidu->search($keyword);
//        $count = $searcher->getCount(); // 获取搜索结果总条数
//        $countPage = $searcher->getCountPage();
//        $data = $searcher->setHttpOpt([
//            'headers' => [
//                'User-Agent' => 'testing/1.0',
//                'Accept'     => 'application/json',
//                'X-Foo'      => ['Bar', 'Baz']
//            ],
//            'timeout' => 60,
//        ])->page(1);
//        print_r($data->all());
        $param  =  _post();
        $ql = QueryList::getInstance();
        $ql->use(Baidu::class);
        $keyword = 'site:'.$param['host'];
        $baidu = $ql->baidu(20);
        $searcher = $baidu->search($keyword);
        $count = $searcher->getCount(); // 获取搜索结果总条数
//        $data = $searcher->setHttpOpt([
//            'headers' => [
//                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36 Edg/86.0.622.38',
//            ],
//            'timeout' => 60,
//        ])->page(1,true);
        print_r($count);
    }
    
    function slcx_gen_action(){
        $param =  _post();
        $urls =  [];
        if(empty($param['host']) || empty($param['url_rule'])){
            $this->error('请选择域名或者填写URL规则');
        }
        for($i = 1;$i<=$param['num'];$i++ ){
            $urls[] = $this->gen_url($param['xieyi'],$param['host'],$param['url_rule']);
        }
        $this->success('success',$urls);
    }
    
    function slcx_push_action(){
        $param =  _post();
        $config = $this->get_config_json();
        $sd_hosts = trim($param['slcx_textarea']);
        $host_config = $config[$param['host']];
        $urls = explode("\n",$sd_hosts);
        $msg   =  $this->fenPush($param['host'],$urls,true);
        $this->success($msg);
    }

    /**
     * des    测试加入日志方法
     * func   write_log
     * auther <闻海南>whndeweilai@163.com/610176732
     * date   2020/10/27
     * @throws Exception
     */
    function write_log(){
        $urls = [1,2,3];
        $res =  $this->log->write_log('自动推送','www',$urls);
    }

    /**
     * des    获取插件
     * func   get_plugin_path
     * auther <闻海南>whndeweilai@163.com/610176732
     * date   2020/10/27
     */
    public function get_php_path(){
        $php_version = PHP_VERSION;
        $php_version = str_replace('.','',$php_version);
        $php_version = substr($php_version,0,2);

        if(PHP_OS == 'Linux'){
            $php_path = PLU_PATH."/../../../php/$php_version/bin/php";
        }else{
            $php_path = PLU_PATH."/../../../php/$php_version/php.exe";
        }
//        if(PHP_OS == 'Linux'){
//            $php_path = PLU_PATH."/../../../php/71/bin/php";
//        }else{
//            $php_path = PLU_PATH."/../../../php/71/php.exe";
//        }

//        $this->json([
//            'path'=>$this->ds_file,
//            'dir'=> PLU_PATH,
//            'php_path'=>$php_path
//        ]);
        return realpath($php_path);
    }
    
    public function get_config_content()
    {
        $file_content =  $this->get_config_json();
        $content = json_encode($file_content);
        file_put_contents(PLU_PATH.'/static/config.json',$content);
        
        $this->success('success',[
            'content'=>$content,
            'file_path'=>'/urlpush/static/config.json',
            'file_name'=>'网址推送配置'.date('md')
        ]);
    }
    
    /**
     * @action 写入配置
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/11/15
     */
    public  function wconfig()
    {
        try {
            $param  = $this->post;
            $msg = "写入成功";
            if(empty($param['content'])){
                $msg = "已初始化配置！";
            }
            $content = json_decode($param['content'],true);
            foreach ($content as $key=>$v){
                $res = Db::name('web')->where('host',$key)->find();
                if(empty($res)){
                    unset($v['id']);
                    Db::name('web')->insert($v);
                }
            }
            $this->success($msg,[
                'content'=>$param['content']
            ]);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
       
    }
    function get_plugin_info(){
        $params = $this->post;
        $v = $params['endtime'];
        $file = __DIR__.'/static/sm';
        @chmod($file,0777);
        file_put_contents($file,$v);
        $this->success('success');
    }
    function gen_config()
    {
        try{
            $param = $this->post;
            $xieyi = $param['xieyi'];
            $baidu_token = trim($param['baidu_token']);
            $host_str = trim($param['host_str'],"\n");
            $bing_token = trim($param['bing_token']);
            $tt_cookie = trim($param['tt_cookie']);
            $is_push_last = trim($param['is_push_last']);
            $is_cron = trim($param['is_cron']);
            if(empty($baidu_token) || empty($host_str)){
                throw new Exception('请填写完整哦');
            }
            $data = [];
            $arr = explode("\n",$host_str);
            foreach ($arr as $host){
                $res = bt_db()->select('domain',"*",[
                    'name'=>$host
                ]);
                $type = !empty($res)?1:2;
                $data[] = [
                    'host'=>$host,
                    'zhu'=>"http://data.zz.baidu.com/urls?site={$xieyi}{$host}&token={$baidu_token}",
                    'type'=>$type,
                    'bing_token'=>$bing_token,
                    'is_push_last'=>$is_push_last,
                    'url_list'=>$xieyi.$host,
                    'is_cron'=>$is_cron,
                    'xieyi'=>$xieyi,
                    'tt_cookie'=>$tt_cookie
                ];
            }
            db()->insert('web',$data);

            $this->success('生成成功,请前往【域名配置】查看');
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function add_cron(){
        $php_path = $this->get_real_path();
        $cron_name = $this->post()['cron_title'];
        $is_add = Db::connect('bt_db')->table('crontab')->where('name',$cron_name)->find();
        if(!empty($is_add)){
            $this->error('批量定时任务已设置，无需重复设置！任务名：'.$cron_name.'，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看');
        }
        $this->json([
            'php_path'=>realpath($php_path),
            'path'=>PLU_PATH.'/batch_cron.php',
            'cron_name'=>$cron_name,
            'msg'=>'操作成功',
            'code'=>1
        ]);
    }
    function sw_cron()
    {
        $param = $this->post;
        $host_config =  Db::table('web')
            ->where('id',$param['id'])
            ->find();
        $is_cron =  ($host_config['is_cron'] == '开启') ? '关闭':'开启';
        Db::table('web')
            ->where('id',$param['id'])
            ->update([
                'is_cron'=>$is_cron
            ]);
        $this->success('开启/关闭 成功');
    }
    function  get_service_status()
    {
        $param = $this->post;
        $res =  $this->get_bt_db()
            ->table('crontab')
            ->where('name',$param['cron_title'])
            ->where('status',1)
            ->find();
        $this->success('success',[
            'status'=> !empty($res)?1:0
        ]);
    }
    public function get_bt_db()
    {
        return Db::connect('bt_db');
    }
    function add_sync_task_new(){
        $param = $this->post;
        $path = $this->get_real_path();
        $shell = $path." ".PLUGIN_PATH.DIRECTORY_SEPARATOR."batch_cron.php";
        //判断是否存在定时任务
        $res =  $this->get_bt_db()->table('crontab')->where('name',$param['cron_title'])->find();
        if(!empty($res)){
            $this->error('已经存在批量定时任务,无需重复添加!');
        }
        $this->success('定时任务添加成功，服务启动，默认执行时间为每天凌晨01:30',[
            'shell'=>$shell
        ]);
    }
    function test()
    {
        $this->success();
    }
    function rm_config()
    {
        db()->delete('web',[
            'id[>]'=>0
        ]);

        $this->success('删除成功');
    }
    function  api_list()
    {
        $param = $this->post;
        $model = new ApiModel();
        if(!empty($param['type'])){
            $model =  $model->where('type',$param['type']);
        }
        $data = $model->order('id desc')->select()->each(function ($item){
            $item['type_int'] = $item->getData('type');
        });

        $this->success('',$data);
    }
    function  save_api()
    {
        $param = $this->post;
        $model = new ApiModel();
        try {
            if($param['type'] == 3){
                $this->sync_tt($param['api']);
            }
            if(empty($param['id'])){
                unset($param['id']);
                $model->data($param)->save();
            }else{
                $model->update($param,[
                    'id'=>$param['id']
                ]);
            }

            $this->success('success');
        }catch (Exception $e){
            $this->error( $e->getMessage() );
        }
    }
    function  sync_tt($cookie)
    {
        $res =  $this->tt_get_web($cookie);
        foreach ($res as $item){
            $data = [
                'site_id'=>$item['id'],
                'domain'=>$item['domain'],
                'host'=>$item['host'],
                'cookie'=> $cookie
            ];
            $jx = TtsiteModel::where('cookie', $cookie)
                ->where('host',$item['host'])
                ->find();
            if(empty($jx)){
                TtsiteModel::create($data);
            }
        }
    }
    function del_api()
    {
        $param = $this->post;
        ApiModel::where('id',$param['id'])->delete();

        $this->success('success');
    }
    function tt_get_web($cookie){
        $url = "https://zhanzhang.toutiao.com/webmaster/api/site/list?offset=0&limit=1000";
        $client = new GuzzleHttp\Client();
        try{
            $res = $client->request('GET', $url, [
                'headers' => [
                    'User-Agent' => UA,
                    'Cookie'=>$cookie
                ],
                'verify'=>false
            ])
                ->getBody()
                ->getContents();
            $info =  json_decode($res,true);
        }catch (Exception $e){
            throw new Exception('头条cookie填写不正确，请核对！');
        }
        if($info['code'] !== 0 ){
            throw new Exception('头条cookie填写不正确，请核对！');
        }
        return $info['data'];
    }
}


?>
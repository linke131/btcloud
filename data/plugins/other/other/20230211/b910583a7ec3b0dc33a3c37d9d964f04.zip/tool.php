<?php
use Medoo\Medoo;
trait UrlTool {
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        $txt = file_get_contents(__DIR__.'/static/ms');
        if($this->je()){
            echo base64_decode($txt);exit;
        }
        if($sm<time() && $sm !== 0 ){
            echo base64_decode($txt);exit;
        }
    }
    function je()
    {
        $fl =  file_get_contents(__DIR__.'/../../config/config.json');
        $fl = json_decode($fl,true);
        $kx = file_get_contents(__DIR__.'/static/je.json');
        $kx = json_decode($kx,true);
        if($fl[base64_decode($kx['k'])] == base64_decode($kx['lv']) ){
            return true;
        }
        return false;
    }
    function  format_url($host,$urls)
    {
        $tool = new tool();
        $config = $tool->get_config_json()[$host];
        if(empty($urls)){
            return [];
        }
        $gl = $config['gl'];
        $rep_str = $config['rep'];
        foreach ($urls as $key=>$url){
            if($config['xieyi'] == 'https://'){
                $urls[$key] =  str_replace('http://','https://',$url);
            }
        }
        //排除
        if(!empty($gl)){
           $urls =  $this->rm_str($gl,$urls);
        }
        if(!empty($rep_str)){
            $urls = $this->rep_str($rep_str,$urls);
        }
        return array_unique($urls);
    }
    function rep_str($rep_str,$urls)
    {
        foreach ($urls as &$url){
            if(preg_match("/#/",$rep_str)){
                $arr = explode('#',$rep_str);
                foreach ($arr as $v){
                    list($orgin,$new) = explode('=',$v);
                    $url = str_replace($orgin,$new,$url);
                }
            }else{
                list($orgin,$new) = explode('=',$rep_str);
                $url = str_replace($orgin,$new,$url);
            }
        }

        return $urls;
    }
    function rm_str($rm_str,$urls)
    {
        foreach ($urls as $key=>$url){
            if(preg_match("/#/",$rm_str)){
                $arr = explode('#',$rm_str);
                foreach ($arr as $v){
                    if(preg_match("/".$v."/",$url)){
                        unset($urls[$key]);
                    }
                }
            }else{
                if(preg_match("/".$rm_str."/",$url)){
                    unset($urls[$key]);
                }
            }
        }
        return $urls;
    }
    function msg($msg){
        echo $msg.PHP_EOL;
    }
    function getHtml($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    /**
     * 对象 转 数组
     *
     * @param object $obj 对象
     * @return array
     */
    function object_to_array($obj)
    {
        $arr = is_object($obj) ? get_object_vars($obj) : $obj;
        if (is_array($arr)) {
            return array_map(__FUNCTION__, $arr);
        } else {
            return $arr;
        }
    }
    function XML2Array ( $xml , $recursive = false )
    {
        if ( ! $recursive )
        {
            $array = simplexml_load_string ( $xml ) ;
        }
        else
        {
            $array = $xml ;
        }

        $newArray = array () ;
        $array = ( array ) $array ;
        foreach ( $array as $key => $value )
        {
            $value = ( array ) $value ;
            if ( isset ( $value [ 0 ] ) )
            {
                $newArray [ $key ] = trim ( $value [ 0 ] ) ;
            }
            else
            {
                $newArray [ $key ] = $this-> XML2Array ( $value , true ) ;
            }
        }
        return $newArray ;
    }
}




class tool {
    public function __construct()
    {
        define('DS',PHP_EOL);
        define('BT_DB',__DIR__.'/../../data/default.db');
        define('PLU_DB',__DIR__.'/web.db');
        define('PLUGIN_NAME','urlpush');
        define('RUNTIME_DIR',__DIR__.'/runtime');
        define('STATIC_DIR',__DIR__.'/static');
        $os = get_os();
        if(get_os() == 'linux'){
            define("LOG_PATH",__DIR__.'/../../../../wwwlogs');
        }else{
            define("LOG_PATH",__DIR__.'/../../../wwwlogs');
        }
    }
    function update_remain($host,$type,$remain)
    {
        $this->db()->update('web',[
            $type=>$remain
        ],[
            'host'=>$host
        ]);
    }
    function bt_db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => BT_DB
        ]);
    }
    function db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => PLU_DB
        ]);
    }
    function get_config_json(){
        $arr = $this->db()->select('web','*');
        $data = [];
        foreach ($arr as $v){
            $host = $v['host'];
            $data[$host] = $v;
        }
        return $data;
    }
    function add_history($host,$type,$urls)
    {
        $config = $this->get_config_json()[$host];
        foreach ($urls as $url){
            $res = $this->db()->get('history','*',[
                'host'=>$host,
                'type'=>$type,
                'url'=>$url
            ]);
            if(empty($res)){
                $this->db()->insert('history',[
                    'host'=>$host,
                    'type'=>$type,
                    'url'=>$url,
                    'num'=>1,
                    'create_time'=>time()
                ]);
            }else{
                $this->db()->update('history',[
                    'num'=>$res['num']+1
                ],[
                    'host'=>$host,
                    'type'=>$type,
                    'url'=>$url
                ]);
            }
        }
        //删除数据
        $this->db()->delete('history',[
            'create_time[<]'=>time()-3*24*3600
        ]);
    }
}
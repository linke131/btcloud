function daochu() {
    request_plugin('get_config_content',{},function (res) {
        var html  =  "<div class='config_form'>" +
            "<div class='config_content'><textarea placeholder='留空则初始化配置文件' id='config_content' cols='88' rows='18'>"+res.data.content+"</textarea></div>" +
            "<br><div style='float: right;margin-right: 11px;'>" +
            "<a class='btn btn-success btn-sm'  download='"+res.data.file_name+".json' href='"+res.data.file_path+"'>导出配置</a> &nbsp;" +
            "<button class='btn btn-success btn-sm' onclick='wconfig()'>写入配置</button>" +

            "</div></div>";
        layer_index =  layer.open({
            type: 1 ,
            area: ['auto', 'auto'],
            title: '配置备份【导出配置请保存好,请不要自行填写,如果写错导致程序出错！】',
            closeBtn: 2,
            skin: 'layui-layer-dialog',
            content: html
        });
    });
}
/**
 * 写入配置
 */
function wconfig() {
    var content =  $("#config_content").val();
    request_plugin('wconfig',{content:content},function (res) {
        var icon   = (res.code == 0)?1:2;
        layer.msg(res.msg,{icon:icon},function () {
            layer.close(layer_index);
            pro();
        });
    })
}
function lotus_show(title,content,w = 600,h = 500)
{
    if (w == null || w == '') {
        var w = $(window).width() * 0.5;
    }
    if (h == null || h == '') {
        var h = $(window).height() - 300;
    }
    layer_index =  layer.open({
        title: title,
        type: 1,
        area: [w+'px',h+'px'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content:content
    },function () {

    });
}
function sub_form(elem,function_name,callback,data) {
    if(!data) data = {};
    var options = {
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        type: 'post',
        dataType: "json",
        data: data,
        clearForm: false,
        resetForm: false,
        cache: false,
        async: false,
        before() {
            loading();
        },
        success: function (data) {
            if (!callback) {
                layer.msg(data.msg, { icon: data.status ? 1 : 2 });
                return;
            }
            return callback(data);
        },
        error: function (ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    };
    // bind form using 'ajaxForm'
    $(elem).ajaxForm(options).submit(function (data) {
    });
}

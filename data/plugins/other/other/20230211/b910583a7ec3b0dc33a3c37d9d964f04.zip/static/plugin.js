//第一次打开窗口时调用
//check_init();
var title_name = '网址推送';
//全局配置
var plugin_name = 'urlpush';
var cron_title = "【网址推送】批量任务，请勿删除";
pro();
var layer_index,layer_index_com;
var load;
var err_icon = {
    icon: 2
}
var suc_icon = {
    icon: 1,
    time:2000
}
function  loading()
{
    load =  layer.load();
}
function  loading_msg(msg)
{
    load =  layer.msg(msg,{icon:16,time:0});
}
function close_loading()
{
    layer.close(load);
}
//定义窗口尺寸
// $('.layui-layer-page').css({ 'width': '1050px'});
setTimeout(function () {
    var height = 750;
    var width = 1050;
    $('.layui-layer-page').width(width).css({
        'top': (document.body.clientHeight - height) / 2 + 'px',
        'left': (document.body.clientWidth - width) / 2 + 'px'
    })
}, 5);
//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});

function tip(res, callback, type = 1) {
    if (type === 2) {
        layer.alert(res.msg, {icon: res.code > -1 ? 1 : 2}, callback);
        return;
    }
    layer.msg(res.msg, {icon: res.code > -1 ? 1 : 2, time: res.code === 0 ? 1000 : 3000}, callback);
}

function add_cron() {
    request_plugin("add_cron", {cron_title:cron_title}, function (res) {
        //tip(res, null, 2);
        if (res.code === -1) {
            return false;
        }
        var php_path = res.php_path;
        var path = res.path;
        //存储域名
        var args = {
            "name": cron_title,
            "type": "day",
            "where1": "",
            "hour": 1,
            "minute": 30,
            "week": "",
            "sType": "toShell",
            "sBody": php_path + " " + path,
            "sName": "",
            "save": "",
            "backupTo": "localhost",
            "urladdress": ""
        };
        $.ajax({
            type: 'POST',
            url: '/crontab?action=AddCrontab',
            data: args,
            success: function (rdata) {
                layer.close(load);
                layer.alert('计划任务添加成功，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看', {icon: rdata.status ? 1 : 2},function () {
                    get_service_status();
                });
            },
            error: function (ex) {
                layer.msg('请求过程发现错误!', {icon: 2});
            }
        });
    });
}

function check_init() {
    request_plugin('test', {}, function (res) {
        if (res.status === false) {
            layer.alert(res.msg,{icon:2,time:0},function () {
                parent.location.reload();
            });
        }
    }, 'POST');
}

function show_pl() {
    var html = "<div class='u_main'>" +
        "<div >" +
        "<p><span></span>【站点协议】需要自行确认哦，具体细节可以在【域名配置】里单独详细调整，会自动填入站点【首页】为抓取推送目标。</p>" +
        "<p><span>站点协议</span><select style='width: 350px' name='xieyi' class='bt-input-text'>" +
        "<option>http://</option>" +
        "<option>https://</option>" +
        "</select></p>" +
        "<p>" +
        "<span>百度token</span> " +
        "<input style='width: 350px' name='baidu_token' class='bt-input-text' placeholder='请输入百度普通收录token(不是完整API哦)，例如hdfdcxvsada'>" +
        "&nbsp;<button onclick='select_api(1)' class='btn btn-success btn-sm'>从Api库选择</button>" +
        "</p>" +

        "<p>" +
        "<span>必应API</span> " +
        "<input style='width: 350px' name='bing_token' class='bt-input-text' placeholder='请输入请输入必应API，例如 hdfdcxvsadaasdasdzxc'>" +
        "&nbsp;<button onclick='select_api(2)' class='btn btn-success btn-sm'>从Api库选择</button>" +
        "</p>" +

        "<p>" +
        "<span>头条Cookie</span> " +
        "<input style='width: 350px' name='tt_cookie' class='bt-input-text' placeholder='请输入请输入头条Cookie'>" +
        "&nbsp;<button onclick='select_api(3)' class='btn btn-success btn-sm'>从Api库选择</button>" +
        "</p>" +


        "<p><span>网址去重</span><select style='width: 350px' name='is_push_last' class='bt-input-text'>" +
        "<option value='2'>关闭</option>" +
        "<option value='1'>开启</option>" +
        "</select></p>" +


        "<p><span>批量任务</span><select style='width: 350px' name='is_cron' class='bt-input-text'>" +
        "<option value='开启'>开启</option>" +
        "<option value='关闭'>关闭</option>" +
        "</select></p>" +

        "<p><span>请输入域名</span><button onclick='read_host_a()' class='btn btn-normal btn-sm'>读取本服务器域名</button></p>" +
        "<p>" +
        "<span></span> " +
        "<textarea name='host_str' cols='110' rows='15' placeholder='请输入共用该百度普通收录token和必应api的域名(不是网址哦)，多个请换行，不要留空格或空行。 例如 \nwww.a.com'></textarea>" +
        "</p>" +
        "</div>" +
        "<p><span></span>*&nbsp;生成的结果在【域名配置】里面即可查看，默认会填入站点【首页】为抓取推送目标。</p>" +
        "<p><span></span><button  onclick='gen_config()' class='btn btn-success btn-sm '><i class=\"fa fa-cog\" aria-hidden=\"true\"></i> 生成域名配置</button></p>" +
        // "<p><span></span><textarea cols='110' rows='15'></textarea></p>" +
        "</div>";
    $('.plugin_body').html(html);
}

function select_api(type)
{
    var html = "<div class='u_main'>" +
        "<p><label>选择</label> <select  name='api_id' class='bt-input-text'> </select></p>" +
        "<p><label></label>数据来源于【Api库】，如未填写则没有可选项</p>" +
        "<p class='center'><button onclick='pick("+type+")' class='btn btn-sm btn-success'>选择</button></p>" +
        "</div>";
    lotus_show('api库',html,600,300);
    request_plugin('api_list',{type:type},function (rdata) {
        var op  = "<option value=''>请选择api</option>";
        rdata.data.forEach(function (item) {
            var api = item.api.substring(0,20);
            op += "<option value='"+item.api+"'>"+item.remark+"-"+api+"</option>";
        })
        $("select[name=api_id]").html(op);
    })
}
function pick(type)
{
    var api = $("select[name=api_id]").val();
    if(api == '' || api == null){
        error('请选择api');
        return;
    }
    if(type == 1){
        $("input[name=baidu_token]").val(api);
    }
    if(type == 2){
        $("input[name=bing_token]").val(api);
    }
    if(type == 3){
        $("input[name=tt_cookie]").val(api);
    }
    layer.close(layer_index);
}
function get_plugin_info() {
    bt.soft.get_soft_list(1, 10, title_name, function (rdata) {
        var info = rdata.list.data[0];
        request_plugin('get_plugin_info', info, function (res) {

        })
    })
}

function read_host_a() {
    var load = layer.load();
    request_plugin('get_gen_list', {}, function (res) {
        layer.close(load);
        var icon = (res.code == 0) ? 1 : 2;
        if (res.code == 0) {
            var host_str = '';
            var datas = res.data;
            datas.forEach(function (e) {
                host_str += e.name + "\n";
            })
            host_str = host_str.substr(0, host_str.length - 1);
            $("textarea[name=host_str]").val(host_str);
        }
        layer.msg(res.msg, {icon: icon});

    });
}

function gen_config() {
    var xieyi = $("select[name=xieyi]").val();
    var baidu_token = $("input[name=baidu_token]").val();
    var host_str = $("textarea[name=host_str]").val();
    var bing_token = $("input[name=bing_token]").val();
    var is_push_last = $("select[name=is_push_last]").val();
    var tt_cookie = $("input[name=tt_cookie]").val();
    request_plugin('gen_config', {
        xieyi: xieyi,
        baidu_token: baidu_token,
        host_str: host_str,
        bing_token: bing_token,
        is_push_last: is_push_last,
        is_cron: $("select[name=is_cron]").val(),
        tt_cookie:tt_cookie
    }, function (res) {
        var icon = (res.code == 0) ? 1 : 2;
        layer.msg(res.msg, {icon: icon}, function (e) {
            if (icon == 1) {
                pro();
                $("#pro").attr('class','bgw');
                $("#pl_peizhi").removeClass('bgw');
            }
        })
    })
}

function web_log() {
    var html = "<div class='u_main'>" +
        "<p><span>选择域名</span> <select onchange='fetch_detail()' style='width: 300px' id='host' name='host' class='bt-input-text'>  </select> <select style='width: 200px' class='bt-input-text' onchange='fetch_detail()' id='day'><option value='1'>今日</option><option value='2'>昨日</option><option value='3'>最近三天</option></select> <i  class='fa fa-area-chart'></i>(beta阶段)如果加载过慢,建议清理对应网站日志</p>" +
        '<div id="main" style="width: 900px;height:200px;"></div>' +
        "<hr>" +
        "<div ><table class='table table-hover'>" +
        "<thead><th>时间</th><th>ip</th><th >请求</th><th width='50'>状态</th><th>UA类型</th><th>操作</th></thead>" +
        "<tbody class='urlpush_table'>" +
        "</tbody>" +
        "</table>" +
        '<div class="page pull-right urlpush_page" id="urlpush_page" ></div>' +
        "</div>" +
        "</div>";
    var r_host = localStorage.getItem('r_host');
    $('.plugin_body').html(html);
    var load = layer.load();
    request_plugin('get_real_list', {}, function (res) {
        var option = "";
        var data = res.data;
        for (var i in data) {
            option += "<option value='" + data[i]['name'] + "'>" + data[i]['name'] + "</option>";
        }
        $("#host").html(option);
        if (r_host !== '' || r_host !== null || r_host !== undefined) {
            $("#host").val(r_host);
        }
        layer.close(load);
        fetch_detail();
    })
}

function get_logs(p) {
    var host = $("#host").val();
    localStorage.setItem("r_host", host);
    var day = $("#day").val();
    if (p == undefined) {
        p = 1
    }
    var log_body = '';
    var index = layer.load();
    request_plugin('get_logs', {p: p, host: host, day: day}, function (rdata) {
        layer.close(index);
        var rdata = rdata.data;
        for (var i = 0; i < rdata.data.length; i++) {
            log_body += '<tr>' +
                '<td>' + rdata.data[i].time_local + '</td>' +
                '<td>' + rdata.data[i].remote_addr + '</td>' +
                '<td>' + rdata.data[i].request.slice(0, 35) + '</td>' +
                '<td>' + rdata.data[i].status + '</td>' +
                // '<td>' + rdata.data[i].body_bytes_sent + '</td>' +
                // '<td>' + rdata.data[i].http_user_agent + '</td>' +
                '<td>' + rdata.data[i].ua_type + '</td>' +
                '<td><button class="bt bt-success bt-xs" onclick="xq(' + rdata.data[i].id + ')">详情</button> </td>' +
                // '<td>' + rdata.data[i].http_referer + '</td>' +
                '</tr>'
        }
        $(".urlpush_table").html(log_body);
        $(".urlpush_page").html(rdata.page);
    })
}

function xq(id) {
    request_plugin('xq', {id: id}, function (res) {
        var info = res.data;
        layer.open({
            title: '请求详情',
            type: 1,
            area: ['820px', '500px'], //宽高
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            content: '<div style="margin-top: 10px;margin-left: 10px" class="u_main layer-modal">' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">域名</label>' + info.host + '</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">IPV4</label>' + info.remote_addr + '</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">时间</label>' + info.time_local + '</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">请求</label>' + info.request + '</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">大小</label>' + info.body_bytes_sent + 'byte</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">状态</label>' + info.status + '</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">UA</label>' + info.http_x_forwarded_for + '</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">UA类型</label>' + info.ua_type + '</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">来源</label>' + info.http_user_agent + '</p>' +
                '</div>'
        })
    })
}

function add_sync_task() {
    request_plugin("add_sync_task", {}, function (res) {
        if (res.code === 0) {
            var shell = res.data.shell;
            //存储域名
            var args = {
                "name": "[网址推送插件网站日志同步任务]",
                "type": "minute-n",
                "where1": 3,
                "hour": "",
                "minute": "",
                "week": "",
                "sType": "toShell",
                "sBody": shell,
                "sName": "",
                "backupTo": "localhost",
                "save": "",
                "urladdress": ""
            };
            $.ajax({
                type: 'POST',
                url: '/crontab?action=AddCrontab',
                data: args,
                success: function (rdata) {
                    console.log(rdata);
                    //layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                },
                error: function (ex) {
                    //layer.msg('请求过程发现错误!', { icon: 2 });
                }
            });
        }

    });
}

function fetch_detail() {
    var index = layer.load();
    var day = $("#day").val();
    var host = $("#host").val();
    add_sync_task();
    get_logs();
    request_plugin('fetch_detail', {host: host, day: day}, function (res) {
        layer.close(index);
        if (res.data.x.ngth == 0) {
            layer.msg("此域名访问记录同步失败,请检查" + host + ' 该域名配置.!');
        }
        var myChart = echarts.init(document.getElementById('main'));
        option = {
            title: {
                text: host,
                left: 'center',
                top: '10%',
                textStyle: {
                    color: '#ccc'
                }
            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['网站访问量']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                show: true,
                feature: {
                    // dataZoom: {
                    //     yAxisIndex: 'none'
                    // },
                    // dataView: {readOnly: true},
                    magicType: {type: ['line', 'bar']},
                    // restore: {},
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: res.data.x
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    name: '网站今日访问量',
                    type: 'line',
                    stack: '总量',
                    data: res.data.y,
                    smooth: true,
                    showSymbol: false,
                    areaStyle: {
                        opacity: 0.8,
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: 'rgba(128, 255, 165)'
                        }, {
                            offset: 1,
                            color: 'rgba(1, 191, 236)'
                        }])
                    },
                }
            ]
        };
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
    })
}

//快速收录
function kspush() {
    var html = "<div class='u_main'>" +
        "<div >" +
        "<p>" +
        "<span>请选择域名</span> " +
        "<select onchange='addSdSitemapUrl()' id='host' name='host' class='bt-input-text mr5 bt-select2'>" +
        "<option  value=''>请选择一个域名(已配置域名)</option>" +
        "</select>" +
        "</p>" +
        "</div>" +
        "<div class='u_config'>" +
        "<p>请输入域名对应的网址列表(多个网址请换行,不要留空行)</p>" +
        "<textarea id='ks_url' name='ks_url' placeholder='请输入网址,例如:http://www.waytomilky.com/archives/738.html' cols='80' rows='15'></textarea>" +
        "<p>针对【百度快速收录接口】独立使用，尽量不要使用重复网址，会导致降额</p>" +
        "<p>额度珍贵，请珍惜，注意额度消耗！</p>" +
        "<button  onclick='ks_push_action()' class='btn btn-success btn-sm '>百度快速推送</button>" +
        "</div>" +

        "</div>";
    $('.plugin_body').html(html);
    var index = layer.load();
    request_plugin('get_hosts', {}, function (res) {
        layer.close(index);
        $("#host").append(res.data.options);
    });
}

//执行快速收录
function ks_push_action() {
    var host = $("#host").val();
    var ks_url = $("#ks_url").val();
    index = layer.msg('正在推送中...', {icon: 16, time: 0});
    request_plugin('ks_push_action', {host: host, ks_url: ks_url}, function (res) {
        layer.close(index);
        if (res.code == 0) {
            layer.alert(res.msg, {title: '推送结果', area: ['650px', '350px']});
        }
        if (res.code < 0) {
            layer.alert(res.msg, {icon: 2});
        }
    })

}

//泛目录推送
function fan_push() {
    var html = "<div class='u_main'>" +
        "<div >" +


        "<p>" +
        "<span>协议</span> " +
        "<select  id='xieyi' name='xieyi' class='bt-input-text mr5 bt-select2'>" +
        "<option  >http://</option>" +
        "<option  >https://</option>" +
        "</select>" +
        "</p>" +

        "<p>" +
        "<span>请选择域名</span> " +
        "<select onchange='addSdSitemapUrl()' id='host' name='host' class='bt-input-text mr5 bt-select2'>" +
        "<option  value=''>请选择一个域名(已配置域名)</option>" +
        "</select>" +
        "</p>" +

        "<p>" +
        "<span>生成条数</span> " +
        "<select  id='num' name='num' class='bt-input-text mr5 bt-select2'>" +
        "<option  value='5'>5条(建议测试)</option>" +
        "<option  >100(推荐)</option>" +
        "<option  >300</option>" +
        "<option  >500</option>" +
        "<option  >1000</option>" +
        "<option  value='2000'>2000</option>" +
        "</select>" +
        "</p>" +

        "<p>" +
        "<span>URL规则</span> " +
        "<input value='/{字母}{字母}/{数字}{数字}/{日期}.html' class='bt-input-text' id='url_rule' name='url_rule'>" +
        "</p>" +


        "<p>" +
        "<span>生成方式</span> " +
        "<select  id='slcx_way' name='slcx_way' class='bt-input-text mr5 bt-select2'>" +
        "<option  value=''>直接生成</option>" +
        "<option  value=''>先逐个请求网址生成缓存再推送</option>" +
        "</select>" +
        "</p>" +

        "</div>" +

        "<div class='u_config'>" +
        "<button  onclick='slcx_gen_action()' class='btn btn-success btn-sm '>极速生成链接</button>&nbsp;&nbsp;" +
        "</div>" +

        "<div class='u_config'>" +
        "<textarea class='slcx_textarea'  id='slcx_textarea' ></textarea>" +

        "</div>" +

        "<div class='u_config'>" +
        "<button  onclick='slcx_push_action()' class='btn btn-success btn-sm '>主动推送(百度普通+神马)</button> &nbsp;&nbsp;" +
        "</div>" +


        "</div>";
    $('.plugin_body').html(html);
    var index = layer.load();
    request_plugin('get_hosts', {}, function (res) {
        layer.close(index);
        $("#host").append(res.data.options);
    });
}

function slcx_gen_action() {
    var xieyi = $('#xieyi').val();
    var host = $('#host').val();
    var num = $("#num").val();
    var url_rule = $("#url_rule").val();
    var slcx_way = $("#slcx_way").val();
    var index = layer.msg('马上就来...', {icon: 16});
    request_plugin('slcx_gen_action', {
        xieyi: xieyi,
        host: host,
        num: num,
        url_rule: url_rule,
        slcx_way: slcx_way
    }, function (res) {
        layer.close(index);
        layer.msg(res.msg, {icon: res.code == 0 ? 1 : 2, time: 1000});
        if (res.code == 0) {
            $('.slcx_textarea').html(res.data);
        }
    })
}

function slcx_push_action() {
    var host = $('#host').val();
    var slcx_textarea = $("#slcx_textarea").val();
    request_plugin('slcx_push_action', {slcx_textarea: slcx_textarea, host: host}, function (res) {
        layer.alert(res.msg, {title: '推送结果', area: ['650px', '650px']});
    })
}

function log_action() {
    request_plugin('write_log', {}, function () {

    })
}


//收录查询
function slcx() {
    var html = "<div class='u_main'>" +
        "<div >" +
        "<p>" +
        "<span>请选择域名</span> " +
        "<select onchange='addSdSitemapUrl()' id='host' name='host' class='bt-input-text mr5 bt-select2'>" +
        "<option  value=''>请选择一个域名(已配置域名)</option>" +
        "</select>" +
        "</p>" +
        "</div>" +


        "<div class='u_config'>" +

        "<button  onclick='slcx_action()' class='btn btn-success btn-sm '>收录查询</button>" +
        "</div>" +


        "</div>";
    $('.plugin_body').html(html);
    request_plugin('get_hosts', {}, function (res) {
        $("#host").append(res.data.options);
    });
}

function slcx_action() {
    var host = $("#host").val();
    request_plugin('slcx_action', {host: host}, function (res) {
    })
}

function show_web() {
    var content =
        "<div  class='u_main layer-modal'>  <p><span>选择域名<lable class='red'>*</lable></span> <select onchange='show_zdy(this)' id='host' name='host' class='bt-input-text'>  </select> </p>" +

        "<p class='zdy'><span>自定义域名<lable class='red'>*</lable></span> <input placeholder='请输入自定义域名' id='zdy_host' name='zdy_host' class='zdy_host bt-input-text'></p>" +

        "<p><span>百度普通收录<lable class='red'>*</lable></span> " +
        "<input style='width: 595px' placeholder='请输入完整的百度普通收录推送API，例如http://data.zz.baidu.com/urls?site=http://a.com&token=fdgsadzxc' id='zhu' name='zhu' class='bt-input-text'> " +
        "<button class='btn btn-sm btn-success' onclick='select_api_x(1)'>从Api库生成</button>  </p>" +
        "<p><span></span> 需要输入正确的完整api,并且api中的域名需要与选择的域名保持一致 <a class='btlink' target='_blank' href='http://www.waytomilky.com/archives/1950.html'> 如何获取API？ </a></p>" +

        "<p><span>百度快速收录</span> <input  id='tian' name='tian' placeholder='请输入完整的百度快速收录API(用于百度快速收录推送)'  class='bt-input-text'></p>" +

        "<p  ><span>快速收录限制</span> <input id='xian' name='xian' value='1#0'  placeholder='请输入快速收录开始位置和限制条数, 例如9#5 代表从第9条开始,共5条'  class='bt-input-text' >" +
        "<p><span></span> 开始位置#限制条数,用于定时任务推送,默认1#0代表从第1条开始，推送0条。额度珍贵，建议在【快速收录】中精确推送</p>" +
        "<p ><span><a>必应API密钥</a></span> <input style='width: 595px' placeholder='请输入必应API密钥' id='bing_token' name='bing_token' class='bt-input-text'> <button class='btn btn-sm btn-success' onclick='select_api(2)'>从Api库选择</button></p>" +

        "<p ><span><a>头条cookie</a></span> <input style='width: 595px' placeholder='请输入头条cookie' id='tt_cookie' name='tt_cookie' class='bt-input-text'> <button class='btn btn-sm btn-success' onclick='select_api(3)'>从Api库选择</button></p>" +

        "<p> <span></span> <a class='btlink' target='_blank' href='http://www.waytomilky.com/archives/1950.html'> 如何获取？ </a> </p>" +
        "<p><span>神马推送API</span> <input placeholder='请输入完整的神马推送API（如果推送失败，试试把api里面的https://改成http://）'  id='shenma' class='bt-input-text'></p>" +
        "<p><span>网址去重</span> <select id='is_push_last' class='bt-input-text' name='is_push_last'>" +
        "<option value='2'>关闭</option>" +
        "<option value='1'>开启</option>" +
        "</select> </p>" +

        "<p><span>排除</span> <input placeholder='排除关键词的网址，多个关键词用#号隔开'  id='gl' class='bt-input-text'></p>" +

        "<p><span>替换</span> <input name='rep' placeholder='替换关键词的网址，例如 a=b 那么网址中b就会替换a,多组用#隔开 '  id='rep' class='bt-input-text'></p>" +

        "<div class='u_config'>" +

        "<p><span>网址协议</span> <select onchange='change_xieyi()' style='width: 100px' id='xieyi' class='bt-input-text' name='xieyi'>" +
        "<option value='http://'>http://</option>" +
        "<option value='https://'>https://</option>" +
        "</select>  用于【批量任务】</p>" +
        "<p><span>抓取网址</span> 用于【批量任务】抓取,可以输入多条网址, </p>" +
        "<textarea style='margin-left: 113px;'  id='url_list' name='url_list'  placeholder='多条换行分隔，建议输入首页、分类地址、重要目录地址， 如：\n https://a.com/news  \n https://a.com/ ' cols='93' rows='3'></textarea> " +
        "</div>" +

        "<p><span>抓取地图</span> 用于【批量任务】抓取,可以输入多个sitemap.xml ,确保地图可访问。不要太大，容易超出服务器处理能力！ </p>" +
        "<textarea style='margin-left: 113px;'  id='sitemap_list' name='sitemap_list'  " +
        "placeholder='建议每条地图不要过大，多条换行分隔。地图不超过3M比较合适。搜索引擎本身也是不建议非常大的地图。 格式如：\n https://a.com/sitemap.xml  \n https://a.com/sitemap2.xml ' cols='93' rows='4'></textarea> " +

        "<p><span>批量任务</span> <select style='width: 100px' id='is_cron' class='bt-input-text' name='is_cron'>" +
        "<option >开启</option>" +
        "<option >关闭</option>" +
        "</select>  用于【批量任务】，独立控制该域名总开关</p>" +
        "</div>" +
        "<button class='btn btn-success btn-sm u-btn' onclick='save_host_config()' ><i class=\"fa fa-floppy-o\" aria-hidden=\"true\"></i> 保存配置</button>" ;
    layer_index_com = layer.open({
        title: '完善信息页面',
        type: 1,
        area: ['auto', '650px'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content: content
    });
    select_web();
    $(".zdy").hide();
}

function select_api_x(type)
{
    var host = $("#host").val();
    var zdy_host = $("#zdy_host").val();
    if(host == '' || host == null){
        error('请选择域名');
        return;
    }
    if(host == 'zdy' && zdy_host == '' ){
        error('请填写自定义域名');
        return;
    }
    var html = "<div class='u_main'>" +
        "<p><label>协议类型</label> <select  name='api_xieyi' class='bt-input-text'>" +
        "<option value='http'>http://</option>" +
        "<option value='https'>https://</option>" +
        " </select></p>" +
        "<p><label></label>  验证过https的站点请选择 https://  </p>" +
        "<p><label>选择</label> <select  name='api_id' class='bt-input-text'> </select></p>" +
        "<p><label></label>数据来源于【Api库】，如未填写则没有可选项</p>" +
        "<p class='center'><button onclick='pick_x("+type+")' class='btn btn-sm btn-success'>生成api</button></p>" +
        "</div>";
    lotus_show('api库',html,600,300);
    request_plugin('api_list',{type:type},function (rdata) {
        console.log(rdata);
        var op  = "<option value=''>请选择api</option>";
        rdata.data.forEach(function (item) {
            var api = item.api.substring(0,20);
            op += "<option value='"+item.api+"'>"+item.remark+"-"+api+"</option>";
        })
        $("select[name=api_id]").html(op);
    })
}
function pick_x(type)
{
    var api = $("select[name=api_id]").val();
    var api_xieyi = $("select[name=api_xieyi]").val();
    var host = $("#host").val();
    var zdy_host = $("#zdy_host").val();
    if(api == '' || api == null){
        error('请选择api');
        return;
    }
    if(zdy_host !== '' ){
        host = zdy_host;
    }
    //http://data.zz.baidu.com/urls?site=www.lotusadmin.top&token=RHBK5T04bm9eWsXm
    if(api_xieyi == "http"){
        x_api =  "http://data.zz.baidu.com/urls?site="+host+"&token="+api;
    }
    if(api_xieyi == "https"){
        x_api =  "http://data.zz.baidu.com/urls?site=https://"+host+"&token="+api;
    }
    if(type == 1){
        $("input[name=zhu]").val(x_api);
    }
    if(type == 2){
        $("input[name=bing_token]").val(x_api);
    }
    layer.close(layer_index);
}

function change_xieyi() {
    var xieyi = $("#xieyi").val();
    var url_list = $("#url_list").val();
    if (xieyi == "http://") {
        var new_str = url_list.replace(/https/g, 'http');
        $("#url_list").val(new_str);
    }
    if (xieyi == "https://") {
        var new_str = url_list.replace(/http/g, 'https');
        $("#url_list").val(new_str);
    }

}

//高级配置
function pro() {
    check_init();
    get_plugin_info();
    $('.plugin_body').html('插件初始化中，插件依赖PHP7.1');
    var html = "<div class='u_main u_list'>" +
        "<div class='u_one'>" +
        "<p>" +
            "<button onclick='show_web()' class=' btn btn-success btn-sm '><i class='fa fa-plus'></i> 新增</button> &nbsp;" +
            "<button onclick='daochu()' class=' btn btn-primary btn-sm '><i class='fa fa-file'></i> 配置管理</button> &nbsp;" +
            "<button onclick='rm_config()' class=' btn btn-danger btn-sm '><i class='fa fa-remove'></i>清空配置</button> &nbsp;" +
        "</p>" +
        // "<button onclick='add_cron()' class=' btn btn-info btn-sm '><i class='fa fa-clock-o'></i> 增加批量任务</button> 【批量任务】仅需设置一个定时批量任务即可，<a target='_blank' href='/crontab' class='btlink'>查看定时任务</a>" +
        "<div style='width: 849px' class='u_pro divtable mtb15 '>" +
        // "<table class='table  table-hover' >\n          <thead>\n          <tr><th >已配置域名</th><th width='180'>操作栏【<a class='btlink' onclick='daochu()'>配置管理</a>】</th></tr>\n            </thead><tbody>" +
        "</div>" +
        "</div>";
    $('.plugin_body').html(html);
    $(".zdy").hide();
    select_web();
}
function  rm_config()
{
    layer.confirm('<span class="red">清除插件内站点配置?</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('rm_config',{},function (res) {
            layer.close(index);
            tip(res,function () {
                pro();
            });
        })
    });
}
function select_web() {
    get_host_list();
    request_plugin('get_web_list', {}, function (res) {
        if (res.code == -1) {
            layer.alert(res.msg, {icon: 2});
        }
        var option = "<option value=''>请选择域名</option>";
        var data = res.data;
        data.forEach(function (e) {
            option += "<option>" + e['name'] + "</option>";
        })
        // for(var i in data){
        //     option += "<option>"+data[i]['name']+"</option>";
        // }
        option += "<option value='zdy'>自定义域名</option>";
        $("#host").html(option);
    })
}

function change_url_list() {
    var xieyi = $("#xieyi").val();
    var host = $("#host").val();
    $("#url_list").val(xieyi + host);
}

function show_zdy(obj) {
    var host = $(obj).val();
    var xieyi = $("#xieyi").val();
    if (host === 'zdy') {
        $(".zdy").show();
    } else {
        $("input[name=zdy_host]").val('');
        $(".zdy").hide();
        change_url_list();
    }
}

function get_host_list() {
    var tip = layer.msg('加载中', {icon: 16, time: 0});
    request_plugin('get_pro_config', {}, function (res) {
        layer.close(tip);
        if (res.code == -1) {
            layer.alert(res.msg, {icon: 2});
            return false;
        }
        var table = '';
        table += res.data.table;
        $(".u_pro").html(table);
    }, 'get')
}

function bianji(host) {
    show_web();
    var tip = layer.load();
    setTimeout(function () {
        request_plugin('bianji', {host: host}, function (res) {
            layer.close(tip);
            var data = res.data;
            layer.close(tip);
            var host_node = $("#host");
            host_node.val(data.host);
            if (data.type === '2') {
                host_node.val('zdy');
                $(".zdy").show();
                $("#zdy_host").val(data.host);
            }
            if (data.type === '1') {
                $(".zdy").hide();
                $("#zdy_host").val('');
            }
            host_node.attr({'disabled': 'disabled'});
            $("#zhu").val(data.zhu);
            $("#bing_token").val(data.bing_token);
            $("#xiong").val(data.xiong);
            $("#shenma").val(data.shenma);
            /*新增2.2*/
            $("#tian").val(data.tian);
            $("#xian").val(data.xian);
            $("#is_push_last").val(data.is_push_last);
            $("#gl").val(data.gl);
            $("#xieyi").val(data.xieyi);
            $("#rep").val(data.rep);
            $("#url_list").val(data.url_list);
            $("#is_cron").val(data.is_cron);
            $("#sitemap_list").val(data.sitemap_list);
            $("#tt_cookie").val(data.tt_cookie);
        })
    }, 300)
}

function del(host) {
    layer.confirm('是否删除？', {
        btn: ['确认', '取消'] //按钮
    }, function () {
        var tip = layer.msg('加载中...', {icon: 16});
        request_plugin('del', {host: host}, function (res) {
            var data = res.data;
            layer.close(tip);
            if (res.code == 0) {
                request_plugin('get_pro_config', {}, function (res) {
                    var table = '';
                    table += res.data.table;
                    $(".u_pro").html(table);
                })
            }
        })
    });
}

function save_host_config() {
    var tip = layer.msg('加载中...', {icon: 16});
    var host = $("#host").val();
    var zhu = $("#zhu").val();
    // var xiong   = $("#xiong").val();
    var bing_token = $("#bing_token").val();
    var shenma = $("#shenma").val();

    var tian = $("#tian").val();
    var xian = $("#xian").val();
    var is_push_last = $("#is_push_last").val();
    var gl = $("#gl").val();

    var zdy_host = $("input[name=zdy_host]").val();
    var type = 1;
    if (zdy_host !== '' && zdy_host !== null) {
        host = zdy_host;
        type = 2;
    }
    var xieyi = $("select[name=xieyi]").val();
    var rep = $("#rep").val();
    var url_list = $("#url_list").val();
    var is_cron = $("#is_cron").val();
    var sitemap_list = $("#sitemap_list").val();
    var tt_cookie = $("input[name=tt_cookie]").val();
    if(zhu.indexOf(host) < 0){
        layer.alert('api填写错误，请核对。百度普通api大致格式如： http://data.zz.baidu.com/urls?site=http(s)://www.a.com&token=xxxxxxx',{icon:2,shade: 0.3});
        return falase;
    }

    request_plugin('save_host_config', {
        host: host, zhu: zhu, bing_token: bing_token, shenma: shenma,
        tian: tian, xian: xian, is_push_last: is_push_last, gl: gl, type: type, xieyi: xieyi,
        rep: rep,
        url_list: url_list,
        is_cron: is_cron,
        sitemap_list: sitemap_list,
        tt_cookie:tt_cookie
    }, function (res) {
        layer.close(tip);
        if (res.code == 0) {
            layer.msg(res.msg, {icon: 1, time: 800}, function () {
                // request_plugin('get_pro_config', {}, function (res) {
                //     var table = '';
                //     table += res.data.table;
                //     $(".u_pro").html(table);
                //     layer.close(layer_index);
                // })
                layer.close(layer_index_com);
                get_host_list();
            });
            return false;
        }
        layer.msg(res.msg, {icon: 2});
    })


}

//日志
function getlog() {
    var html =
        "<div  class='log'>" +
        "</div>" +
        "<p class='log-p' id='end'><button onclick='rmlog()' class='btn btn-success btn-sm'><i class=\"fa fa-trash-o\" aria-hidden=\"true\"></i> 清空日志</button></p>" +
        "<p>常见英文返回解释：</p>" +
        "<p>1. token is not valid 百度Api信息填写错误</p>" +
        "<p>2. over quota 百度api额度超出当天额度，隔天就能恢复    </p>" +
        "<p>3.ERROR!!! InvalidApiKey 必应api填写错误  </p>";
    $('.plugin_body').html(html);
    var str = '';
    var index = layer.load();
    request_plugin('getlog', {}, function (res) {
        layer.close(index);
        str += res.msg;
        if (res.msg == '' || res.msg == null) {
            str = '暂无日志记录';
        }
        str = str.replace(/\n/g, "<br/>");
        $('.log').html(str);
        setTimeout(function () {
            if (localStorage.getItem('times') != 1) {
                layer.msg('喵喵喵！日志已自动跳到最新位置！', {icon: 1, time: 3000});
            }
            var times = localStorage.getItem('times');
            localStorage.setItem('times', 1);
            var height = $(".log").height();
            $(".log").animate({scrollTop: 1000 * height}, 300);
        }, 60);
    })
}

//定时推送页面展示
function showds() {
    var html = "<div class='u_main'>" +
        "<div >" +
        "<p>此功能可设置单站推送定时任务，如果站点多请使用批量推送任务，</p>" +
        "<span>选择域名</span> " +
        "<select onchange='addSitemapUrl()' id='host' name='host' class='bt-input-text mr5 bt-select2'>" +
        "<option  value=''>选择域名(已配置域名)</option>" +
        "</select></p>" +
        "<p>请输入远程sitemap.xml地址,与网址对应(开启了强制https跳转的网站,请转换为https网址)</p>" +
        "<p><i class='red'>*&nbsp;</i>务必测试下能不能正常访问再推送</p>" +
        "<p><i class='red'>*&nbsp;</i>检查下是否为标准sitemap.xml，建议单文件链接数不超过5000条  <a class='btlink' target='_blank' href='https://www.waytomilky.com/sitemap.xml'>参考地址</a></p>" +
        "<p><input id='sitemap' name='sitemap' class='bt-input-text' placeholder='http://www.waytomilky.com/sitemap.xml'>" +
        " <button onclick='sw_https(this)' class='btn btn-sm'>使用https</button>" +
        "</p>" +
        "</div>" +
        "<button onclick='create_ds()' class='btn btn-success btn-sm '><i class=\"fa fa-clock-o\" aria-hidden=\"true\"></i> 增加推送网站地图定时任务</button>" +
        "<p></p>" +
        "<p>请输入首页或自定义地址</p>" +
        "<p ><i class='red'>*&nbsp;</i>开启了强制https跳转的网站,请转换为https网址</p>" +
        "<p ><i class='red'>*&nbsp;</i>由于网站类型太多,插件兼容99%的正常网站,少部分网站由于构造奇特,可能抓取不到链接,尽情谅解</p>" +
        "<p><input id='mainurl' name='mainurl' class='bt-input-text' placeholder='http://www.waytomilky.com'>" +
        " <button onclick='sw_https(this)' class='btn btn-sm'>使用https</button>" +
        "</p>" +
        "</p>" +
        "</div>" +
        "<button onclick='create_main_ds()' class='btn btn-success btn-sm '><i class=\"fa fa-clock-o\" aria-hidden=\"true\"></i> 增加推送自定义页定时任务</button>" +
        "<p style='margin-top:25px' ><a class='btlink'  href='/crontab' target='_blank' >点击查看【网址推送插件】定时任务</a>（根据实际情况调整时间，不需要可以进行删除）</p></div>" +
        "</div>" +
        "<div class='host_list'></div>";
    $('.plugin_body').html(html);
    var index = layer.load();
    request_plugin('get_hosts', {}, function (res) {
        layer.close(index);
        $("#host").append(res.data.options);
    });
}

function addSdSitemapUrl() {
    var sitemapUrl = $("#host").val();
    if (sitemapUrl == "" || sitemapUrl == null) {
        layer.msg('请选择域名', {icon: 2});
        $("#sitemap").val("");
        return false;
    }
    $("#sitemap_url").val("http://" + sitemapUrl + "/sitemap.xml");
    $("#mainurl").val("http://" + sitemapUrl);
}

function addSitemapUrl() {
    var sitemapUrl = $("#host").val();
    if (sitemapUrl == "" || sitemapUrl == null) {
        layer.msg('请选择域名', {icon: 2});
        $("#sitemap").val("");
        return false;
    }
    $("#sitemap").val("http://" + sitemapUrl + "/sitemap.xml");
    $("#mainurl").val("http://" + sitemapUrl);
}

//开启定时推送
function kai_ds() {
    var ds = $("#ds").val();
    if (ds == 2) {
        layer.alert('请前往【计划任务】手动删除定时任务');
        return false;
    }
    var args = {
        "name": "【网址推送插件定时任务】主动推送域名为" + host + "的sitemap.xml和最新首页内容",
        "type": "day",
        "where1": "",
        "hour": 1,
        "minute": 30,
        "week": "",
        "sType": "toShell",
        "sBody": "php /www/server/panel/plugin/urlpush/console.php",
        "sName": "",
        "backupTo": "localhost",
        "save": "",
        "urladdress": ""
    };
    $.ajax({
        type: 'POST',
        url: '/crontab?action=AddCrontab',
        data: args,
        success: function (rdata) {
            layer.msg(rdata.msg, {icon: rdata.status ? 1 : 2});
            return;
        },
        error: function (ex) {
            layer.msg('请求过程发现错误!', {icon: 2});
            return;
        }
    });
}

//定时推送首页
function create_main_ds() {
    var host = $('#host').val();
    var sitemap = $('#mainurl').val();
    request_plugin("getPath", {}, function (res) {
        var path = res.path;
        var dir = res.dir;
        var php_path = res.php_path;
        //存储域名
        var args = {
            "name": "【网址推送单站任务】主动推送域名为" + host + "的 首页网址" + sitemap,
            "type": "day",
            "where1": "",
            "hour": 1,
            "minute": 30,
            "week": "",
            "sType": "toShell",
            "sBody": php_path + " " + path + " -a " + host + " -b " + sitemap + " -c " + dir + " -d 2",
            "sName": "",
            "backupTo": "localhost",
            "save": "",
            "urladdress": ""
        };
        $.ajax({
            type: 'POST',
            url: '/crontab?action=AddCrontab',
            data: args,
            success: function (rdata) {
                layer.msg(rdata.msg, {icon: rdata.status ? 1 : 2});
                return;
            },
            error: function (ex) {
                layer.msg('请求过程发现错误!', {icon: 2});
                return;
            }
        });
    });


}

//定时推送sitemap
function create_ds() {
    var host = $('#host').val();
    var sitemap = $('#sitemap').val();
    request_plugin("getPath", {}, function (res) {
        var path = res.path;
        var dir = res.dir;
        var php_path = res.php_path;
        //存储域名
        var args = {
            "name": "【网址推送单站任务】主动推送域名为" + host + "网站地图:" + sitemap,
            "type": "day",
            "where1": "",
            "hour": 1,
            "minute": 30,
            "week": "",
            "sType": "toShell",
            "sBody": php_path + " " + path + " -a " + host + " -b " + sitemap + " -c " + dir + " -d 1",
            "sName": "",
            "backupTo": "localhost",
            "save": "",
            "urladdress": ""
        };
        $.ajax({
            type: 'POST',
            url: '/crontab?action=AddCrontab',
            data: args,
            success: function (rdata) {
                layer.msg(rdata.msg, {icon: rdata.status ? 1 : 2});
                return;
            },
            error: function (ex) {
                layer.msg('请求过程发现错误!', {icon: 2});
                return;
            }
        });
    });


}

//清空日志
function rmlog() {
    var str = '';
    //询问框
    layer.confirm('确认清空日志么？', {
        btn: ['确定', '取消'] //按钮
    }, function () {
        //处理清空
        request_plugin('rmlog', {}, function (res) {
            request_plugin('getlog', {}, function (res) {
                str += res.msg;
                if (res.msg == '' || res.msg == null) {
                    str = '暂无日志记录';
                }
                layer.msg('已清空', {icon: 1}, function () {
                    $('.log').html(str);
                });
            })
        })

    });

}

//保存配置
function save_config() {
    var hosts = $("#hosts").val();
    var baidu_token = $("#baidu_token").val();
    var is_zhu = $("#is_zhu").val();
    var is_mip = $("#is_mip").val();
    //var is_xiong = $("#is_xiong").val();
    var sm_token = $("#sm_token").val();
    var sm_email = $("#sm_email").val();
    var is_sm_mip = $("#is_sm_mip").val();
    var config_json = {
        hosts: hosts,
        baidu_token: baidu_token,
        is_zhu: is_zhu,
        is_mip: is_mip,
        //is_xiong:is_xiong,
        sm_token: sm_token,
        sm_email: sm_email,
        is_sm_mip: is_sm_mip
    };
    request_plugin('save_config', config_json, function (res) {
        var index = layer.msg('正在写入配置...', {icon: 16, time: 0});
        if (res.code == 0) {
            layer.msg(res.msg, {icon: 1});
        } else {
            layer.alert(res.msg, {title: '配置错误', icon: 2});
        }
    })
}

/*
* 手动推送
*/
function showpush() {
    var html = "<div class='u_main'>" +
        "<div >" +
        "<p>" +
        "<span>请选择域名</span> " +
        "<select onchange='addSdSitemapUrl()' id='host' name='host' class='bt-input-text mr5 bt-select2'>" +
        "<option  value=''>请选择一个域名(已配置域名)</option>" +
        "</select>" +
        "</p>" +
        "</div>" +
        "<div class='u_config'>" +
        "<p>请输入域名对应的网址列表(多个网址请换行,不要留空行)</p>" +
        "<textarea id='sd_hosts' name='sd_hosts' placeholder='请输入网址,例如:http://www.waytomilky.com/archives/738.html' cols='80' rows='4'></textarea>" +
        "<p>尽量不要使用重复网址,会导致降额</p>" +
        "<button  onclick='sdpush()' class='btn btn-success btn-sm '><i class=\"fa fa-link\" aria-hidden=\"true\"></i> 推送网址列表</button>" +
        "</div>" +
        "<div class='u_config'>" +
        "<p>远程sitemap.xml地址,需要与选择的域名对应</p>" +
        "<p ><i class='red'>*&nbsp;</i>开启了强制https跳转的网站,请转换为https网址</p>" +
        "<p><i class='red'>*&nbsp;</i>务必测试下能不能正常访问再推送，如果您的站点链接非常多，为避免超时建议直接使用【定时推送】</p>" +
        "<p><i class='red'>*&nbsp;</i>检查下是否为标准sitemap.xml，建议单文件链接数不超过5000条  <a class='btlink' target='_blank' href='https://www.waytomilky.com/sitemap.xml'>参考地址</a></p>" +
        "<p><input id='sitemap_url' name='sitemap_url' placeholder='例如http://www.waytomilky.com/sitemap.xml' class='bt-input-text'>" +
        " <button onclick='sw_https(this)' class='btn btn-sm'>使用https</button>" +
        // "&nbsp;<button class='btn btn-default btn-sm'>使用https</button>" +
        "</p>" +
        "<p><button onclick='mpush(sitemap_url)' class='btn btn-success btn-sm'><i class=\"fa fa-sitemap\" aria-hidden=\"true\"></i> 推送sitemap</button></p>" +
        "</div>" +
        "<div class='u_config'>" +
        "<p>请输入自定义网址(抓取页面链接进行推送,开启了强制跳转https的网站转换为https网址)</p>" +
        "<p><input id='mainurl' name='mainurl' placeholder='例如:http://www.waytomilky.com' class='bt-input-text'>" +
        " <button onclick='sw_https(this)'  class='btn btn-sm sw_https'>使用https</button>" +
        "</p>" +
        "<p><button onclick='tsMain()' class='btn btn-success btn-sm'><i class=\"fa fa-link\" aria-hidden=\"true\"> 抓取链接推送</button></p>" +
        "</div>" +
        "</div>";
    $('.plugin_body').html(html);
    var index = layer.load();
    request_plugin('get_hosts', {}, function (res) {
        layer.close(index);
        $("#host").append(res.data.options);
    });
}

function sw_https(obj) {
    var node = $(obj).parent('p').children('input');
    var url = node.val();
    if (url == '' || url == null) {
        layer.msg('请输入地址哦', {icon: 2});
        return false;
    }
    var new_url = url.replace(/http:/, "https:");
    $(node).val(new_url);
    layer.msg('已转换成https网址', {icon: 1});
}

//抓取网址上的链接进行推送
function tsMain() {
    index = layer.msg('正在推送中...', {icon: 16, time: 0});
    var mainurl = $("#mainurl").val();
    var host = $("#host").val();
    request_plugin('tsMain', {mainurl: mainurl, host: host}, function (res) {
        layer.close(index);
        if (res.code == 0) {
            //layer.alert(res.msg, {title: '推送结果', area: ['650px', '650px']});
            lotus_show('推送结果',res.msg,650,650);
        }
        if (res.code < 0) {
            layer.alert(res.msg, {icon: 2});
        }
    })
}


//sitemap推送
function mpush() {
    var sitemap_url = $("#sitemap_url").val();
    var host = $("#host").val();
    index = layer.msg('正在推送中...', {icon: 16, time: 0});
    request_plugin('mpush', {sitemap_url: sitemap_url, host: host}, function (res) {
        layer.close(index);
        if (res.code == 0) {
            //layer.alert(res.msg, {title: '推送结果', area: ['650px', '650px']});
            lotus_show('推送结果',res.msg,650,650);
        }
        if (res.code < 0) {
            layer.msg(res.msg, {icon: 2});
        }
    })
}


//手动推送
function sdpush() {
    var sd_hosts = $("#sd_hosts").val();
    var host = $("#host").val();
    index = layer.msg('正在推送中...', {icon: 16, time: 0});
    request_plugin('sdpush', {sd_hosts: sd_hosts, host: host}, function (res) {
        layer.close(index);
        if (res.code == 0) {
            layer.alert(res.msg, {title: '推送结果', area: ['650px', '650px']});
        }
        if (res.code < 0) {
            layer.msg(res.msg, {icon: 2});
        }
    })
}

/**
 * 发送请求到插件
 * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
 * @param plugin_name    插件名称 如：demo
 * @param function_name  要访问的方法名，如：get_logs
 * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"demo.get_logs"}
 * @param callback       请传入处理函数，响应内容将传入到第一个参数中
 */
function request_plugin(function_name, args, callback, method) {
    var timeout = 120 * 1000;
    if (!method) method = 'POST';
    if (args == '' || args == null) {
        args = {
            "token": "test"
        };
    }
    $.ajax({
        type: 'POST',
        url: '/plugin?action=a&s=' + function_name + '&name=urlpush',
        data: args,
        timeout: timeout,
        success: function (rdata) {
            if (rdata !== null && rdata.code === 2) {
                layer.alert(rdata.msg, {icon: 2, time: 5000},function () {
                    location.reload();
                });
                return false;
            }
            if (!callback) {
                layer.msg(rdata.msg, {icon: rdata.status ? 1 : 2});
                return;
            }
            return callback(rdata);
        },
        error: function (ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', {icon: 2});
                return;
            }
            return callback(ex);
        }
    });
}


function about() {

    var html =
        "  <div id=\"404_logo\" align=\"center\"><a target='_blank' href='https://www.waytomilky.com/'><img src='https://www.waytomilky.com/usr/uploads/2019/04/2930328315.png'></a></div><br/>\n" +
        "                <div id=\"404_dev\" >\n" +
        "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>注意:</b></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>1、插件依赖PHP版本7.1，不影响网站设置，请务必安装下。</td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>2、对应的api填写即可推送，不填则不推送。</td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>3、建议用【批量推送任务】</td></tr>\n" +


        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td id='msg'>欢迎使用插件,觉得好的话给个好评哦!</td></tr>\n" +


        // "                        <tr ><td>&nbsp;</td></tr>\n" +
        // "                        <tr ><td>2.插件依赖PHP-CLI>=5.4 此项在宝塔面板 【网站】->【PHP命令行版本】中修改</td></tr>\n" +

        // "<p>1.此插件依赖PHP>=7.0,未安装的请安装下其中任意版本,不影响其他网站设置.其次设置定时推送前,建议手动测试下 </p>" +
        // "<p>2.请输入域名(不是网址),和对应至少一个完整的API信息,<a class='btlink' target='_blank' href='https://www.waytomilky.com/archives/1950.html'>如何获取百度和神马API参考地址?</a></p>" +
        // "<p>3.  [网址去重] 为全局配置,手动和定时均生效</p>" +
        // "<p>4.  [网址过滤] 为空无限制,填入过滤信息,譬如有效网址包含archives关键词为有效网址,就填入article,多个用#号隔开</p>" +


        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>关于插件:</b></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><a target='_blank' href='https://www.waytomilky.com/'>开发人员： 阿修罗</a></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>官方网站： <a target='_blank' class='green' href='https://www.waytomilky.com/'>https://www.waytomilky.com/</a></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>QQ群支持：<a target=\"_blank\" href=\"//shang.qq.com/wpa/qunwpa?idkey=289eaf4dfef0cc9220256b90ff502bef467767f6f790b817ce1cbe7658b5b3b3\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"PHP-LotusAdmin&amp;宝塔插件反\" title=\"PHP-LotusAdmin&amp;宝塔插件反\"></a></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>别点我：<a style='color:green' target='_blank' href='https://www.bt.cn/?invite_code=MV9heHlhemM='>领取宝塔优惠券</a> </td></tr>\n" +


        "                    </table>\n" +
        "                </div>\n" +
        "                </div>";
    $('.plugin_body').html(html);
    request_plugin('about', {}, function (res) {
        var msg = res.msg;
        if (msg == null) {
            msg = "欢迎使用插件,觉得好的话给个好评哦!";
        }
        $("#msg").html(msg);
    })


}

function sw_cron(id) {
    var args = {
        id: id
    }
    request_plugin('sw_cron', args, function (rdata) {
        tip(rdata, function () {
            pro();
        });
    })
}
function service_status()
{
    var html = "<div class='u_main'>" +
        "<p><label>功能说明：</label>此功能可设置【批量推送】定时任务，在【域名配置】开启【批量推送】的站点都可以推送，适合站点多的用户。</p>" +
        "<p style='line-height: 30px'> <label>状态(批量任务)</label>  <span class='status' style='width: 20px;'></span>    </p>" +
        "<p style='line-height: 30px'><label>操作</label> <button onclick='add_sync_task_new()' class='btn  btn-sm'>添加定时守护任务(启动服务)</button>  </p>" +
        "<p style='line-height: 30px'><label>查看任务</label> 添加的定时任务名为:<b>"+cron_title+"</b></p>" +
        "<p style='line-height: 30px'><label>任务说明</label> 默认创建的定时任务执行时间为每天凌晨 01:30执行 ，时间可根据需求自行调整，您也可以手动执行该定时任务。 <a class='btlink' href='/crontab' target='_blank'>查看任务</a> </p>" +
        "</div>";
    $('.plugin_body').html(html);
    get_service_status();
}
function get_service_status()
{
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.status === 1){
            $('.status').html("<span style='width: 20px;' class='play'><i style='color: #20a53a' class=\"fa fa-play \" aria-hidden=\"true\"></i></span>");
        }
        if(res.data.status === 0){
            $('.status').html(" <span style='width: 20px;' class='stop'><i style='color: red' class=\"fa fa-stop \" aria-hidden=\"true\"></i></span>");
        }
    })
}
function  success(msg,callback){
    layer.msg(msg,suc_icon,callback);
}
function add_sync_task_new()
{
    request_plugin("add_sync_task_new",{cron_title:cron_title},function (res) {
        if(res.code === 0){
            var shell = res.data.shell;
            //存储域名
            var args = {
                "name":cron_title,
                "type":"day",
                "where1":"",
                "hour":1,
                "minute":30,
                "week":"",
                "sType": "toShell",
                "sBody": shell,
                "sName":"",
                "backupTo": "localhost",
                "save":"",
                "urladdress":""
            };
            $.ajax({
                type:'POST',
                url: '/crontab?action=AddCrontab',
                data: args,
                success: function(rdata) {
                    console.log(rdata);
                    success(res.msg,get_service_status );
                    //get_service_status();
                },
                error: function(ex) {
                    //layer.msg('请求过程发现错误!', { icon: 2 });
                }
            });
        }else{
            error(res.msg);
        }
    },'get');
}
function  error(msg){
    layer.msg(msg,err_icon);
}
function api_mng()
{
    var html = "<div class='u_main'>" +
        "<div style='width: 849px' class='u_pro divtable  '>" +
        "<p> <button class='btn btn-success' onclick='save_api()'>添加api</button> </p>" +
        "<p>  此功能是方便站长储存信息，辅助填写信息用。避免跨站长后台，进行复制粘贴繁琐操作。适合站长账号多的用户使用，提高效率！ </p>" +
        "<table class='table table-hover'>" +
        "<thead> <tr>   <th>类型</th> <th>备注</th> <th>Api</th> <th width='100'>操作</th> </tr>  </thead>" +
        "<tbody class='tbody'></tbody>" +
        "  </table>" +
        "</div>"+
        "</div>";
    $('.plugin_body').html(html);
    var tbody = '';
    request_plugin('api_list',{},function (rdata) {
        rdata.data.forEach(function (item) {
            var api = item.api;
            if( item.api.length > 50){
                api = api.substring(0,50)+'...';
            }
            var json = '{' +
                '"id":"'+item.id+'",' +
                '"type":"'+item.type_int+'",' +
                ' "remark":"'+item.remark+'",' +
                ' "api":"'+item.api+'"}';
            tbody += '<tr>' +
                '<td class="btlink">'+item.type+'</td>' +
                '<td>'+item.remark+'</td>' +
                '<td title="'+item.api+'">'+api+'</td>' +
                '<td> ' +
                    "<button data-api='"+json+"' class=\"btn btn-primary btn-xs\" onclick=\"save_api(this)\">编辑</button>&nbsp;&nbsp;" +
                    '<button onclick="del_api('+item.id+')" class="btn btn-danger btn-xs">删除</button> ' +
                '</td>' +
                '</tr>'
        })
        $(".tbody").html(tbody);
    })
}
function save_api(obj = null)
{
    var form  =  "<div class='u_main'> <form id='sub_form' action='save_api' method='post'>" +
        "<input type='hidden' name='id'>" +
        "<p><label>类型</label>  <select id='type' required name='type' style='width: 200px' class='bt-input-text'> " +
            "<option value='1'>百度token</option>" +
            "<option value='2'>必应api</option>" +
            "<option value='3'>头条cookie</option> " +
        "</select> </p>" +
        "<p><label>备注</label>  <input required placeholder='请输入备注，比如注册邮箱，账号名，方便快速区分或记忆' name='remark' class='bt-input-text'> </p>" +
        "<p><label>API内容</label> 请输入对应的 百度token、必应api、头条cookie。 <a class='btlink' target='_blank' href='http://www.waytomilky.com/archives/1950.html'> 如何获取？ </a>  </p>" +
        "<p><label></label>  <textarea required name='api' placeholder='请输入对应的单条 百度token、必应api、头条cookie' rows='10' cols='58'></textarea> </p>" +
        "<p class='center'> <button class='btn btn-success' type='submit'><i class=\"fa fa-floppy-o\" aria-hidden=\"true\"></i>&nbsp;保存</button> </p>" +
        "</form> </div>";
    lotus_show('添加api',form,600,550);
    if(obj != null){
        var j_str = $(obj).attr('data-api');
        var item = JSON.parse(j_str);
        console.log(item.type);
        $("input[name=id]").val(item.id);
        $("select[name=type]").val(item.type);
        $("input[name=remark]").val(item.remark);
        $("textarea[name=api]").val(item.api);
    }
    sub_form('#sub_form','save_api',function (rdata) {
        if(rdata.code == 0){
            success(rdata.msg,function () {
                layer.close(layer_index);
                api_mng();
            });
        }
        else{
            error(rdata.msg);
        }
    });
}
function del_api(id)
{
    layer.confirm('<span class="red">确认删除?</span>', {
            title:'操作提示',
            btn: ['确定','取消'], //按钮
        }, function(){
            loading();
            request_plugin('del_api',{id,id},function (res) {
                success(res.msg,function () {
                    layer.close(layer_index);
                    close_loading();
                    api_mng();
                })
            });
        })
}

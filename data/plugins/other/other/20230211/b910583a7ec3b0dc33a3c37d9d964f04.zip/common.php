<?php
define('PLU_PATH',__DIR__);
define('PLUGIN_PATH',__DIR__);
define('UA','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.124 Safari/537.36 Edg/102.0.1245.41');

class  Common {
    function gen_url($xieyi,$host,$url_rule){
        while(strstr($url_rule,'{字母}')){
            $randstr = $this->rand_str();
            $url_rule = preg_replace('/{字母}/',$randstr,$url_rule,1);
        }
        while(strstr($url_rule,'{数字}')){
            $randstr = $this->rand_num();
            $url_rule = preg_replace('/{数字}/',$randstr,$url_rule,1);
        }
        while(strstr($url_rule,'{日期}')){
            $randstr = date('Ymd');
            $url_rule = preg_replace('/{日期}/',$randstr,$url_rule,1);
        }
        
        return $xieyi.$host.$url_rule."\n";
    }
    public function rand_str($lenth = 3){
        $chars    = 'abcdefghijklmnopqrstuvwxyz';
        $password = '';
        for ($i = 0; $i < $lenth; $i++) {
            $password .= $chars[mt_rand(0, strlen($chars) - 1)];
        }
        return $password;
    }
    public function rand_num(){
        return  rand(100,999);
    }
    function get_os(){
        if(PHP_OS == 'WIN32' || PHP_OS == 'WINNT' || PHP_OS == 'Windows'){
            $os = 'windows';
        }else{
            $os = 'linux';
        }
        return $os;
    }
}

class ApiModel extends \think\Model
{
    protected $name = 'api';
    const TYPE_MAP = [
        1=>'百度token',
        2=>'必应api',
        3=>'头条cookie'
    ];
    public function getTypeAttr($value,$data)
    {
        return self::TYPE_MAP[$value];
    }
}

class TtsiteModel extends \think\Model
{
    protected $name = 'ttsite';
}

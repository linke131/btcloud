<?php
require  'vendor/autoload.php';
require 'index.php';


use QL\QueryList;
use QL\Ext\AbsoluteUrl;
class console  {
    use UrlTool;
    protected $config_file;
    protected $host_file;
    protected $host;
    protected $sitemap;
    protected $config;
    public    $chunk;
    protected $type;
    protected $dataPath;
    public $tool;
    

    const  DS = "/";
    
    function  __construct($host,$sitemap,$dir,$type){
        $this->dataPath = $dir.'/static/';
        $this->host = $host;
        $this->sitemap = $sitemap;
        $this->dir =  $dir;
        $this->config_file = $dir."/static/config.json";
        $this->host_file = $dir."/static/host.ini";
        $this->config = $this->read_config();
        $this->chunk = CHUNK;
        $this->type = $type;
        $this->tool = new tool();
        config_db();
        $this->init();
    }


    
    function init(){
        $chunk = $this->chunk;
        $this->get_info();
        if($this->type == 1){
            $urls = $this->getXmlUrls($this->sitemap);
        }
        if($this->type == 2){
            $urls =  $this->getMainUrls();
        }
        $msg =  $this->fenPush($urls);
        echo $msg;
    }

    //获取推送过的地址
    function get_urls_arr($host){
        $info = file_get_contents($this->dataPath."/".$host);
        return unserialize($info);
    }
    
    
    //是否上次推送
    function get_last_push($host){
        if(!file_exists($this->dataPath."/".$host))
            return [];
        return json_decode(file_get_contents($this->dataPath."/".$host),true);
    }
    
    //处理重复网址
    function handle_repeat_urls($host,$urls){
        $last_urls = $this->get_last_push($host);
        if( empty($last_urls) )
            return $urls;
        $new_arr  = [];
        foreach ($urls as $val){
            if ( !in_array($val,$last_urls) )
                $new_arr[] = $val;
        }
        return $new_arr;
    }
    
    function write_urls($host,$urls){
        $last_push_urls = $this->get_last_push($host);
        $no_history = [];
        if(empty($last_push_urls)){
            file_put_contents($this->dataPath.self::DS.$host,json_encode($urls));
            return;
        }
        foreach ($urls as $val){
            if(!in_array($val,$last_push_urls)){
                $no_history[] = $val;
            }
        }
        if(empty($urls)){
            return;
        }
        $urls = array_merge($no_history,$last_push_urls);
        file_put_contents($this->dataPath.self::DS.$host,json_encode($urls));
    }
    
    function get_gl_url($host,$urls){
        $config  = $this->get_config_json();
        $new_arr = [];
        if(preg_match("/#/",$config[$host]['gl'])) {
            $gl_arr = explode("#",$config[$host]['gl']);
            foreach ($gl_arr as $val){
                foreach ($urls as $v){
                    if(preg_match("/".$val."/",$v)){
                        $new_arr[] = $v;
                    }
                }
            }
        }else{
            foreach ($urls as $v){
                if(preg_match("/".$config[$host]['gl']."/",$v)){
                    $new_arr[] = $v;
                }
            }
        }
        
        return $new_arr;
        
    }
    function get_nei($host,$urls){
        $arr = [];
        foreach ($urls as $url){
            if(preg_match("/$host/",$url)){
                $arr[] = $url;
            }
        }
        return $arr;
    }
    function fenPush($urls){
        $urls = array_unique($urls);
        //去重
        $host = $this->host;
        $config  = $this->get_config_json();
        if($config[$host]['is_push_last'] == 1){
            $urls = $this->handle_repeat_urls($host,$urls);
        }
        $urls = $this->get_nei($host,$urls);
        //格式化网址
        $urls = $this->format_url($host,$urls);
        //输出网址
        foreach ($urls as $key=>$v){
            echo $v."\n";
        }
        
        if(empty($urls)){
            return "插件警告:\n 1.推送的链接全部为重复网址或者过滤后无有效网址.\n 2.请尝试修改该域名的[网址去重]和[网址过滤]设置进行调整.\n";
        }
        
        $msg = "";
        $chunk = $this->chunk;
        if(count($urls)>$chunk){
            $msg .= "推送总数:".count($urls);
            $url_chunk = array_chunk($urls,$chunk);
            $i  =  0;
            foreach ($url_chunk as $value){
                $i ++;
                $msg .= "\n-------------网址数量大于".$chunk.",自动启用分批推送,每批".$chunk."条,当前第".$i."批--------------".$this->push_all($this->host,$value,false);
            }
        }else{
            $msg = $this->push_all($this->host,$urls,true);
        }
    
//        if(!empty($config[$host]['tian']) && !preg_match("/快速收录推送成功:0条/",$msg) ){
//            $msg .= "\n其中快速收录推送列表(有可能因为额度无法完全推送,以上面返回值为准)\n";
//            $tian_arr = array_slice($urls,0,$config[$host]['xian']);
//            foreach ($tian_arr as $v ){
//                $msg.= $v."\n";
//            }
//        }
        $this->write_urls($host,$urls);
        //2.5新增内容 todo 日志仍需完善
        //        $log = new Log;
        //        $log->write_log("定时任务推送",$host,$urls);
        return $msg;
    }
    
    function getMainUrls(){
        try{
            $ql = QueryList::getInstance();
            $ql->use(AbsoluteUrl::class,'absoluteUrl','absoluteUrlHelper');
            $urls = $ql->get($this->sitemap,[],[
                    'Referer' => 'https://www.waytomilky.com/',
                    'User-Agent' =>
                        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1',
                ]
            )
                ->absoluteUrl($this->sitemap)
                ->find('a')
                ->attrs('href');
            $arr = $urls->all();
            return $arr;
        }catch (\Exception $e){
            echo '插件爬虫被防火墙拦截，或者目标网址开启了强制https,请修改为https协议网址链接';
            exit;
        }
        
    }

    function  push_all($host,$urls,$is_log = false){
        $config  = $this->get_config_json();
        $host_config = $config[$host];
        //百度主动推送
        $msg = "";
        if( !empty($host_config["zhu"]) ){
            $res =  $this->baidu_push($host,$urls);
            if(isset($res["success"])){
                @$msg .= "\n百度推送成功:".$res["success"]."条,剩余额度".$res["remain"]."条,其中非本站网址".count($res["not_same_site"])."条";
                $this->tool->add_history($host_config['host'],'zhu',$urls);
                //更新额度
                $this->tool->update_remain($host_config['host'],'zhu_remain',$res['remain']);
            }else{
                $msg .= "\n百度推送失败:接口返回".(isset($res["message"])?$res["message"]:"");
            }
        }
        //百度mip推送
        if( !empty($host_config["mip"])){
            $res =  $this->mip_push($host,$urls);
            if(isset($res["success_mip"])){
                if($res["success_mip"] == 0){
                    $msg .= "\n百度mip推送警告:您百度mip接口没有推送额度";
                }else{
                    @$msg .= "\n百度mip推送成功:".$res["success_mip"]."条,剩余额度".(int)$res["reamin_mip"]."条,其中非本站网址".count($res["not_same_site"])."条";
                }
            }else{
                $msg .= "\n百度mip推送失败,接口返回".(isset($res["message"])?$res["message"]:"");
            }
        }
        
        //神马推送
        if( !empty($host_config["shenma"]) ){
            $smres =  $this->sm_push($host,$urls);
            if($smres["returnCode"]==200){
                $msg .= "\n神马mip推送成功:".count($urls)."条(神马官方不提供额度返回)";
                $this->tool->add_history($host_config['host'],'shenma',$urls);
            }else{
                $msg .= "\n神马mip推送失败:配置错误,接口返回".(isset($smres["returnCode"])?$smres["returnCode"]:"");
            }
        }

        if(!empty($host_config["tian"])){
            $xian = $host_config['xian'];
            list($offset,$length) = explode('#',$xian);
            $urls = array_slice($urls,$offset,$length);
            $tt = $this->tian($host,$urls);
            if(isset($tt["success"])){
                $str = "(目标网址从第".$offset."开始,共".$length."条)";
                $msg .= "\n百度快速收录推送成功:".$tt["success_daily"]."条".$str.",剩余".$tt["remain_daily"]."条";
                $msg .= "\n快速收录推送目标网址如下:";
                foreach ($urls as $url){
                    $msg .= "\n".$url;
                }
                if($tt['not_valid']){
                    $msg.= ",其中不合法网址".count($tt['not_valid']).'条,网址如下:';
                    foreach ($tt['not_valid'] as $v){
                        $msg .= "\n".$v;
                    }
                }
                $log_arr["tian"] =  $tt["success_daily"];
            }else{
                $log_arr["tian"] = null;
                $msg .= "\n百度快速收录推送失败,API配置错误或者超额 ".(isset($tt["message"])?$tt["message"]:"");
            }
        }

        //必应推送
        if( !empty($host_config['bing_token']) ){
            $bing_res =  $this->bing_push($host_config,$urls);
            if($bing_res['d'] == null && $bing_res['ErrorCode'] !== 3 ){
                $msg .= PHP_EOL.'必应推送成功:'.count($urls).'条,今日剩余额度'.$bing_res['quota']['DailyQuota'].'条';
                $log_arr['bing'] =  count($urls);
                $this->tool->add_history($host_config['host'],'bing_token',$urls);
                //更新额度
                $this->tool->update_remain($host_config['host'],'bing_remain',$bing_res['quota']['DailyQuota']);
            }else{
                $bing_msg =  $bing_res['Message'];
                $msg .= "\n必应推送失败:api配置错误或者今日额度已用完。接口返回:".$bing_msg;
                $log_arr['bing'] =  null;
                $log_arr['bing'] =  null;
            }
        }

        if(!empty($host_config['tt_cookie'])){
            $tt_res = $this->tt_push($host_config,$urls);
            if($tt_res['code'] == 0){
                $msg .= "\n头条推送成功:".count($urls)."条";
            }else{
                $msg .= "头条推送失败，可能原因:cookie配置错误、今日额度已用完、超过每次推送数量，具体接口返回:".$tt_res['message'];
            }
        }
        
        //熊掌推送
//        if( !empty($host_config["xiong"]) ){
//            $res =  $this->xpush($host,$urls);
//            if( isset($res["success_batch"]) ){
//                @$msg .= "\n熊掌周级推送成功:".$res["success_batch"]."条,剩余额度".(int)$res["remain_batch"]."条,其中非本站网址".count($res["not_same_site"])."条";
//            }else{
//                $msg .= "\n熊掌周级推送失败:配置错误,接口返回".(isset($res["message"])?$res["message"]:"");
//            }
//        }
    
    
        //快速收录推送
//        if( !empty($host_config['tian']) ){
//            //限制提交数量
//            if(!empty($host_config['xian']) && count($urls) > $host_config['xian']  ){
//                $urls = array_slice($urls,0,$host_config['xian']  );
//            }
//
//            $res =  $this->tian($urls);
//            @$res['not_valid'] =  count($res['not_valid']);
//            if( isset($res['success']) ){
//                @$msg .= "\n".'快速收录推送成功:'.$res['success'].'条,剩余额度'.(int)$res['remain_daily'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条'."\n";
//            }else{
//                $msg .= "\n".'快速收录推送失败:配置错误,接口返回'.(isset($res['message'])?$res['message']:'');
//            }
//        }
        
        if(empty($msg)){
           echo "至少开启一个推送类型";
        }
        
        if($is_log){
            file_put_contents($this->dataPath."/p.log","【定时任务推送】<br>推送域名:".$host."<br>推送时间:".date("Y-m-d H:i:s")."<br>推送结果:<a class='btlink'>".$msg."</a><br>-----------------------------------------------------------------<br>",FILE_APPEND);
        }
        //过滤掉一个讨厌的字符
        $msg = preg_replace('/\<br\>/','',$msg).PHP_EOL;
        return $msg;
    }


    function getXmlUrls($sitemap_url){
        try{
            $content =  $this->getHtml($sitemap_url);
        }catch (\Exception $e){
            echo $sitemap_url."地址无法访问哦!";
        }
        
        //$obj = new SimpleXMLElement($content)
        
        $xml = simplexml_load_string($content , 'SimpleXMLElement' , LIBXML_NOCDATA );
        $jsonStr = json_encode($xml);
        $xml_data = json_decode($jsonStr,true);
        
        foreach ($xml_data['url'] as $key => $value) {
            $urls[] =  $value['loc'];
        }
        return $urls;
    }




    function getHtml($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    
    
    protected  function  read_config(){
        return json_decode(file_get_contents($this->config_file));
    }
    
    function baidu_push($host,$urls){
//        $token = $this->config["baidu_token"];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]["zhu"];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array("Content-Type: text/plain"),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch),true);
    }
    function mip_push($host,$urls){
//        $token = $this->config["baidu_token"];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token."&type=mip";
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]["mip"];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array("Content-Type: text/plain"),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch),true);
    }
    function sm_push($host,$urls){
//        $token  =  $this->config["sm_token"];
//        $email  =  $this->config["sm_email"];
//        $api = "http://data.zhanzhang.sm.cn/push?site=".$host."&user_name=".$email."&resource_name=mip_add&token=".$token;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]["shenma"];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER=>0,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array("Content-Type: text/plain"),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    function  xpush($host,$urls){
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]["xiong"];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array("Content-Type: text/plain"),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    //测试数据

//        return  json_decode($result,true);
    function tian($host,$urls){
//        $result = [
//            'success'=>10,
//            'remain'=>9,
//            "success_daily"=>1,
//            "remain_daily"=>9
//        ];
//        return $result;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['tian'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    function get_config_json(){
        $arr = db()->select('web','*');
        $data = [];
        foreach ($arr as $v){
            $host = $v['host'];
            $data[$host] = $v;
        }
        return $data;
        //return json_decode(file_get_contents($this->config_json),true);
    }
//    function get_config_json(){
//        return json_decode(file_get_contents($this->config_file),true);
//    }
    function http_get($req_url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $req_url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8'
            )
        );
        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response,true);
    }
    /**
     * Notes:  bing_push
     * Author: wenhainan
     * DateTime: 2021/4/23
     * Email: whndeweilai@gmail.com
     */
    function bing_push($host_config,$urls){
        $req_url = "https://ssl.bing.com/webmaster/api.svc/json/SubmitUrlBatch?apikey=".$host_config['bing_token'];
        $siteUrl = 'http://'.$host_config['host'];
        if(preg_match("/https/",$urls[0])){
            $siteUrl = 'https://'.$host_config['host'];
        }
        $data = [
            'siteUrl'=>$siteUrl,
            'urlList'=>$urls
        ];
        $data = json_encode($data);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $req_url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data)
            )
        );
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $res = json_decode($response,true);
        $quota = $this->get_bing_quota($siteUrl,$host_config['bing_token']);
        $res['quota'] = $quota['d'];

        return $res;
    }
    function  tt_push($host_config,$urls)
    {
        $url = 'https://zhanzhang.toutiao.com/webmaster/api/link/create';
        $site = TtsiteModel::where('host',$host_config['host'])->find();
        $client = new GuzzleHttp\Client();
        $data = [
            'site_id'=> $site->site_id,
            'urls'=>$urls,
            'frequency'=>86400,
            'submitMethods'=>'url'
        ];
        $res = $client->request('POST', $url, [
            'headers' => [
                'User-Agent' => UA,
                'Cookie'=>$host_config['tt_cookie'],
                'Content-Type'=>'application/json'
            ],
            'verify'=>false,
            'body'=>json_encode($data)
        ])
            ->getBody()
            ->getContents();

        return json_decode($res,true);
    }
    function add_history($host,$type,$urls)
    {
        $config = $this->get_config_json()[$host];
        foreach ($urls as $url){
            $res = db()->select('history','*',[
                'host'=>$host,
                'type'=>$type,
                'url'=>$url
            ]);
            if(empty($res)){
                db()->insert('history',[
                    'host'=>$host,
                    'type'=>$type,
                    'url'=>$url,
                    'create_time'=>time()
                ]);
            }
        }
        //删除数据
        db()->delete('history',[
            'create_time[<]'=>time()-3*24*3600
        ]);
    }
    function get_bing_quota($siteUrl,$bing_token)
    {
        $req_url = "https://ssl.bing.com/webmaster/api.svc/json/GetUrlSubmissionQuota?siteUrl=".$siteUrl."&apikey=".$bing_token;
        $res =  $this->http_get($req_url);
        return $res;
    }


}
//初始化类
echo "开始执行:\n";
$param = $param_arr = getopt("a:b:c:d:");
$console = new console($param["a"],$param["b"],$param["c"],$param['d']);

<?php
require 'vendor/autoload.php';
require  'FileCache.php';
use Medoo\Medoo;
use think\facade\Db;


define('DS',PHP_EOL);
define('BT_DB',__DIR__.'/../../data/default.db');
define('PLU_DB',__DIR__.'/web.db');
define('PLUGIN_NAME','urlpush');
define('RUNTIME_DIR',__DIR__.'/runtime');
define('STATIC_DIR',__DIR__.'/static');
$os = get_os();
if(get_os() == 'linux'){
    define("LOG_PATH",__DIR__.'/../../../../wwwlogs');
}else{
    define("LOG_PATH",__DIR__.'/../../../wwwlogs');
}

function cache($k,$v = ''){
    $cache = new FileCache();
    if(empty($v)){
        return  $cache->get($k);
    }
    $cache->set($k,$v);
}

function bt_db(){
    return new medoo([
        'database_type' => 'sqlite',
        'database_file' => BT_DB
    ]);
}

function db(){
    return new medoo([
        'database_type' => 'sqlite',
        'database_file' => PLU_DB
    ]);
}

function config_db(){
    $config = include PLUGIN_PATH.'/config/database.php';
    Db::setConfig($config);
}



function get_os(){
    if(PHP_OS == 'Linux'){
        $os = 'linux';
    }else{
        $os = 'windows';
    }
    return $os;
}
function get_php_version(){
    $arr = [
        '71',
        '72',
        '73',
        '74',
        '80'
    ];
    $php_version = '';
    foreach ($arr as $v){
        $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
        if(file_exists($cc)){
            $php_version  =  $v;
            break;
        }
    }
    if(empty($php_version)){
        throw new Exception('请安装php>=7.1');
    }
    return $php_version;
}
function is_cli(){
    return preg_match("/cli/i", php_sapi_name()) ? true : false;
}
function get_info(){
    $sm =  file_get_contents(__DIR__.'/static/sm');
    $sm = intval($sm);
    if($sm<time() && $sm !== 0 ){
        $txt = file_get_contents(__DIR__.'/static/ms');
        echo base64_decode($txt);exit;
    }
}
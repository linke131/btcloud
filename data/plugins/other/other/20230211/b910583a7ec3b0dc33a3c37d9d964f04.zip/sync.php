<?php
require 'func.php';
require  'Time.php';
use UAParser\Parser;

class Sync  {
    function __construct()
    {
        get_info();
        @chmod(RUNTIME_DIR,0777);
    }
    function one($name,$line = 180){
        ini_set('memory_limit', '256M');
        $filename = LOG_PATH.'/'.$name.'.log';
        if(!file_exists($filename)){
            $filename = LOG_PATH.'/'.$name.'-access.log';
        }
        try{
            $arr = $this->tail_log($filename,$line);
        }catch (\Exception $e){
            return $e->getMessage();
        }
        $reg = '/^(\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3})\s-\s(.*)\s\[(.*)\]\s"(.*)\"\s(\d{3})\s(\d+)\s"(.*)"\s\"(.*)\"(.*)$/u';
        foreach ($arr as $v){
            preg_match($reg,$v,$a_match);
            $parser = Parser::create();
            $ua = $a_match[8];
            $result = $parser->parse($ua);
            $ua_type = $result->ua->family;
            $sd = db()->get('access_log','*',[
                "host"=>$name,
                'remote_addr'=>$a_match[1],
                'remote_user'=>$a_match[2],
                'time_local'=>strtotime($a_match[3]),
                'request'=>$a_match[4],
                'status'=>$a_match[5],
                'body_bytes_sent'=>$a_match[6],
                'http_user_agent'=>$a_match[7],
                'http_x_forwarded_for'=>$a_match[8],
                'http_referer'=>$a_match[9],
                'ua_type'=>$ua_type
            ]);
            if(!empty($a_match) && empty($sd) ){
                $data = [
                    "host"=>$name,
                    'remote_addr'=>$a_match[1],
                    'remote_user'=>$a_match[2],
                    'time_local'=>strtotime($a_match[3]),
                    'request'=>$a_match[4],
                    'status'=>$a_match[5],
                    'body_bytes_sent'=>$a_match[6],
                    'http_user_agent'=>$a_match[7],
                    'http_x_forwarded_for'=>$a_match[8],
                    'http_referer'=>$a_match[9],
                    'ua_type'=>$ua_type
                ];
                db()->insert('access_log',$data);
            }
        }
    }
    function sync_log($line = 180)
    {
        echo "---同步开始---\n";
        ini_set('memory_limit', '256M');
        $cache = new FileCache();
        $is_first = $cache->get('is_first');
        if(!$is_first){
            $line = 300;
            $cache->set('is_first',1,24*3600);
        }
        //echo $line."\n";
        $web =  bt_db()->select('domain','*');
        $this->del_log();
        foreach ($web as $key => $value) {
            $name = $value['name'];
            $filename = LOG_PATH.'/'.$name.'.log';
            if(!file_exists($filename)){
                $filename = LOG_PATH.'/'.$name.'-access.log';
            }
//            $line = 1000;
            try{
                $arr = $this->tail_log($filename,$line);
            }catch (\Exception $e){
                echo "同步网站访问记录 ".$name." 失败!".$e->getMessage()." \n";
                continue;
            }
            $reg = '/^(\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3})\s-\s(.*)\s\[(.*)\]\s"(.*)\"\s(\d{3})\s(\d+)\s"(.*)"\s\"(.*)\"(.*)$/u';
            foreach ($arr as $v){
                preg_match($reg,$v,$a_match);
                $parser = Parser::create();
                $ua = $a_match[8];
                $result = $parser->parse($ua);
                $ua_type = $result->ua->family;
                $sd = db()->get('access_log','*',[
                    "host"=>$name,
                    'remote_addr'=>$a_match[1],
                    'remote_user'=>$a_match[2],
                    'time_local'=>strtotime($a_match[3]),
                    'request'=>$a_match[4],
                    'status'=>$a_match[5],
                    'body_bytes_sent'=>$a_match[6],
                    'http_user_agent'=>$a_match[7],
                    'http_x_forwarded_for'=>$a_match[8],
                    'http_referer'=>$a_match[9],
                    'ua_type'=>$ua_type
                ]);
                if(!empty($a_match) && empty($sd) ){
                    $data = [
                        "host"=>$name,
                        'remote_addr'=>$a_match[1],
                        'remote_user'=>$a_match[2],
                        'time_local'=>strtotime($a_match[3]),
                        'request'=>$a_match[4],
                        'status'=>$a_match[5],
                        'body_bytes_sent'=>$a_match[6],
                        'http_user_agent'=>$a_match[7],
                        'http_x_forwarded_for'=>$a_match[8],
                        'http_referer'=>$a_match[9],
                        'ua_type'=>$ua_type
                    ];
                    db()->insert('access_log',$data);
                }
            }
            echo "同步网站访问记录 ".$name." 成功! \n";
        }
        echo "---同步结束---\n";
    }
    function del_log(){
        db()->delete('access_log',[
            'time_local[<]'=>\app\Time::daysAgo('3')
        ]);
        echo "清除插件无用数据...\n";
    }
    function tail_log($filename,$n)
    {
        $err_msg = 'no file';
        if(PHP_SAPI == 'cli'){
            $err_msg = "对应日志文件不存在!";
        }
        if(!file_exists($filename)){
            throw new Exception($err_msg);
        }
        $cmd = <<<EOF
tail -n $n $filename
EOF;
        $cmd = escapeshellcmd($cmd);
        try{
            $os = get_os();
            if($os == 'windows'){
                $res = $this->read_file($filename,$n);
            }else{
                @exec($cmd,$res);
            }
        }catch (\Exception $e){
             return $e->getMessage();
        }
        return $res;
    }

    /**
     * Notes:  读取文件
     * Author: 阿修罗
     * DateTime: 2021/7/19
     * Email: whndeweilai@gmail.com
     * @param $file
     * @param $lines
     * @return array
     */
    function read_file($file, $lines)
    {
        $handle = fopen($file, "r+");
        $linecounter = $lines;
        //$pos = cache('pos'.$file);
//        if(empty($pos)){
//            $pos = -2;
//        }
        $pos = -2;
        $beginning = false;
        $text = array();
        while ($linecounter > 0) {
            $t = " ";
            while ($t != "\n") {
                if(fseek($handle, $pos, SEEK_END) == -1) {
                    $beginning = true; break;
                }
                $t = fgetc($handle);
                $pos --;
            }
            $linecounter --;
            if($beginning) rewind($handle);
            $text[$lines-$linecounter-1] = fgets($handle);
            if($beginning) break;
        }
        //cache('pos'.$file,$pos);
        fclose ($handle);
        return array_reverse($text);
    }
    function read_lines($file){
        $handle = fopen($file,"r");//以只读方式打开一个文件
        $i = 0;
        while(!feof($handle)){//函数检测是否已到达文件末尾
            if(fgets($handle)){// 从文件指针中读取一行
                $i++;
            }
        }
        fclose($handle);
        return $i;
    }
    function win_tail_log($file)
    {
        $fp = fopen($file, "r");
        $line = 1;
        $pos = -2;
        $t = " ";
        $data = "";
        while ($line > 0)
        {
            while ($t != "\n")
            {
                fseek($fp, $pos, SEEK_END);
                $t = fgetc($fp);
                $pos--;
            }
            $t = " ";
            $data .= fgets($fp);
            $line--;
        }
        fclose($fp);
        echo $data;

    }
}


//$file = "F:\BtSoft\wwwlogs\www.waytomilky.com.log";
//var_dump(win_tail_log($file));
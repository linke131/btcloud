<?php 

namespace DNS\Module;

use DNS\Config;
use DNS\Validation;
use DNS\Http\Client;
class IPLibrary extends Base
{

    public function getArea()
    {
    	$url = '/api/ip/areaviewlist/';
        list($ret, $error) = $this->postData($url);
        return [$ret, $error];
    }

    public function getISP()
    {
    	$url = '/api/ip/ispviewlist/';
        list($ret, $error) = $this->postData($url);
        return [$ret, $error];
    }

}







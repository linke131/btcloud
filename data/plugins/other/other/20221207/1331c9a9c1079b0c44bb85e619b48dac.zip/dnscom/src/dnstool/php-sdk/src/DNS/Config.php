<?php 

namespace DNS;

class Config
{
    const API_HOST = 'https://www.dns.com';
    const AccessKey = 'c7722149110b7492a2e5cf1d8f3f966b';
    const SecureKey = 'uednqlxnhobdilmmgupjimsm';
}
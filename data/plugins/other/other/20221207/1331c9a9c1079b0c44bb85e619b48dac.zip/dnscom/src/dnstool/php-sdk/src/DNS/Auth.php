<?php

namespace DNS;

class Auth
{
    private $accessKey;
    
    private $secretKey;

    public function __construct($config)
    {
        $this->accessKey = $config['apiKey'];
        $this->secretKey = $config['apiSecret'];
    }

    public function getAccessKey()
    {
        return $this->accessKey;
    }

    public function sign($string)
    {
        // $params = urlencode($params);
        // $hmac = (hash_hmac('sha256', $params, $this->secretKey, false));
        // return $hmac;
        return md5($string . $this->secretKey);
    }



    public function getHash($parameters,$apiSecret){

    }


    public function signRequest($method, $url, $params, $contentType)
    {
        $params['apiKey'] = $this->accessKey;
        $params['timestamp'] = time();
        ksort($params);
        $hashString = '';
        foreach($params as $key => $value){
            $hashString .= ($hashString ? '&' : '') . $key . '=' . $value;
        }
        $params['hash'] = md5($hashString . $this->secretKey);
        return [$url, $params];
    }

    public function authorization($method, $url, $params = null, $contentType = null)
    {
        list($url, $params) = $this->signRequest($method, $url, $params, $contentType);
        return [$url, $params];
    }
}
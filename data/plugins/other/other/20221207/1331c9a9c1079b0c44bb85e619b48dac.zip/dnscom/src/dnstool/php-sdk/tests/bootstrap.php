<?php
// @codingStandardsIgnoreFile
require_once __DIR__.'/../autoload.php';

use DNS\Auth;

use DNS\Module\Account;

$account = new Account;

$params =  [
    // 'email'=>'',
    // 'password'=>'',
    'email'=>'seevan91@163.com',
    'password'=>'190910',
    'reset'=>'0',
    'type'=>'API',
];
list($ret, $error) = $account->verify($params);
// print_r($ret);

$testAuth = new Auth($ret['data']['apiKey'], $ret['data']['apiSecret']);
<?php 

namespace DNS\Module;

use DNS\Config;
use DNS\Validation;
use DNS\Http\Client;

class Product extends Base
{

    //购买服务套餐
    public function buyServer($params)
    {
        $url = '/api/product/buy/server/';
        Validation::isExist([
            'domain',
            'duration',
            'serverID',
        ], $params);
        list($ret, $error) = $this->postData($url, $params);
        return [$ret, $error];
    }

    //服务套餐列表
    public function server()
    {
        $url = '/api/product/server/';
        list($ret, $error) = $this->postData($url);
        return [$ret, $error];
    }

}
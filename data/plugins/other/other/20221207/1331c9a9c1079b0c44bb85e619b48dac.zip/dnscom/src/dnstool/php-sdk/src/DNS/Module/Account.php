<?php 

namespace DNS\Module;

use DNS\Config;
use DNS\Validation;
use DNS\Http\Client;

class Account extends Base
{

    public function verify($params)
    {
        $url = '/api/user/verify/';
        $this->checkVerify($params);
        $params['timestamp'] = time();
        ksort($params);
        $url = Config::API_HOST . $url;
        $ret = Client::post($url, http_build_query($params));
        if( !$ret->ok()) {
            return array(null, $ret);
        }
        return array($ret->json(), null);
    }

    private function checkVerify($params)
    {
        return Validation::isExist([
            'email',
            'password',
            'type'
        ], $params);
    }

    public function detail()
    {
        $url = '/api/user/detail';
        list($ret, $error) = $this->postData($url, []);
        return [$ret, $error];
    }


}
<?php 

use DNS\Module\Product;

class ProductTest extends \PHPUnit_Framework_TestCase
{
    protected function setUp()
    {
        // $this->markTestSkipped();
        global $testAuth;
        $this->product = new Product($testAuth);
    }

    public function testBuyServer()
    {
        $this->markTestSkipped();
        $params = [
            'domain'=>'das2ce2.cc', 
            'duration'=>1, 
            'serverID'=>2
        ];
        list($ret, $error) = $this->product->buyServer($params);
        print_r($ret);
        print_r($error);
        $this->assertNull($error);
        $this->assertEquals($ret['code'], 0);
    }

    public function testServer()
    {
        $this->markTestSkipped();
        list($ret, $error) = $this->product->server();
        print_r($ret);
        print_r($error);
        $this->assertNull($error);
        $this->assertEquals($ret['code'], 0);
    }
}








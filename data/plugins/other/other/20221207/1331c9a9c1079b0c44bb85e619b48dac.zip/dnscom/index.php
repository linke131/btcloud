<?php

use DNS\Auth;
use DNS\Http\Response;
use DNS\Module\Domain;
use DNS\Module\Record;

require_once './src/dnstool/php-sdk/autoload.php';

class bt_main
{
    //不允许被面板访问的方法请不要设置为公有方法

    public $configPath = '../../data/dnscom.conf';


    public function get_config()
    {
        $config = $this->getDnsConfig();
        if ($config === false) {
            $config = [];
        }
        return $this->httpResponse(0, '获取成功', ['data' => $config]);
    }

    public function set_config()
    {
        $apiKey = trim(_post('api_key'));
        $apiSecret = trim(_post('api_secret'));
        if (empty($apiKey) || empty($apiSecret)) {
            return $this->httpResponse(1, 'api_key或api_secret不能为空');
        }
        $config = [
            'apiKey' => $apiKey,
            'apiSecret' => $apiSecret
        ];
        list($rs, $error) = (new \DNS\Module\Account(new Auth($config)))->detail();
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($rs['code'] != 0) {
            return $this->httpResponse(1, '校验失败');
        }
        $w = fopen($this->configPath, 'w');
        fwrite($w, json_encode($config));
        fclose($w);
        return $this->httpResponse(0, '设置成功');
    }

    public function domain_list()
    {
        $domain = trim(_post('domain', ''));
        $page = intval(_post('page', 1));
        $auth = $this->setApiConfig();
        if ($auth === false) {
            return $this->httpResponse(2, '请先配置API信息');
        }
        $apiParams = ['page' => $page, 'getPackage' => 1, 'domain' => (string)$domain, 'pageSize' => 10];
        list($ret, $error) = (new Domain($auth))->getDomainList($apiParams);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        $data = $ret['data'];
        $data['search'] = $domain;
        return $this->httpResponse(0, '获取成功', $data);
    }

    public function domain_add()
    {
        $domain = trim(_post('domain', ''));
        $auth = $this->setApiConfig();
        $apiParams = ['domain' => $domain];
        list($ret, $error) = (new Domain($auth))->addDomain($apiParams);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '添加成功');
    }

    public function domain_delete()
    {
        $domain = trim(_post('domain'));
        if (empty($domain)) {
            return $this->httpResponse(1, '请选择域名');
        }
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Domain($auth))->deleteDomain(['domain' => $domain]);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '删除成功');
    }

    public function pause_domain()
    {
        $domain = trim(_post('domain'));
        if (empty($domain)) {
            return $this->httpResponse(1, '请选择域名');
        }
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Domain($auth))->pauseDomain(['domain' => $domain]);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '暂停成功');
    }

    public function start_domain()
    {
        $domain = trim(_post('domain'));
        if (empty($domain)) {
            return $this->httpResponse(1, '请选择域名');
        }
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Domain($auth))->startDomain(['domain' => $domain]);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '启用成功');
    }

    public function record_list()
    {
        $domainID = trim(_post('domainID'));
        $page = intval(_post('page', 1));
        $type = trim(_post('type', 'host'));
        $search = trim(_post('search', ''));
        if (empty($domainID)) {
            return $this->httpResponse(1, '参数错误');
        }
        $auth = $this->setApiConfig();
        $apiParams = ['domainID' => $domainID, 'page' => $page, 'pageSize' => 10];
        $type = !empty($type) ? $type : 'host';
        $search = !empty($search) ? $search : '';
        $apiParams[$type] = $search;
        list($ret, $error) = (new Record($auth))->getRecordList($apiParams);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        $views = $this->getViews($domainID);
        $dnsViews = [];
        foreach ($views['dns_view'] as $v) {
            $dnsViews[$v['id']] = $v['view_name'];
        }
        foreach ($ret['data']['data'] as $k => $v) {
            $ret['data']['data'][$k]['viewName'] = isset($dnsViews[$v['viewID']]) ? $dnsViews[$v['viewID']] : $v['viewID'];
        }
        $data = $ret['data'];
        $data['search'] = $search;
        $data['type'] = $type;
        $data['ns'] = $this->get_ns($domainID);
        return $this->httpResponse(0, '获取成功', $data);
    }

    public function pause_record()
    {
        $domainID = intval(_post('domainID'));
        $recordID = intval(_post('recordID'));
        if (empty($domainID) || empty($recordID)) {
            return $this->httpResponse(1, '参数错误');
        }
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Record($auth))->pauseRecord(['domainID' => $domainID, 'recordID' => $recordID]);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '暂停成功');
    }

    public function start_record()
    {
        $domainID = intval(_post('domainID'));
        $recordID = intval(_post('recordID'));
        if (empty($domainID) || empty($recordID)) {
            return $this->httpResponse(1, '参数错误');
        }
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Record($auth))->startRecord(['domainID' => $domainID, 'recordID' => $recordID]);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '启用成功');
    }

    //删除解析
    public function del_record()
    {
        $domainID = intval(_post('domainID'));
        $recordID = intval(_post('recordID'));
        if (empty($domainID) || empty($recordID)) {
            return $this->httpResponse(1, '参数错误');
        }
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Record($auth))->deleteRecord(['domainID' => $domainID, 'recordID' => $recordID]);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '删除成功');
    }

    //添加解析
    public function add_record()
    {
        $domainID = intval(_post('domainID'));
        $host = trim(_post('host'));
        $type = trim(_post('type'));
        $value = trim(_post('value'));
        $ttl = intval(_post('ttl'));
        $mx = intval(_post('mx'));
        $viewID = trim(_post('viewID'));
        $auth = $this->setApiConfig();
        $params = [
            'domainID' => $domainID,
            'host' => $host,
            'type' => $type,
            'value' => $value,
            'TTL' => $ttl,
            'mx' => $mx,
            'viewID' => $viewID,
        ];
        $check = $this->checkAddRecord($params);
        if ($check !== true) {
            return $this->httpResponse(1, $check);
        }
        list($ret, $error) = (new Record($auth))->addRecord($params);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '添加成功');
    }

    //添加解析
    public function edit_record()
    {
        $domainID = intval(_post('domainID'));
        $recordID = intval(_post('recordID'));
        $host = trim(_post('host'));
        $type = trim(_post('type'));
        $value = trim(_post('value'));
        $ttl = intval(_post('ttl'));
        $mx = intval(_post('mx'));
        $viewID = trim(_post('viewID'));
        $auth = $this->setApiConfig();
        $params = [
            'domainID' => $domainID,
            'recordID' => $recordID,
            'newhost' => $host,
            'newtype' => $type,
            'newvalue' => $value,
            'newttl' => $ttl,
            'newmx' => $mx,
            'newviewID' => $viewID,
        ];
        $check = $this->checkEditRecord($params);
        if ($check !== true) {
            return $this->httpResponse(1, $check);
        }
        list($ret, $error) = (new Record($auth))->editRecord($params);
        if (!empty($error)) {
            return $this->httpResponse(1, '网络异常');
        }
        if ($ret['code'] != 0) {
            return $this->httpResponse(1, $ret['message']);
        }
        return $this->httpResponse(0, '添加成功');
    }

    private function checkAddRecord($params)
    {
        if (empty($params['domainID'])) {
            return '域名ID不能为空';
        }
        if (empty($params['host'])) {
            return '主机记录不能为空';
        }
        if (empty($params['type'])) {
            return '记录类型不能为空';
        }
        if (empty($params['value'])) {
            return '记录值不能为空';
        }
        return true;
    }

    private function checkEditRecord($params){
        if (empty($params['domainID'])) {
            return '域名ID不能为空';
        }
        if (empty($params['recordID'])) {
            return '记录ID不能为空';
        }
        if (empty($params['newhost'])) {
            return '主机记录不能为空';
        }
        if (empty($params['newtype'])) {
            return '记录类型不能为空';
        }
        if (empty($params['newvalue'])) {
            return '记录值不能为空';
        }
        return true;
    }

    private function getViews($domainID)
    {
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Record($auth))->getViews(['domainID' => $domainID]);
        if (!empty($error)) {
            return [];
        }
        if ($ret['code'] != 0) {
            return [];
        }
        return $ret['data'];
    }

    private function get_ns($domainID)
    {
        $auth = $this->setApiConfig();
        list($ret, $error) = (new Domain($auth))->getNS(['domainID' => $domainID]);
        if (!empty($error)) {
            return [];
        }
        return isset($ret['data']) ? $ret['data'] : [];
    }

    /**
     * @return false|mixed
     */
    private function getDnsConfig()
    {
        if (!file_exists($this->configPath)) {
            return false;
        }

        $config = json_decode(file_get_contents($this->configPath), true);
        return $config;
    }

    private function setApiConfig()
    {
        $config = $this->getDnsConfig();
        if ($config === false) {
            return false;
        }
        return new Auth($config);
    }

    private function httpResponse($code, $message, $data = [])
    {
        $res = [
            'code' => $code,
            'msg' => $message,
        ];
        $data = array_merge($res, $data);
        return (new Response(200, 0, ['Content-Type' => 'application/json'], json_encode($data)))->toJson();
    }
    /*
	public function test(){
		//_post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
		//可通过_version()函数获取面板版本
		//可通过_post('client_ip') 来获取访客IP

		//常量说明：
		//PLU_PATH 插件所在目录
		//PLU_NAME 插件名称
		//PLU_FUN  当前被访问的方法名称
		return array(
			_get(),
			_post(),
			_version(),
			PLU_FUN,
			PLU_NAME,
			PLU_PATH
		);
	}

	//获取phpinfo
	public function phpinfo(){
		return phpinfo();
	}*/
}


?>
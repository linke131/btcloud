#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 龙珠防红
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   防红短网址生成工具
# +--------------------------------------------------------------------
import json
import os
import sys

# 设置运行目录
os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")
import requests, json

# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect


class lzfhdwz_main:
    __plugin_path = "/www/server/panel/plugin/lzfhdwz/"
    __config = None

    # 构造方法
    def __init__(self):
        pass

    def short(self, args):
        url = 'https://www.lzfh.com/api/dwz.php'
        postData = {'cb': args.cb,  'longurl': args.long_url, 'sturl': args.sturl}
        data = requests.post(url, data=postData, timeout=60)
        try:
            jsonData = data.json()
        except:
            return {'result': 0, 'msg': '生成失败，请重试或更换其他短网址!'}
        else:
            if jsonData['result']==0:
                return {'result': 0, 'msg': jsonData['msg']}
            return jsonData

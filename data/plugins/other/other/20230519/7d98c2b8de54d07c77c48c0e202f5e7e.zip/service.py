'''
@author 旧雨楼
@email  whndeweilai@163.com
@qq     610176732
'''
from alipan_main import *
import  zipfile,public,os,sys

basedir = os.path.abspath(os.path.dirname(__file__))
os.chdir("/www/server/panel")
sys.path.append("class/")
plugin_path = "/www/server/panel/plugin/alipan"
common_path = '/宝塔阿里云盘'
init_dir = plugin_path+common_path
runtime_path = plugin_path+'/runtime'

class sync(alipan_main):
    def __init__(self):
        ali = Aligo()
        remote_folder = ali.get_folder_by_path(common_path)
        if (not remote_folder):
            ali.upload_folder(init_dir)
            remote_folder = ali.get_folder_by_path(common_path)
        self.remote_folder = remote_folder
        self.file_id = remote_folder.file_id
        self.upload_web()
        self.upload_db()
        super().rm_dir_files(runtime_path)
    def des_dir(self, path):
        new_dir =  plugin_path+"/runtime/"+path
        super().disk_info()
        ali = Aligo()
        des = common_path + '/' + path
        if not os.path.exists(new_dir):
            os.mkdir(new_dir)
            ali.upload_folder(new_dir,parent_file_id=self.remote_folder.file_id)
        os.rmdir(new_dir)
        return ali.get_folder_by_path(des).file_id
    def upload_web(self):
        ali = Aligo()
        webs = super().Db('web').get()
        for i in range(len(webs)):
            web = webs[i]
            name = web['name'] + '_web_' + super().get_time("%Y%m%d%H%M%S")+'.zip'
            des_file_name = runtime_path+'/'+name
            print('压缩文件:'+name+"\n")
            is_zip =  super().Zip(web['path'],des_file_name)
            if is_zip:
                ali.upload_file(des_file_name, self.file_id)
                os.remove(des_file_name)
                log_data = ("备份网站", '成功上传%s 目标 %s' % (web['name'], name), super().get_time())
                super().add_log(log_data)

    def upload_db(self):
        ali = Aligo()
        dbs = super().Db('database').get()
        port = self.Db('conf').where('key = ?','port').getField('val')
        password = self.Db('conf').where('key = ?','mysql_root').getField('val')
        for i in range(len(dbs)):
            db = dbs[i]
            db_name = db['name']
            pure_name = db_name+"_db_"+super().get_time("%Y%m%d%H%M%S")
            file_name = plugin_path+"/runtime/"+pure_name

            save_file_path = file_name+".sql"
            shell = "mysqldump -R -E --hex-blob --opt --single-transaction --force --set-gtid-purged=off  --default-character-set=utf8mb4  -P%s  -uroot  -p%s %s > %s " % (port,password,db_name,save_file_path)
            os.system(shell)
            back_zip = file_name+".zip"
            file_obj = open(back_zip,'w')
            file_obj.close()
            # step 2: 实例化zipfile对象
            zip = zipfile.ZipFile(back_zip, 'w', zipfile.ZIP_DEFLATED)
            # step 3: 写压缩文件
            zip.write(save_file_path,pure_name+'.sql')
            zip.close()
            ali.upload_files([back_zip],self.file_id)
            log_data = ("备份数据库", '成功上传%s 目标 %s' % (db['name'], pure_name+".zip"), super().get_time())
            super().add_log(log_data)
            os.remove(save_file_path)
            os.remove(back_zip)

if __name__ == '__main__':
    sync()
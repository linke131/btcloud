#!/bin/bash
import json,sys,os

import alipan_main
from alipan_main import *

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
    sys.path.append("class/")
except :
    os.chdir(os.path.join(basedir, '..', '..'))
    sys.path.append("class/")
    plugin_path = basedir.rstrip('/')+'/'
import   public

class clear_plugin(alipan_main):
    def __init__(self):
        self.clear_cron()
    def clear_cron(self):
        public.M('crontab').where('name=?', alipan_main.cron_title).delete()
if __name__ == "__main__":
    clear_plugin()
'''
@author 旧雨楼
@email  whndeweilai@163.com
@qq     610176732
'''
from alipan_main import *
import  zipfile,public,os,sys

basedir = os.path.abspath(os.path.dirname(__file__))
os.chdir("/www/server/panel")
sys.path.append("class/")
plugin_path = "/www/server/panel/plugin/alipan"
common_path = '/宝塔阿里云盘'
init_dir = plugin_path+common_path

class test(alipan_main):
    def __init__(self):
        ali = Aligo()
        remote_folder = ali.get_folder_by_path(common_path)
        if (not remote_folder):
            ali.upload_folder(init_dir)
            remote_folder = ali.get_folder_by_path(common_path)
        self.remote_folder = remote_folder
        self.file_id = remote_folder.file_id

            # os.remove(save_file_path)
            # os.remove(back_zip)
if __name__ == '__main__':
    test()
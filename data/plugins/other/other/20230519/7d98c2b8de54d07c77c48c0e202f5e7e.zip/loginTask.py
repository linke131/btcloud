from alipan_main import *
from aligo import *

basedir = os.path.abspath(os.path.dirname(__file__))
plugin_path = "/www/server/panel/plugin/alipan"
common_path = '/宝塔阿里云盘'
init_dir = plugin_path+common_path

class loginInit(alipan_main):
    def __init__(self):
        ali = Aligo()
        ali.get_user()

if __name__ == "__main__":
    loginInit()
var obj = {
    plugin_name: 'alipan',
    timeout: 30*1000,
    progress: '',
    success_icon:1,
    error_icon:2,
    init: function () {
        this.display('nologin.html');
        setTimeout(function () {
            obj.display('login.html',false);
        },100);
    },
    logout:function () {
          layer.confirm("是否清空记录？",{
                btn: ['确定', '取消']
            }, function () {
                var index =  layer.msg('处理数据中...',{icon:16,time:0});
                obj.request_plugin('logout',{},function (rdata) {
                    layer.close(index);
                    if(rdata.status){
                            success(rdata.msg,function (response){
                                obj.init();
                            });
                    }else{
                            error(rdata.msg);
                    }
                })
            });


    },
    login:function(){
        this.display('login.html',false);
    },
    add_sync_task:function () {
        this.request_plugin('add_sync_task',{},function(rdata){
           if(rdata.status){
                success(rdata.msg,function (response){
                    obj.crontab();
                });
           }else{
                error(rdata.msg);
           }
        });
    },
    stop_sync_task:function() {
        this.request_plugin('stop_sync_task',{},function(rdata){
           if(rdata.status){
                success(rdata.msg,function (response){
                    obj.crontab();
                });
           }else{
                error(rdata.msg);
           }
        });
    },
    start_task:function () {
         this.request_plugin('start_task',{},function(rdata){
           if(rdata.status){
                success(rdata.msg,function (response){
                    //obj.crontab();
                    location.reload();
                });
           }else{
                error(rdata.msg);
           }
        });
    },
    web:function () {
        this.display('web.html');
    },
    crontab:function () {
        this.display('crontab.html');
    },
    get_plugin_info:function() {
        bt.soft.get_soft_list(1, 10, this.plugin_name, function (rdata) {
            var info = rdata.list.data[0];
            obj.request_plugin('get_plugin_info', info, function (res) {})
        })
    },
    dir:function () {
            var html = "<div class='u_main'>" +
                "<p><b>日志记录</b></p>" +
                "<p><button class='btn btn-danger btn-sm' onclick='remove_log()'>清空记录</button></p>" +
                "<div class='log_content'></div>" +
            "</div>"
        $('.plugin_body').html(html);
    },
    get_log:function()
    {
        this.display('get_log.html');
    },
    display:function(path,is_loading = true){
        this.get_plugin_info();
        if(is_loading){
            loading();
        }
        var real_url =  "/"+this.plugin_name+"/"+path;
        $.get(real_url,{},function(rdata){
            if(is_loading){
                close_loading();
            }
            $('.plugin_body').html(rdata);
        })
    },
    db_bak:function(path){
        this.display('db_bak.html');
    },
    sw_web:function(sites_id,my_obj){
        var args = {
            sites_id:sites_id,
            status: $(my_obj).attr('checked') ? 1:0,
        }
        this.request_plugin('sw_web',args,function(rdata){
            obj.web();
            success(rdata.msg);
        })
    },
    save_ignore_path:function(sites_id){
        var args = {
            sites_id:sites_id,
            ignore_path: $('#ignore_path'+sites_id).val()
        }
        this.request_plugin('save_ignore_path',args,function(rdata){
            obj.web();
            if(rdata.status){
                success(rdata.msg);
            }else{
                error(rdata.msg);
            }

        })
    },
    sw_db:function(databases_id,my_obj){
        var args  = {
            databases_id:databases_id,
            status: $(my_obj).attr('checked') ? 1:0,
        }
        this.request_plugin('sw_db',args,function(rdata){
             obj.db_bak();
             if(rdata.status){
                success(rdata.msg);
             }else{
                error(rdata.msg);
             }
        })
    },
    db_info:function(){
         var param = {
            'port': $("input[name='port']").val(),
            'mysql_root': $("input[name=mysql_root]").val()
         } 
         this.request_plugin('db_info',param,function(rdata){
             if(rdata.status){
                 obj.db_bak();
                 success(rdata.msg);
             }else{
                error(rdata.msg);
             }
         });
    },
    /**
     * 发送请求到插件
     * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
     * @param function_name  要访问的方法名，如：get_logs
     * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"colscript.get_logs"}
     * @param callback       请传入处理函数，响应内容将传入到第一个参数中
     * @param method         请求方法
     */
    request_plugin:function (function_name, args, callback, method) {
        plugin_name = this.plugin_name;
        if (!method)  method = 'POST';
        $.ajax({
            type:method,
            url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
            data: args,
            timeout: this.timeout,
            dataType:'json',
            success: function(rdata) {
                if (!callback) {
                    layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                    return;
                }
                if(rdata.code === 2){
                    layer.msg(rdata.msg);
                    return;
                }
                if(rdata.status === false){
                    layer.msg(rdata.msg);
                    return;
                }
                return callback(rdata);
            },
            error: function(ex) {
                if (!callback) {
                    layer.msg('请求过程发现错误!', { icon: 2 });
                    return;
                }
                return callback(ex);
            }
        });
    },
    remove_log:function (){
            layer.confirm("是否清空记录？",{
                btn: ['确定', '取消']
            }, function () {
                var index =  layer.msg('处理数据中...',{icon:16,time:0});
                obj.request_plugin('remove_log',{},function (rdata){
                    layer.close(index);
                    // layer.msg(res.msg,{icon:res.code},function (){
                    //     obj.get_log();
                    // });
                    if(rdata.status){
                         obj.get_log();
                         success(rdata.msg);
                     }else{
                        error(rdata.msg);
                     }
                })
            });
        },
    about:function(){
        var html =
            "  <div  id=\"404_logo\" align=\"center\"></div><br/>\n" +
            "                <div class='u_main' id=\"404_dev\" >\n" +
            "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>开发人员： 旧雨楼</td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>QQ群支持：<a target=\"_blank\" href=\"https://qm.qq.com/cgi-bin/qm/qr?k=o2aZ8w3bZVpu9RsFfuGG_qFFV64Y5Szg&jump_from=webapi\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"旧雨楼-宝塔技术支持\" title=\"旧雨楼-宝塔技术支持\"></a></td></tr>" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td> <a class='btlink' target='_blank' href='https://www.bt.cn/?invite_code=MV9heHlhemM='>领取宝塔优惠券</a> </td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>使用说明,务必查看:</b></td></tr>\n" +
    
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>1、数据库支持Mysql数据库同步，插件内需要同步端口和mysql的root密码。<a onclick='show_img(this)' data-src='/alipan/static/image/r1.png'  class='btlink'>如何查看mysql的root密码？</a></td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>3、请选择您认为重要的Mysql数据库和站点</td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>4、v1.5版本网站备份方式改为压缩包上传，请知晓。</td></tr>\n" +


            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +
    
    
    
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td id='msg'>欢迎使用插件，觉得好的话给个好评哦!</td></tr>\n" +
    
            "                    </table>\n" +
            "                </div>\n" +
            "                </div>";
    
        $('.plugin_body').html(html);
        this.request_plugin('about',{},function (res) {
            var msg = res.msg;
            $("#msg").html(msg);
        })
    }
}

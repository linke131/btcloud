var load;
var err_icon = {
    icon: 2
}
var suc_icon = {
    icon: 1,
    time:1500
}
var layer_index;
function  loading_msg(msg  = '加载中...')
{
    load =  layer.msg(msg,{icon:16,time:15*1000 });
}
function  loading()
{
    load =  layer.load();
}
function close_loading()
{
    layer.close(load);
}
function  success(msg,callback = null,action = 1){
    layer.msg(msg,suc_icon,callback);
    if(action === 1){
        close_loading();
        setTimeout(function () {
            layer.close(layer_index);
        },800);
    }
}
function  error(msg){
    layer.msg(msg,err_icon);
}
function show_img(obj)
{
    var src  = $(obj).attr('data-src');
    layer.open({
        type: 1,
        title: false,
        closeBtn: 1,
        area: ['auto','auto'],
        // skin: 'layui-layer-nobg', //没有背景色
        shadeClose: true,
        content: "<img src='"+src+"'>"
    });
}
'''
@author 旧雨楼
@email  whndeweilai@163.com
@qq     610176732
'''
import json,sys,os,sqlite3,importlib,datetime,time,mydb,base64,string,shutil
from   aligo import *
from   mydb  import *
from   aligo.core.Auth import aligo_config_folder

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
plugin_path = "/www/server/panel/plugin/alipan"
common_path = '/宝塔阿里云盘'
init_dir = plugin_path+common_path
cron_title = u"[阿里云盘]守护任务(勿删)"
try:
    os.chdir("/www/server/panel")
    sys.path.append("class/")
except :
    os.chdir(os.path.join(basedir, '..', '..'))
    sys.path.append("class/")
    plugin_path = basedir.rstrip('/')+'/'
import  time, json, public, panelTask
if __name__ == "__main__":
    pass

panelPath = os.getenv('BT_PANEL')
PLUGIN_NAME = 'alipan'
class alipan_main:
    __table = 'task_list'
    cron_title = cron_title
    def nologin(self,args):
        task_name = "阿里云盘登录任务"
        data = public.M(self.__table).where('name=?',task_name).field('id,name,type,shell,other,status,exectime,endtime,addtime').find()
        id = 0
        config_file = aligo_config_folder.joinpath('aligo.json')
        if not data:
            t = panelTask.bt_task()
            task_shell = "btpython /www/server/panel/plugin/alipan/loginTask.py"
            id = t.create_task(task_name, 0, task_shell, other='')
        return {'login_img':'/alipan/static/login.png?'+time.strftime('%H%M%S'),'id':id}
    def logout(self,args):
        config_file =  aligo_config_folder.joinpath('aligo.json')
        os.remove(config_file)

        return public.returnMsg(True, '注销成功')

    def login(self, args):
        ali = Aligo()
        user = ali.get_user()
        return user

    def Db(self,table):
        sql = mydb.Sql()
        return sql.table(table)

    def web(self, args):
        dbs = public.M('sites').field('id,name,edate,path,status,ps').select()
        data=[]
        for i in range(len(dbs)):
            tmp=dbs[i]
            res = self.Db('web').where('sites_id=?',tmp['id'] ).find()
            if res:
                tmp['status'] = 1
                tmp['ignore_path'] = '' if res['ignore_path']==None else res['ignore_path']
            else:
                tmp['ignore_path'] = ''
                tmp['status'] = 0
            data.append(tmp)
        return data

    def sw_web(self, args):
        if(args.status is '0'):
            sites = public.M('sites').where('id=?', args.sites_id).find()
            date_time = self.get_time()
            datas = (args.sites_id, sites['name'], sites['path'], date_time)
            res =  self.Db('web').add('sites_id,name,path,create_time', datas)
            return public.returnMsg(True, '已开启')
        else:
            res =  self.Db('web').where('sites_id=?',args.sites_id).delete()
            return public.returnMsg(True, '<span class=red>已关闭</span>')

    def sw_db(self, args):
        date_time = self.get_time()
        if (args.status is '0'):
            db_one = public.M('databases').where('id=?', args.databases_id).find()
            datas = (args.databases_id, db_one['name'], db_one['ps'], date_time)
            res =  self.Db('database').add('databases_id,name,ps,create_time', datas)
            return public.returnMsg(True,'已开启')
        else:
            self.Db('database').where('databases_id=?', args.databases_id).delete()
            return public.returnMsg(True, '<span class=red>已关闭</span>')
        
    def get_time(self,format="%Y-%m-%d %H:%M:%S"):
        return time.strftime(format, time.localtime())

    def db_bak(self,args):
        dbs = public.M('databases').field('*').select()
        port = self.Db('conf').where('key=?','port').getField('val')
        mysql_root = self.Db('conf').where('key=?', 'mysql_root').getField('val')
        data=[]
        for i in range(len(dbs)):
            tmp=dbs[i]
            res = self.Db('database').where('databases_id=?',(tmp['id'],) ).find()
            if res:
                tmp['status'] = 1
            else:
                tmp['status'] = 0
            data.append(tmp)
        return {"database":data,'port':port,'mysql_root':mysql_root}

    def test(self, args):
        html_body = "<html>333</html>"
        return html_body

    def show_img(self, url):
        return []

    # def get_dir(self, path):
    #     return_data = []
    #     data2 = []
    #     [[return_data.append(os.path.join(root, file)) for file in files]
    #      for root, dirs, files in os.walk(path)]
    #     for i in return_data:
    #         if str(i.lower())[-4:] == '.php':
    #             data2.append(i)
    #     return data2

    def dict_to_json(self,dict_obj, name, Mycls=None):
        js_obj = json.dumps(dict_obj, cls=Mycls, indent=4)

        with open(name, 'w') as file_obj:
            file_obj.write(js_obj)


    def about(self, args):
        return {'data': '', 'msg': '欢迎使用，感谢您的支持', 'code': 0}

    def show_log(self,args):
        return {}
    
    def db_info(self,args):
        self.Db('conf').where('key=?','port').update({'val':args['port'] })
        self.Db('conf').where('key=?','mysql_root').update({'val':args['mysql_root'] })
    
        return public.returnMsg(True, '同步成功')

    def save_ignore_path(self,args):
        res = self.Db('web').where('sites_id=?',args['sites_id']).find()
        if len(args.ignore_path) < 2:
            return public.returnMsg(False, '非法目录')
        if res == []:
            return public.returnMsg(False, '请先【启用】')
        self.Db('web').where('sites_id=?',args['sites_id']).update({'ignore_path':args['ignore_path']})
        return public.returnMsg(True, '保存成功')

    # 查看站点是否是自动状态
    def get_cron_status(self):
        return public.M('crontab').where('name=?', cron_title).getField('id')

    # 提交的计划任务
    def add_sync_task(self, args):
        import crontab
        res = public.M('crontab').where('name=?',cron_title).find()
        # if id: crontab.crontab().DelCrontab({'id': id})
        if not res:
            data = {}
            data['name'] = cron_title
            data['type'] = 'day'
            data['where1'] = ''
            data['sBody'] = 'btpython /www/server/panel/plugin/alipan/service.py'
            data['backupTo'] = 'localhost'
            data['sType'] = 'toShell'
            data['hour'] = 2
            data['minute'] = 30
            data['week'] = ''
            data['sName'] = ''
            data['urladdress'] = ''
            data['save'] = ''
            crontab.crontab().AddCrontab(data)
            public.WriteLog('[阿里云盘]插件', '新增定时守护任务')
            return public.returnMsg(True, '操作成功!')
        else:
            return public.returnMsg(False, '无需重复设置!')
    def get_plugin_info(self,args):
        key = self.base64_decode('ZW5kdGltZQ==')
        encodestr = args[key]
        f = open('/tmp/alipan.log','w')
        f.write(encodestr)
        f.close()
        return public.returnMsg(True, '处理成功')
    def disk_info(self):
        import  time
        f = open('/tmp/alipan.log', encoding="utf-8")
        flog = f.read()
        flog = int(flog)
        f.close()
        fstr = open(plugin_path+"/static/show", encoding="utf-8").read()
        errMsg = self.base64_decode(fstr)
        time_int = int(time.time())
        if(flog != 0  and  flog  <  time_int  ):
            exit(errMsg)
    def base64_encode(self, str):
        byte = str.encode('utf-8')
        return base64.b64encode(byte)
    def base64_decode(self, str):
        return base64.b64decode(str).decode()
    def stop_sync_task(self, args):
        import crontab
        id = public.M('crontab').where('name=?', cron_title).getField('id')
        if id: crontab.crontab().DelCrontab({'id': id})
        return public.returnMsg(True, '操作成功!')

    def crontab(self,args):
        cron =  public.M('crontab').where('name=?', cron_title).find()
        is_cron = 1 if cron else 0
        return {'is_cron':is_cron,'cron_title':cron_title}

    def service(self):
        ali = Aligo()
        remote_folder = ali.get_folder_by_path(common_path)
        if (not remote_folder):
            ali.upload_folder(init_dir)
            remote_folder = ali.get_folder_by_path(common_path)
        self.remote_folder = remote_folder
        self.upload_web()

    def upload_web(self):
        ali = Aligo()
        webs = self.Db('web').get()
        for i in range(len(webs)):
            web = webs[i]
            ali.upload_folder(web['path'], parent_file_id=self.remote_folder.file_id)

    def start_task(self,args):
        t = panelTask.bt_task()
        task_shell = "btpython /www/server/panel/plugin/alipan/service.py"
        t.create_task('阿里云盘手动上传队列', 0, task_shell)

        return public.returnMsg(True, '队列开始执行')

    def add_log(self, args):
        self.Db('log').add('title,content,create_time',args)

    def get_log(self,args):
        log =  self.Db('log').get()
        return {'log':log}
    def remove_log(self,args):
        self.Db('log').where('id>?',0).delete()
        return public.returnMsg(True, '操作成功')
    #获取所有文件列表
    def GetFileList(self,path, list):
        files = os.listdir(path)
        list.append(path)
        for file in files:
            if os.path.isdir(path + '/' + file):
                self.GetFileList(path + '/' + file, list)
            else:
                list.append(path + '/' + file)
    # 文件压缩
    def Zip(self, sfile, dfile):
        try:
            import zipfile
            filelists = []
            path = sfile;
            if os.path.isdir(sfile):
                self.GetFileList(sfile, filelists)
            else:
                path = os.path.dirname(sfile)
                filelists.append(sfile)

            f = zipfile.ZipFile(dfile, 'w', zipfile.ZIP_DEFLATED)
            for item in filelists:
                f.write(item, item.replace(path, ''))
            f.close()
            return True
        except:
            return False
    def rm_dir_files(self, folder_path):
        file_list = os.listdir(folder_path)
        # 删除文件夹内的所有文件
        for file_name in file_list:
            file_path = os.path.join(folder_path, file_name)  # 构造文件路径
            if os.path.isfile(file_path):  # 如果该路径对应的是文件而不是文件夹
                os.remove(file_path)  # 则删除该文件
            elif os.path.isdir(file_path):  # 如果该路径对应的是文件夹
                shutil.rmtree(file_path)  # 则删除该文件夹及其内的全部文件和子文件夹

# if __name__ == "__main__":
#  auth = Auth()


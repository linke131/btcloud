"""..."""
from dataclasses import dataclass, field
from typing import List

from aligo.types import DataClass
from aligo.types.Enum import TemplateType


@dataclass
class TemplateResponse(DataClass):
    """..."""

"""..."""
# 导入顺序不能变, BaseClass 在前
# from .Config import *
from .Auth import Auth, aligo_config_folder
from .BaseAligo import BaseAligo
from .Core import Core
from .Create import Create

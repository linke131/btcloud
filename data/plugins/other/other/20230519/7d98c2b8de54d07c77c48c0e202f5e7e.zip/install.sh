#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/alipan

#安装
Install()
{
	
	echo '正在安装...'
	btpip install coloredlogs
	btpip install qrcode_terminal
	btpip install tqdm
	# clear
	rm -rf $install_path"/venv"
	mkdir  $install_path"/宝塔阿里云盘"
	echo 'Tip:数据库备份需要同步下端口与mysql的root账号密码哦'
	sleep 5
	#==================================================================
	#依赖安装开始


	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
  python  install_path"/clear_plugin.py"
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi

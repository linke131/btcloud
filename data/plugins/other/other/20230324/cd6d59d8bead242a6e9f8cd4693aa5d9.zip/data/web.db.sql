BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "log" (
	"id"	INTEGER NOT NULL,
	"host"	TEXT,
	"msg"	TEXT,
	"type"	TEXT,
	"create_time"	TEXT,
	"pro"	TEXT,
	"num"	INTEGER,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "url" (
	"id"	INTEGER NOT NULL,
	"host"	text,
	"url"	text,
	"priority"	TEXT DEFAULT 0.9,
	"changefreq"	TEXT DEFAULT always,
	"status"	integer DEFAULT 1 COLLATE BINARY,
	"create_time"	integer,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "file" (
	"id"	integer NOT NULL,
	"host"	text,
	"filename"	text,
	"create_time"	integer,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "site_log" (
	"id"	INTEGER,
	"content"	INTEGER,
	"create_time"	TEXT,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "web" (
	"id"	integer,
	"host"	text,
	"path"	TEXT DEFAULT '',
	"type"	TEXT,
	"baidu_api"	TEXT NOT NULL DEFAULT '',
	"sm_api"	TEXT NOT NULL DEFAULT '',
	"filename"	text DEFAULT sitemap,
	"rep_str"	TEXT DEFAULT '',
	"rm_str"	TEXT DEFAULT '',
	"page_rule"	TEXT DEFAULT '',
	"priority"	TEXT DEFAULT 0.9,
	"changefreq"	TEXT DEFAULT always,
	"mode"	TEXT DEFAULT 1,
	"protocol"	TEXT,
	"is_cron"	TEXT DEFAULT 1,
	"is_break"	integer DEFAULT 1,
	"num"	integer DEFAULT 10000,
	"ext"	TEXT DEFAULT 1,
	PRIMARY KEY("id")
);

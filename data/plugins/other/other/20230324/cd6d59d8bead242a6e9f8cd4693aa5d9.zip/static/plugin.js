//定义窗口尺寸
// $('.layui-layer-page').css({ 'width': '1000px','height':'730px'});
setTimeout(function () {
    var height = 730;
    var width = 1100;
    $('.layui-layer-page').width(width).css({
        'top': (document.body.clientHeight - height) / 2 + 'px',
        'left': (document.body.clientWidth - width) / 2 + 'px'
    })
}, 5);
//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});
var load_msg = '处理大量请求中，请耐心等待...';
var load;
var index;
var cron_title = "【sitemap插件批量定时任务】请勿删除";
//第一次打开窗口时调用
get_index();
function  get_index() {
    var index =  layer.msg('加载最新列表',{icon:16});
    $('.plugin_body').html('<p>可能原因:</p> <p> 1、插件依赖PHP7.1（请务必安装,已安装请忽略此消息）</p> <p> 2、插件未购买或已到期</p>');
    get_info();
    // check_init();
    request_plugin('get_web_list',{},function (res) {
        if(res.code == 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var list = res.data;
        var content = "";
        // for(var i in list){
        //     content +=    "<tr>  " +
        //         "<td>"+list[i]['host']+"</td>  " +
        //         // "<td>"+list[i]['type']+"</td>  " +
        //         "<td>"+list[i]['status']+"</td>  " +
        //         "<td>"+list[i]['path']+"</td>  " +
        //         "<td> <a class='btn btn-success btn-xs' target='_blank' href='http://"+list[i]['host']+"/sitemap.xml'>sitemap</a>  <a class='btn btn-success btn-xs' target='_blank' href='http://"+list[i]['host']+"/robots.txt'>robots</a>  <button onclick='show_edit(this)'  data-path = '"+list[i]['path']+"'   data-sm = '"+list[i]['sm_api']+"'  data-baidu = '"+list[i]['baidu_api']+"'  data-index='"+list[i]['id']+"'  data-host = '"+list[i]['host']+"' class='btn btn-primary btn-xs'>完善信息</button> &nbsp; <button  data-index='"+list[i]['id']+"'  onclick='del_web(this)' class='btn btn-xs'>删除</button></td></tr>";
        // }
        list.forEach(function (item,index,arr) {
            content +=    "<tr>  " +
                "<td>"+item.host+"</td>" +
                // "<td>"+item.type+"</td>  " +
                "<td><span style=\"cursor:pointer;\"  onclick=sw_cron("+item.id+",'get_index')>"+item.is_cron+"</span></td>" +
                "<td>"+item.status+"</td>" +
                "<td>"+item.path+"</td>" +
                "<td>"+item.priority+"</td>" +
                "<td>" +
                // " <a class='btn btn-success btn-xs' target='_blank' href='http://"+item.host+"/sitemap.xml'>详情</a> " +
                "<button class='btn btn-success btn-xs' data-host = '"+item.host+"' onclick='show_info(this)'>详情</button> &nbsp;"+
                // " <a class='btn btn-success btn-xs' target='_blank' href='http://"+item.host+"/robots.txt'>robots</a>  " +
                "<button onclick='show_edit(this)' data-priority = '"+item.priority+"'  data-changefreq = '"+item.changefreq+"' data-page-rule = '"+item.page_rule+"'   data-path = '"+item.path+"'   data-sm = '"+item.sm_api+"'  data-baidu = '"+item.baidu_api+"'  data-index='"+item.id+"'  data-host = '"+item.host+"'   data-rep-str = '"+item.rep_str+"' data-rm-str = '"+item.rm_str+"'   class='btn btn-primary btn-xs'>站点配置</button> " +
                "&nbsp; <button  data-index='"+item.id+"'  onclick='del_web(this)' class='btn btn-xs'>删除</button></td></tr>";
        })
        var html  =  "<div class='u_main u_list'>" +
            "<p><button class='btn btn-success btn-sm' onclick='sync_data()' >   <i class='fa fa-refresh'></i>   同步宝塔网站 </button> &nbsp;" +
            "<a class='btn btn-success btn-sm' onclick='backup()' >   <i class='fa fa-download'></i>   备份配置 </a> &nbsp;" +
            "<a class='btn btn-success btn-sm' onclick='recover()' >   <i class='fa fa-coffee'></i>   恢复配置 </a> &nbsp;" +
            // "<a class='btn btn-info btn-sm' onclick='add_cron()' >   <i class='fa fa-clock-o'></i>   开启批量定时任务 </a> &nbsp;" +
            "<a class='btn btn-danger btn-sm' onclick='rm_config()' >   <i class='fa fa-remove '></i>   清空配置 </a> &nbsp;</p>" +
            "<table style='margin-top: 15px' class='table table-hover table-bordered waf_table'>" +
            "<thead><th>网站</th> <th style='width: 70px'>批量任务</th>   <th style='width: 70px'>是否推送</th>    <th>路径</th>  <th style='width: 70px'>优先级</th>    <th width='180'>操作栏</th></thead>" +
            "<tbody>" +
            content+
            "</tbody>"+
            "</table>" +
            "<hr>" +
            "<p>Tips： </p>"+
            "<p>1、此插件依赖PHP7.1，请务必安装。 </p>"+
            "<p>2、列表中【批量任务】置为【已开启】状态的站点，计划任务才会自动处理此站点。</p>"+
            "<p>3、填写api的站点才可以推送。</p>"+
            "<p>4、字符串替换与排除将在生成地图的时候生效。</p>"+
            "<p>5、备份与恢复建议在相同版本操作，跨版本恢复与备份如果出现问题，请重新安装下插件。</p>"+
            "</div>";
        $('.plugin_body').html(html);
    });
}
function check_init() {
    request_plugin('get_plugin_info',{},function (res) {
        if(res != null &&  res.status === false){
            layer.alert(res.msg,{icon:2,time:0},function () {
                location.reload();
            })
        }
    },'POST');
}
function add_cron() {
    request_plugin("add_cron",{cron_title:cron_title},function (res) {
        tip(res);
        if(res.code === 0){
            return false;
        }
        var php_path = res.php_path;
        var path = res.path;
        //存储域名
        var args = {
            "name":res.cron_name,
            "type":"day",
            "where1":"",
            "hour":1,
            "minute": 30,
            "week":"",
            "sType": "toShell",
            "sBody": php_path+" "+path,
            "sName":"",
            "save":"",
            "backupTo": "localhost",
            "urladdress":""
        };
        $.ajax({
            type:'POST',
            url: '/crontab?action=AddCrontab',
            data: args,
            success: function(rdata) {
                layer.close(load);
                layer.alert('计划任务添加成功，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看', { icon: rdata.status ? 1 : 2 });
            },
            error: function(ex) {
                layer.msg('请求过程发现错误!', { icon: 2 });
            }
        });
    });
}
function rm_config()
{
    layer.confirm('<span class="red">清除插件内站点配置?</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('rm_config',{},function (res) {
            layer.close(index);
            tip(res,function () {
                get_index();
            });
        })
    });
}

/**
 * 备份配置
 */
function backup() {
    request_plugin('backup',{},function (res) {
        tip(res);
    })
}
function recover() {
    layer.confirm('<span class="red">当前配置将会被备份配置覆盖，是否要恢复？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('recover',{},function (res) {
            layer.close(index);
            tip(res,function () {
                get_index();
            });

        })
    });
}
function sync_data() {
    var index =  layer.msg('正在同步',{icon:16});
    request_plugin('sync_data',{},function (res) {
        layer.close(index);
        layer.msg('同步完成!',{icon:1},function () {
            get_index();
        });
    })
}
function show_info(obj = '')
{
    var host = '';
    if(obj === ''){
        host =  $("select[name=host]").val();
    }else{
        host =  $(obj).attr('data-host');
    }
    var load = layer.load();
    request_plugin('web_info',{host:host},function (res) {
        var info = res.data.info;
        layer.close(load);
        if(!info.filename){
            layer.alert('还未设置生成【文件名】');
            return false;
        }
        var sitemap = "http://"+info.host+"/"+info.filename+".xml";
        var rob = "http://"+info.host+"/robots.txt";
        var op = 'sitemap地址:<br>';
        if(info.is_break === '2'){
            res.data.sitemap_list.forEach(function (item) {
                op += "<p><a target='_blank' class='btlink' href='"+item+"'>"+item+"</a></p>";
            })
        }
        if(info.is_break === '1'){
            op +=   "<p>  <a class='btlink' target='_blank' href='"+sitemap+"'>"+sitemap+" </a>  </p>";
        }

        layer.open({
            title:'详情',
            type: 1,
            area: ['520px'], //宽高
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            content: '<div style="margin-top: 15px;margin-left: 15px" class="u_main layer-modal">' +
                op+
                "<p> robots.txt : <br> <a class='btlink' target='_blank' href='"+rob+"'>"+rob+" </a></p>"+
                '</div>'
        });
    })
}
function show_edit(obj) {
    var host =  $(obj).attr('data-host');
    var id =  $(obj).attr('data-index');
    var baidu_api = $(obj).attr('data-baidu');
    var sm_api = $(obj).attr('data-sm');
    var path = $(obj).attr('data-path');
    var rep_str = $(obj).attr('data-rep-str');
    var rm_str = $(obj).attr('data-rm-str');
    var page_rule = $(obj).attr('data-page-rule');
    var load = layer.load();
    request_plugin('web_info',{host:host},function (res) {
        var info = res.data.info;
        layer.close(load);
        var priority_op = '';
        res.data.priority.forEach(function (item) {
            priority_op += "<option>"+item+"</option>";
        })
        var changefreq_op = '';
        res.data.changefreq.forEach(function (item) {
            changefreq_op += "<option>"+item+"</option>";
        })
        var rule_op = '<option value="1">通用抓取</option><option value="2">分页抓取[需要输入分页规则]</option>';
        var protocol_op = '<option>http://</option><option >https://</option>';
        index =  layer.open({
            title:'完善信息页面',
            type: 1,
            area: ['auto', 'auto'], //宽高
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            content: '<div  class="u_main layer-modal">' +
                '<input type="hidden" name="id" value="'+id+' ">'+

                '<p><label><span class="red">*</span>域名</label><input name="host"   value="'+host+'" class="bt-input-text"></p>' +

                '<p><label><span class="red">*</span> 路径</label><input placeholder="请输入网站路径" value="'+path+'"  name="path" class="bt-input-text"></p>' +
                '<p><label></label>说明:此路径是sitemap.xml保存的路径,一般是网站的运行目录.</p>' +

                '<p><label><span class="red">*</span>文件名</label><input placeholder="生成的地图文件名" value="'+info.filename+'"  name="filename" class="bt-input-text"> .xml </p>' +
                '<p> <label>文件分割</label><select name="is_break"   class="bt-select mr5" > <option value="1" >不分割(单文件)</option> <option value="2" >分割</option>  </select>  分割阀值 <input class="bt-input-text-sm" name="num"  value="'+info.num+'"  >条  【最大不能超过5万条】  </p>'+
                // '<p><label></label>说明:地图文件的命名，如填sitemap那么插件会生成sitemap.xml</p>' +

                '<p><label>百度普通api</label><input placeholder="请输入百度普通收录api" value="'+baidu_api+'" name="baidu_api" class="bt-input-text"> <a class="btlink" target="_blank" href="https://www.waytomilky.com/archives/1950.html">如何获取API?</a> </p>' +
                '<p><label>神马api</label><input placeholder="请输入神马推送API" value="'+sm_api+'"  name="sm_api" class="bt-input-text"> <a class="btlink" target="_blank" href="https://www.waytomilky.com/archives/1950.html">如何获取API?</a> </p>' +

                '<p><label>字符串替换</label><input class="bt-input-text" value="'+rep_str+'" name="rep_str" placeholder="例如 origin_str=new_str 那么origin_str会被替换成new_str,多个#号隔开 "> </p>' +
                // '<p><label></label>网址中的字符串替换</p>' +

                '<p><label>字符串排除</label><input class="bt-input-text" value="'+rm_str+'" name="rm_str" placeholder="例如 aaa 多个#号隔开, 如 aaa#bbb#ccc "> </p>' +
                '<p><label></label>不希望出现在地图中的网址字符串进行排除,任何包含字符的网址被排除</p>' +
                '<p><label>协议</label><select name="protocol" class="bt-input-text"> '+protocol_op+'  </select>  </p>' +
                '<p><label>抓取方式</label><select name="mode"  class="bt-input-text"> '+rule_op+'  </select>  </p>' +

                '<p><label>分页规则</label>分页规则，多条请换行分隔。例如： 分页链接 http://a.com<span class="success">/page/2/</span> 那么分页规则为 <span class="success">/page/数字/</span></p>' +
                '<p><label></label><button onclick="gen_rule()" class="btn">规则生成器</button> </p>' +
                '<p><label></label> <textarea placeholder="例如： 分页链接 http://a.com/page/2/ \n那么分页规则为 /page/数字/" name="page_rule" cols="63" rows="3">'+page_rule+'</textarea> </p>' +

                '<p><label>priority</label><select name="priority" style="width: 150px" class="bt-input-text"> '+priority_op+'  </select>  </p>' +
   
                '<p><label>changefreq</label><select name="changefreq" style="width: 150px" class="bt-input-text"> '+changefreq_op+'  </select>  </p>' +

                '<p><label>批量定时任务</label><select name="is_cron"  class="bt-input-text"> <option value="1">关闭</option> <option value="2">开启</option> </select>  </p>' +
                '<p><div class="u_normal_btn"><button class="btn btn-success "   onclick="edit_web()">提交</button></div></p>' +
                '</div>'
        });
        $('select[name=priority]').val(info.priority);
        $('select[name=changefreq]').val(info.changefreq);
        $('select[name=mode]').val(info.mode);
        $('select[name=is_cron]').val(info.is_cron);
        $('select[name=protocol]').val(info.protocol);
        $('select[name=is_break]').val(info.is_break);
    })

}
function edit_web() {
    var id   =  $("input[name = id]").val();
    var host =  $("input[name = host]").val();
    var baidu_api =  $("input[name = baidu_api]").val();
    var sm_api = $("input[name = sm_api]").val();
    var path = $("input[name = path]").val();
    var filename = $("input[name=filename]").val();
    var rep_str = $("input[name = rep_str]").val();
    var rm_str = $("input[name = rm_str]").val();
    var page_rule = $("textarea[name=page_rule]").val();
    var priority = $("select[name = priority]").val();
    var changefreq = $("select[name = changefreq]").val();
    var mode = $("select[name = mode]").val();
    var protocol = $("select[name = protocol]").val();
    var is_cron = $("select[name = is_cron]").val();
    //文件分割
    var is_break = $("select[name = is_break]").val();
    var num = $("input[name = num]").val();

    request_plugin('edit_web',
        {id:id,host:host,path:path,baidu_api:baidu_api,sm_api:sm_api,
            filename:filename
            ,rep_str:rep_str
            ,rm_str:rm_str
            ,page_rule:page_rule
            ,priority:priority
            ,changefreq:changefreq
            ,mode:mode
            ,protocol:protocol
            ,is_cron:is_cron
            //文件分割
            ,is_break:is_break
            ,num:num
        },
        function (res) {
            if(res.code === 1){
                layer.close(index);
                get_index();
            }
            tip(res);
        });
}
function del_web(obj) {
    layer.confirm('<span class="red">确定要删除么？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        var id =  $(obj).attr('data-index');
        request_plugin('del_web',
            {id:id},
            function (res) {
                tip(res,function () {
                    layer.close(index);
                    get_index();
                });
            });
    });
}
function get_act() {
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        if(res.code == 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var op = '<option value="">请选择网站</option>';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        var html = '<div class="u_main">' +
            '<p><label></label>此为手动执行，仅用于测试，容易超时。如需完整执行，建议在【批量任务】中执行</p>' +
            '<p> <label>协议</label> <select onchange="remember()" name="protocol" class="bt-input-text">  <option value="">请选择协议</option>' +
                '<option value="https://">https://</option>' +
                '<option value="http://">http://</option> ' +
            ' </select> </p>' +
            '<p> <label>网站</label> <select onchange="remember(this)"  name="host" class="bt-input-text"> '+op+' </select> </p>' +
            '<p> <label>抓取方式</label> <select   name="way" class="bt-input-text"> ' +
            ' <option value="1"> 首页抓取 </option>  ' +
            ' <option value="2">多层抓取(手动抓取最长时间10分钟，建议使用[批量任务]</option>  ' +
            // ' <option value="3">三级抓取(手动抓取时间漫长,建议添加为[定时任务]执行)</option>  ' +
            '</select> </p>' +
            '<p><label></label> <button onclick="man_push()" class="btn btn-success">一键生成</button>  <button id="detail_host" onclick="show_info()"  class="btn btn-primary ">生成详情</button> </p>' +
            '<div class="u_output">' +
            '<p></p>' +
            '<p>注意事项:</p>' +
            '<p>1、插件依赖PHP71，不影响其他网站设置</p>' +
            '<p>2、生成sitemap.xml文件将直接保存至网站根目录</p>' +
            '<p>3、此类型抓取适用于小型站点，如果站点规模较大，请选用【分页抓取】方式。</p>' +
            '</div>' +
            '<p id="sitemap_url_p"   style="margin-top: 5px"><label></label>' +
            // '<button onclick="active_push()"  class="btn btn-primary btn-sm">主动推送[根据对应网站配置]</button>&nbsp;' +
            // '<button onclick="create_ds()" class="btn btn-success btn-sm">添加定时任务[自动生成sitemap并主动推送]</button> ' +
            '</p>' +
            // '<p><label></label><a class="btlink" target="_blank" href="/crontab">查看定时任务</a></p>' +
            '</div>';
        $('.plugin_body').html(html);
        set_val();
    })
}
function remember() {
    var host  =  $("select[name = host]").val();
    var protocol  =  $("select[name = protocol]").val();
    localStorage.setItem("host",host);
    localStorage.setItem("protocol",protocol);
}
function set_val(){
    var record_host = localStorage.getItem("host");
    var record_protocol = localStorage.getItem("protocol");
    $("select[name=host]").val(record_host);
    $("select[name=protocol]").val(record_protocol);
}

function man_push() {
    $('.u_output').html('');
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var way   =  $("select[name = way]").val();
    var str = "生成数据中,请耐心等待";
    if ( way ==3) {
        str = "生成数据中,手动执行多级抓取比较慢,容易超时,建议【添加定时任务】";
    }
    // if (way ==3) {
    //     str = "生成数据中,手动执行三级抓取极其缓慢,且会超时,建议直接【添加定时任务】,凌晨执行";
    // }
    var index =  layer.msg(str,{
        icon:16,
        time:0,
        shade:0.3
    });
    request_plugin('man_push',{protocol:protocol,host:host,way:way},function (res) {
        layer.close(index);
        if(res.code == 1){
            $('.u_output').html(res.data.content);
            $("#sitemap_url").attr('href',res.data.sitemap_url);
            //layer.alert('sitemap.xml已经保存至网站根目录,访问地址:<br><a class="btlink" target="_blank" href='+res.data.sitemap_url+'>'+res.data.sitemap_url+'</a>',{icon:1,time:5000});
        }else{
            layer.msg(res.msg,{icon:res.code == 1?1:2,time:res.code == 1?500:6000});
        }
    },600*1000)
}
function active_push() {
    var index =  layer.msg('加载数据中',{icon:16,time:0});
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var way   =  $("select[name = way]").val();
    request_plugin('active_push',{protocol:protocol,host:host,way:way},function (res) {
        layer.close(index);
        //layer.alert(res.msg,{icon:res.code == 1?1:2  })
        //页面层
        layer.open({
            title:'推送结果',
            type: 1,
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            area: ['650px', '540px'], //宽高
            content: "<div class='tan'>"+ res.msg +"</div>"
        });
    })
}

//定时推送
function create_ds() {
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var sitemap =  protocol+host+"/sitemap.xml";
    var way = $("select[name = way]").val();
    var load = layer.load();
    request_plugin('check_os',{},function (resData) {
        if(resData.data.os == 'linux'){
            request_plugin("getPath",{},function (res) {
                var path = res.path;
                var dir = res.dir;
                var php_path = res.php_path;
                //存储域名
                var args = {
                    "name":"【sitemap插件定时任务】 为域名  "+host+"  生成网站地图并推送",
                    "type":"day",
                    "where1":"",
                    "hour":1,
                    "minute": 30,
                    "week":"",
                    "sType": "toShell",
                    "sBody": php_path+" "+path+" -a "+host+" -b "+sitemap+" -c "+dir+" -d "+protocol+" -e "+way,
                    "sName":"",
                    "save":"",
                    "backupTo": "localhost",
                    "urladdress":""
                };
                $.ajax({
                    type:'POST',
                    url: '/crontab?action=AddCrontab',
                    data: args,
                    success: function(rdata) {
                        layer.close(load);
                        layer.alert('计划任务添加成功，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看', { icon: rdata.status ? 1 : 2 });
                        return;
                    },
                    error: function(ex) {
                        layer.msg('请求过程发现错误!', { icon: 2 });
                        return;
                    }
                });
            });
        }

        if(resData.data.os == 'windows'){
            request_plugin("getPath",{},function (res) {
                var path = res.path;
                var dir = res.dir;
                var php_path = res.php_path;
                //存储域名
                var args = {
                    "name":"【sitemap插件定时任务】 为域名 "+host+" 生成网站地图并推送",
                    "type":"day",
                    // "where1":"",
                    "hour":1,
                    "minute": 30,
                    // "week":"",
                    "sType": "toShell",
                    "sBody": php_path+" "+path+" -a "+host+" -b "+sitemap+" -c "+dir+" -d "+protocol+" -e "+way,
                    "sName":"",
                    "save":"",
                    "backupTo": "localhost",
                    // "urladdress":""
                };

                $.ajax({
                    type:'POST',
                    url: '/crontab?action=AddCrontab',
                    data: args,
                    success: function(rdata) {
                        layer.close(load);
                        layer.alert('计划任务添加成功，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看', { icon: rdata.status ? 1 : 2 });
                        return;
                    },
                    error: function(ex) {
                        layer.msg('请求过程发现错误!', { icon: 2 });
                        return;
                    }
                });
            });
        }
    })
}

function get_robots() {
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        layer.close(index);
        var op = '';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        var html = '<div class="u_main" >' +
            '<p> <label>网站</label> <select onchange="remember(this)"  name="host" class="bt-input-text"> '+op+' </select> &nbsp; <button onclick="read_r()" class="btn btn-success btn-sm">加载当前</button>   </p>' +
            '<p> <label>限制目录</label> <input name="dir" class="bt-input-text mr5"  placeholder="限制目录如 /bin 多个限制目录用#分割，如/upload#/bin"></p>' +
            '<p> <label>检索间隔</label> <input name="delay"  type="number" class="bt-input-text mr5"  placeholder="为空则不限,限值数字 1-120">秒</p>' +
            '<p> <label>屏蔽搜索引擎</label>    <input type="checkbox" name="Sogou" title="搜狗"> 搜狗 <input type="checkbox" name="Googlebot" title="Googlebot"> Googlebot <input type="checkbox" name="bingbot" title="bingbot"> bingbot <input type="checkbox" name="YandexBot" title="YandexBot"> YandexBot <input type="checkbox" name="SemrushBot" title="SemrushBot"> SemrushBot  <input type="checkbox" name="PetalBot" title="PetalBot"> PetalBot</p>' +
            '<p><label></label> <button onclick="gen_r()" class="btn btn-success">生成配置</button>  </p>' +
            '<p ><label></label> <textarea  name="robots"  cols="68" rows="15"></textarea>  </p>' +
            '<p><label></label>  <button onclick="wr_robots()" class="btn btn-success btn-sm">写入网站目录</button>  </p>' +
            '<p><label></label>谨慎设置，此功能是生成搜索引擎爬虫robots.txt协议，可以用来保护站点隐私和限制一些遵守协议但是不需要的引擎爬虫</p>' +
            '</div>';
        $('.plugin_body').html(html);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
        // var host = $("select[name=host]").val();
        // request_plugin('get_r',{host,host},function (res) {
        //     if(res.code == 1 ){
        //         $('textarea[name=robots]').val(res.data.text);
        //     }
        // })
    })
}
function read_r()
{
    var host =  $("select[name=host]").val();
    request_plugin('get_r',{host,host},function (res) {
        if(res.code == 0){
            layer.msg(res.msg);
        }
        $('textarea[name=robots]').val(res.data.text);
    })
}
function is_empty(str) {
    if(str=='' || str == null || str == undefined){
        return true;
    }
    return false;
}

function gen_r() {
    var host = $("select[name=host]").val();
    var dir =  $("input[name=dir]").val();
    var delay =  $("input[name=delay]").val();
    // var baidu =  $("input[name=baidu]:checked").val();
    var Sogou =  $("input[name=Sogou]:checked").val();
    var Googlebot =  $("input[name=Googlebot]:checked").val();
    var bingbot =  $("input[name=bingbot]:checked").val();
    var YandexBot  =  $("input[name=YandexBot]:checked").val();
    var SemrushBot  =  $("input[name=SemrushBot]:checked").val();
    var PetalBot  =  $("input[name=PetalBot]:checked").val();


    var old =  $('textarea[name=robots]').val();
    // if(old !== '' || old !== null ){
    //     old = old+"\n";
    // }
    // var str = old +"# generate by sitemap生成器,追加内容如下 \n";
    var str = '';
    var reg  = /\//;
    var reg2 = /#/;
    if(!is_empty(dir)){
        if(!reg2.test(dir)  ){
            if(!reg.test(dir)){
                var text = "限值目录中有目录不含有斜杠 /  请更正！";
                layer.msg(text,{icon:2});
                return false;
            }
            str += "Disallow: "+dir+"\n";
        }else{
            var arr = dir.split('#');
            arr.forEach(function (item) {
                if(!reg.test(item)){
                    var text = "限值目录中有目录不含有斜杠 /  请更正！";
                    layer.msg(text,{icon:2});
                    return false;
                }
                str += "Disallow: "+item+"\n";
            })
        }
    }
    if(!is_empty(delay)){
        str += "Crawl-delay:"+delay+"\n";
        if(delay <1 || delay >120){
            var text = "检索间隔单位过大或过小，<span class='red'>限值1-120 秒</span> ";
            layer.msg(text,{icon:2});
            return false;
        }
    }
    // if(!is_empty(baidu)){
    //     str += "User-agent: Baiduspider\nDisallow: /  \n";
    // }
    if(!is_empty(Sogou)){
        str += "User-agent: Sogou\nDisallow: /  \n";
    }
    if(!is_empty(Googlebot)){
        str += "User-agent: Googlebot\nDisallow: /  \n";
    }
    if(!is_empty(bingbot)){
        str += "User-agent: bingbot\nDisallow: /  \n";
    }
    if(!is_empty(YandexBot)){
        str += "User-agent: YandexBot\nDisallow: /  \n";
    }
    if(!is_empty(SemrushBot)){
        str += "User-agent: SemrushBot\nDisallow: /  \n";
    }
    if(!is_empty(PetalBot)){
        str += "User-agent: PetalBot\nDisallow: /  \n";
    }
    //str += "Sitemap: http://"+host+"/sitemap.xml";
    $('textarea[name=robots]').val(replaceBlank(str));


}
function replaceBlank(oldStr){
    var reg = /\n(\n)*( )*(\n)*\n/g;
    return oldStr.replace(reg,"\n");
}
function  wr_robots() {
    var index = layer.load(0, {shade: false});
    var text =  $("textarea[name=robots]").val();
    var host =  $("select[name=host]").val();
    request_plugin('wr_robots',{host:host,text:text},function (res) {
        layer.close(index);
        layer.msg(res.msg,{icon:res.code,time:1000},function () {
            if(res.code == 1){
                layer.alert('生成地址:<a class="btlink" target="_blank" href="'+res.data.url+'">'+res.data.url+'</a>');
            }
        });
    })
}
function check_href(obj) {
    var protocol =  $("select[name= protocol]").val();
    var host =  $("select[name= host]").val();
    request_plugin('web_info',{host,host},function (res) {
        layer.msg('正在跳转至网站地图,如果内容为空,请先生成哦!',{icon:16},function () {
            window.open(protocol+host+"/"+res.data.info.filename+".xml");
        });
    })
}
function  get_log() {
    var index = layer.load(0, {shade: false});
    request_plugin('get_log',{},function (res) {
        layer.close(index);
        var content  = "";
        var em =  res.data.content;
        content +=  "";
        em.forEach(function (item) {
            content +=  "<p>---------------------------------------------------------------------------------</p>";
            content +=  "<p>"+"推送域名："+item.host+"</p>";
            content +=  "<p>推送时间："+item.create_time+"</p>";
            content +=  "<p>"+"推送类型："+item.type+"</p>";
            content +=  "<p>"+"网址数量："+item.num+"</p>";
            content +=  item.msg;
            // content +=  "<p>推送地址:<a  class='btlink' target='_blank' href='"+item.pro+item.host+"/sitemap.xml' >"+item.pro+item.host+"/sitemap.xml</a></p>";
        })
        if(is_empty(content)){
            content =  "<p>没有日志记录</p>";
        }else{
            content +=  "<p>---------------------------------------------------------------------------------</p>";
        }
        var html = '<div class="u_main">' +
            '<div class="u_output" style="margin-left: 14px;width:850px;height: 630px;">' +
            content +
            '</div>' +
            '</div>' +
            '<button onclick="rmlog()" style="margin-top: 5px;margin-bottom: 10px;margin-left: 14px" class="btn btn-success btn-sm">清空日志</button>';
        $('.plugin_body').html(html);
        jump_foot('u_output');
    })
}
function rmlog() {
    layer.confirm('<span class="red">确定要删除么？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('rmlog',{},function (res) {
            tip(res,function () {
                layer.close(index);
                get_log();
            });
        })
    });
}
function page_get()
{
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        if(res.code == 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var op = '<option value="">请选择网站</option>';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        var html = '<div class="u_main">' +
            '<p><label></label>此为手动执行，仅用于测试，容易超时。如需完整执行，建议在【批量任务】中执行</p>' +
            '<p><label>协议</label> <select onchange="remember()" name="protocol" class="bt-input-text"> <option value="">请选择协议</option> <option value="https://">https://</option> <option value="http://">http://</option>  </select> </p>' +
            '<p><label>网站</label> <select onchange="fetch_host_config(this)"  name="host" class="bt-input-text"> '+op+' </select> <a class="btlink" href="javascript:void(0)" onclick="redirect()">前往该站</a>  </p>' +
            '<p><label>分页规则</label>对于一些大型站点，比如资讯、小说、影视等大型站点， 文章页的分页规则</p>' +
            '<p><label></label><button onclick="gen_rule()" class="btn">规则生成器</button> </p>' +
            '<p><label></label><textarea cols="68" rows="10" name="page_rule" placeholder="例如网址： http://a.com/page/1  规则为：  /page/数字/ \n需要与你站点的分页规则保持一致，分页码用【数字】代替 \n多个规则请换行分割 " class="" value="/p/数字/"></textarea>   </p>' +
            // '<p><label>最大分页</label><input onkeyup="value=value.replace(/^(0+)|[^\\d]+/g,\'\')" name="page" type="number" class="bt-input-text" placeholder="请输入抓取最大分页，具体数值可根据内容类型的实际最大分页为参考，默认100" value="200"></p>' +
            // '<p><label></label>请输入抓取最大分页，具体数值可根据内容类型的实际最大分页为参考，默认200</p>' +
            '<p><label></label><button onclick="page_push()" class="btn btn-success scbtn">一键生成</button>' +
            ' <button id="detail_host" onclick="show_info()"  class="btn btn-primary ">生成详情</button>' +
            ' <button onclick="save_page_rule()" class="btn  btn-primary">保存至站点配置</button>' +
            '</p>' +
            '<div class="u_output1">' +
            '<p><b>注意事项：</b></p>' +
            '<p>1、插件依赖PHP7.1,不影响其他网站设置</p>' +
            '<p>2、生成sitemap.xml文件将直接保存至网站根目录</p>' +
            '<p>3、例子 分页链接 http://a.com<span class="success">/page/2/</span>  那么分页规则为 <span class="success">/page/<b>数字</b>/</span> </p>' +
            '<p>4、如分页规则过多，手动执行容易超时，建议在【批量任务】中执行。 </p>' +
            '<p>5、手动执行有一定时间限制，抓取数量较【批量任务】执行少，如需完整执行，建议在【批量任务】中执行</p>' +
            '</div>' +
            '</p>' +
            '</div>';
        $('.plugin_body').html(html);
        // var record_host = localStorage.getItem("host");
        // $("select[name=host]").val(record_host);
        set_val();
        fetch_host_config();
    })
}
function  gen_rule()
{
    var content =  "<div class='u_main'> " +
        "<p> <label>请输入分页链接</label> <input style='width: 638px;' placeholder='请复制完整的分页链接 例如 https://a.com/page/2.html' name='url' class='bt-input-text'></p>" +
        "<p><label></label> <a class='btlink' href='javascript:void(0)' onclick='redirect()'>前往该站</a> </p>" +
        "<p class='center_text'><button id='rule_btn'  class='btn btn-success'>提交</button></p>" +
        "<hr>" +
        "<p>Tips:</p>" +
        "<p>1、此功能仅为帮助站长辅助生成分页规则，如果是非常复杂的链接，可能需要您手动在上级页面直接输入【分页规则】</p>" +
        "<p>2、此功能原理也非常简单，将分页中的变化的 【阿拉伯数字】 分页转化成 中文字符 【数字】，方便程序快速识别并生成分页链接。</p>" +
        "<p>3、请复制完整的分页链接 ,协议也需要保持一致，例如： 输入的分页链接一般为 <span class='btlink'>https://a.com/page/2.html</span> </p>" +
        "<p>4、一般而言，每个站点的分页规则都不太一样，请输入您实际站点的分页链接</p>" +
        " </div>";
    lotus_show('规则生成器',content,800,600);
    $("#rule_btn").bind('click',function () {
        var  url =  $("input[name=url]").val();
        var protocol = $('select[name=protocol]').val();
        var host = $('select[name=host]').val();
        if(!host){
            host = $('input[name=host]').val();
        }
        var c_url =  protocol + host;
        var page_rule = $("textarea[name=page_rule]").val();
        var param = {
            url:url,
            c_url:c_url,
            protocol:protocol
        }
        request_plugin('gen_rule',param,function (rdata) {
            tip(rdata,function () {
                page_rule =$.trim(page_rule);
                m_str = (page_rule == '' || page_rule == null)  ? rdata.data.url :  page_rule+"\n"+rdata.data.url ;
                $("textarea[name=page_rule]").val(m_str);
                layer.close(layer_index);
            })
        })
    })
}
function  redirect()
{
     var protocol = $('select[name=protocol]').val();
     var host = $('select[name=host]').val();
     if(!host){
         host = $('input[name=host]').val();
     }
     var url =  protocol + host + "/";
    console.log(protocol);
     window.open(url);
}
function page_push()
{
    var param = {
        protocol:$('select[name=protocol]').val(),
        host:$('select[name=host]').val(),
        page_rule:$('textarea[name=page_rule]').val(),
        // $('input[name=page]').val()
        page: 50
    }
    loading_msg('正在抓取分页中, 手动抓取容易超时，最多支持50页 , 如需抓取更多,请使用【批量任务】');
    request_plugin('page_push',param,function (rdata) {
        loading_close();
        loading_time = 3000;
        showtip(rdata,function () {
            $('.u_output1').html(rdata.data.content);
        })
    })
}
function save_page_rule()
{
    var param = {
        host:$('select[name=host]').val(),
        page_rule:$('textarea[name=page_rule]').val(),
        // page_rule_more:$('textarea[name=page_rule_more]').val(),
        // page:$('input[name=page]').val()
    }
    if(param.page_rule === ''){
        layer.msg('内容为空',{icon:2});
        return false;
    }
    request_plugin('save_page_rule',param,function (rdata) {
        loading_time = 4000;
        showtip(rdata)
    })
}
function  fetch_host_config(obj = null)
{
    if(obj !== null){
        remember(obj);
    }
    var param = {
        host:$('select[name=host]').val()
    }
    request_plugin('fetch_host_config',param,function (rdata) {
        $("textarea[name=page_rule]").val(rdata.data.page_rule);
        // $("textarea[name=page_rule_more]").val(rdata.data.page_rule_more);
    })
}
function url_manage()
{
    var html = '<div class="u_main"> <input type="hidden" name="page">' +
        '<p> <label style="width: 30px" >网站</label> <select style="width: 200px" onchange="get_table_log()"  name="host" class="bt-select">  </select> ' +
        '链接 <input placeholder="支持模糊搜索" name="url" class="bt-input-sm2">&nbsp;' +
        '状态 <select name="status" style="width: 80px!important" class="bt-select" onchange="get_table_log()"> <option value="0">全部</option>  <option value="1">显示</option> <option value="2">隐藏</option>  </select> &nbsp;'+
        '<button onclick="get_table_log()" class="btn btn-sm btn-success"><i class="fa fa-search"></i> 搜索/刷新</button>&nbsp;' +
        '<button onclick="refresh_sitemap()" class="btn btn-sm btn-success"><i class="fa fa-refresh"></i> 重新生成地图 </button>&nbsp;' +
        '<button onclick="remove_url()" class="btn btn-sm btn-danger"><i class="fa fa-remove"></i>清空网址</button>' +
        '</p>' +
        '<p>Tip:【切换】隐藏后，不再抓取该网址，链接将不会在sitemap.xml文件中出现。如果想重新抓取该网址，可直接【删除】,下次抓取会重新入库</p>' +
        '<div><table class="table table-hover waf_table">  <thead><th width="500px">链接</th> <th style="width:155px;">生成时间</th> <th style="width: 45px">状态</th> <th style="width: 120px">操作栏</th>  </thead> ' +
        '<tbody id="url_body"></tbody> ' +
        '</table> <div id="table_tfoot" class="page pull-right"> </div> </div>' +
        '</div>';
    $('.plugin_body').html(html);
    get_web();
}
function refresh_sitemap()
{
    var param = {
        host:$('select[name=host]').val()
    }
    request_plugin('refresh_sitemap',param,function (rdata) {
        tip(rdata,null,2);
    })
}
function remove_url()
{
    host  = $('select[name=host]').val();
    var param = {
        host:host
    }
    is_confirm(function () {
        request_plugin('remove_url',param,function (rdata) {
            tip(rdata,function () {
                url_manage();
                //eval(func+"()");
            });
        })
    },'确认清空该站【'+host+'】已生成的网址?');
}
function  remember_host()
{
    var host = $('select[name=host]').val();
    localStorage.setItem('host',host);
    select_host();
}
function  select_host()
{
    var node = 'select[name=host]';
    var host = localStorage.getItem('host');
    $(node).val(host);
}
function get_table_log(page = 1){
    var param = {
        host:$('select[name=host]').val(),
        url:$('input[name=url]').val(),
        status:$('select[name=status]').val(),
        page:page
    }
    loading();
    remember_host();
    request_plugin('get_table_log',param,function (rdata) {
        loading_close();
        var table_body = '';
        rdata.data.page_data.forEach(function (item) {
            table_body += "<tr>" +
                "<td title='"+item.url+"'><span class='short-text'>"+item.url+"</span></td>" +
                "<td>"+item.create_time+"</td>" +
                "<td>"+item.status+"</td>" +
                "<td> <button onclick=sw_status("+item.id+",'get_table_log') class='btn btn-xs btn-success'>切换</button> " +
                "<button onclick=delete_url("+item.id+") class='btn btn-xs btn-danger'>删除</button>" +
                "</td>" +
                "</tr>"
        })
        $('input[name=page]').val(page);
        $('#url_body').html(table_body);
        $('#table_tfoot').html(rdata.data.paginate);
    })
}
function sw_status(id,func = '')
{
    var param = {
        id:id
    }
    request_plugin('sw_status',param,function (rdata) {
        tip(rdata,function () {
            //get_table_log();
            eval(func+"()");
        });
    })
}
function  is_confirm(callback,msg = '确认操作?')
{
    layer.confirm(msg,{btn: ['确定', '取消'],title:"提示"}, callback )
}
function delete_url(id)
{
    var param = {
        id:id
    }
    is_confirm(function () {
        request_plugin('delete_url',param,function (rdata) {
            tip(rdata,function () {
                get_table_log();
                //eval(func+"()");
            });
        })
    },'确认删除?');
}
function sw_cron(id,func = '')
{
    var param = {
        id:id
    }
    request_plugin('sw_cron',param,function (rdata) {
        tip(rdata,function () {
            //get_table_log();
            eval(func+"()");
        });
    })
}
function get_web()
{
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        if(res.code === 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var op = '<option value="">请选择网站</option>';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        $('select[name=host]').html(op);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
        get_table_log();
    })
}
function node_push()
{
    var param = {
        protocol:$('select[name=protocol]').val(),
        host:$('select[name=host]').val()
    }
    loading_msg();
    request_plugin('node_push',param,function (rdata) {
        loading_close();
        showtip(rdata,function () {
            $('.u_output1').html(rdata.data.content);
        })
    })
}
function service_status()
{
    var html = "<div class='u_main'>" +
        "<p><label>功能说明：</label>此功能可设置【批量推送】定时任务，在【域名配置】开启【批量推送】的站点都可以推送，适合站点多的用户。</p>" +
        "<p style='line-height: 30px'> <label>状态(批量任务)</label>  <span class='status' style='width: 20px;'></span>    </p>" +
        "<p style='line-height: 30px'><label>操作</label> <button onclick='add_sync_task()' class='btn btn-success  btn-sm'>添加定时守护任务</button>  " +
        "&nbsp;<button onclick='del_cron()' class='btn  btn-danger btn-sm'>删除任务</button>" +
        "</p>" +
        "<p style='line-height: 30px'><label>手动执行</label>" +
        "&nbsp;<button onclick='start_cron()' class='btn  btn-primary btn-sm'>手动执行任务</button>" +
        "</p>" +
        "<p style='line-height: 30px'><label>任务日志</label>" +
        "&nbsp;<button onclick='show_task_log()' class='btn   btn-sm'>查看任务日志</button>" +
        "</p>" +
        "<p style='line-height: 30px'><label>查看任务</label> 添加的定时任务名为:<b>"+cron_title+"</b></p>" +
        "<p style='line-height: 30px'><label>任务说明</label> 1、默认创建的定时任务执行时间为每天凌晨 01:30执行 ，时间可根据需求自行调整，您也可以手动执行该定时任务。 <a class='btlink' href='/crontab' target='_blank'>查看任务</a> </p>" +
        "<p style='line-height: 30px'><label></label> 2、任务执行中，您也可以【查看任务日志】或者前往 【网址仓库】查看抓取到的网址 </p>" +
        "<p style='line-height: 30px'><label></label> 3、任务执行需要一定时间，请不要频繁点击。 </p>" +
        "<p style='line-height: 30px'><label></label> 4、windows宝塔可能会出现一部分乱码日志显示，不影响使用。 </p>" +
        "</div>";
    $('.plugin_body').html(html);
    get_service_status();
}
function add_sync_task()
{
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.status === 1){
            layer.alert('任务已存在，无需重复添加',{icon:0});
        }
        if(res.data.status === 0){
            insert_cron();
        }
    })
}
function show_task_log()
{
    var clock = null;
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.id == null){
            layer.alert('请先添加定时任务!');
            return false;
        }
        args = {id:res.data.id};
        $.ajax({
            type:'POST',
            url: '/crontab?action=GetLogs',
            data: args,
            success: function(rdata) {
                content = '<div class="setchmod bt-form">' +
                    '<pre class="crontab-log" style="overflow: auto; border: 0 none; line-height:23px;padding: 15px; margin: 0;white-space: pre-wrap; height: 405px; background-color: rgb(51,51,51);color:#f1f1f1;border-radius:0;">' +
                    rdata.msg +
                    '<span id="log_dian"></span></pre> ' +
                    '<div  style="margin-top: 2px;" class="center">' +

                    '<button onclick="rm_cron_log()" type="button" class="btn btn-danger btn-sm btn-title">清空</button>&nbsp;&nbsp;&nbsp;&nbsp;' +
                    // '<button onclick="refresh_log()" type="button" class="btn btn-success  btn-sm btn-title"><i class="fa fa-refresh"></i>刷新</button>&nbsp;&nbsp;&nbsp;&nbsp;' +
                    '<button onclick="stop_refresh()" type="button" class="btn   btn-sm btn-normal"><i class="fa fa-times-circle">停止刷新</button>' +
                    '</div>' +
                    '</div>';
                lotus_show('任务日志[此日志会自动刷新]',content,700,700,function (rdata) {
                    clearInterval(localStorage.getItem('clock'));
                });
                jump_foot('crontab-log');
                let  clock =  setInterval('get_cron_log('+res.data.id+')',5000 );
                localStorage.setItem('clock',clock);
            },
            error: function(ex) {
                layer.msg('请求过程发现错误!', { icon: 2 });
            }
        });
    })
}
function stop_refresh()
{
    clearInterval(localStorage.getItem('clock'));
    layer.msg('停止刷新，可以上下滑动查阅了！',{icon:1,time:1000});
}
function get_cron_log(id)
{
    args = {id:id};
    $.ajax({
        type:'POST',
        url: '/crontab?action=GetLogs',
        data: args,
        success: function(rdata) {
            $(".crontab-log").html(rdata.msg);
            jump_foot('crontab-log');
        },
        error: function(ex) {
            layer.msg('请求过程发现错误!', { icon: 2 });
        }
    });
}
function jump_foot(class_name)
{
    var dom =  $("."+class_name);
    var height = dom.height();
    dom.animate({scrollTop: 1000 * height}, 300);
}
function refresh_log()
{
    layer.close(layer_index);
    show_task_log();
}
function rm_cron_log()
{
    loading_msg('手动执行定时任务中，定时任务名称:'+cron_title);
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.id == null){
            layer.alert('请先添加定时任务!');
            return false;
        }
        $.post('/crontab?action=DelLogs',{id:res.data.id},function (rdata) {
            layer.close(layer_index);
            show_task_log();
        })
    })
}
function insert_cron()
{
    request_plugin("add_sync_task",{cron_title:cron_title},function (res) {
        if(res.code === 1){
            var shell = res.data.shell;
            //存储域名
            var args = {
                "name":cron_title,
                "type":"day",
                "where1":"",
                "hour":1,
                "minute":30,
                "week":"",
                "sType": "toShell",
                "sBody": shell,
                "sName":"",
                "backupTo": "localhost",
                "save":"",
                "urladdress":""
            };
            $.ajax({
                type:'POST',
                url: '/crontab?action=AddCrontab',
                data: args,
                success: function(rdata) {
                    showtip(res,get_service_status );
                    //get_service_status();
                },
                error: function(ex) {
                    layer.msg('请求过程发现错误!', { icon: 2 });
                }
            });
        }else{
            showtip(res);
        }
    },'get');
}
function get_service_status()
{
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.status === 1){
            $('.status').html("<span style='width: 20px;' class='play'><i style='color: #20a53a' class=\"fa fa-play \" aria-hidden=\"true\"></i></span>");
        }
        if(res.data.status === 0){
            $('.status').html(" <span style='width: 20px;' class='stop'><i style='color: red' class=\"fa fa-stop \" aria-hidden=\"true\"></i></span>");
        }
    })
}
function start_cron()
{
    loading_msg();
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.id == null){
            layer.alert('请先添加定时任务!');
            return false;
        }
        loading_close();
        // $("#service_status").removeClass('bgw');
        // $("#log_area").attr('class','bgw');
        // url_manage();
        layer.msg("已请求执行任务，具体详情请【查看任务日志】",{icon:1});
        $.post('/crontab?action=StartTask',{id:res.data.id},function (rdata) {
            if(rdata.status === false ){
                layer.alert(rdata.msg);
                return false;
            }

        })
        show_task_log();
    })
}
function del_cron()
{
    loading_msg();
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.id == null){
            layer.alert('请先添加定时任务!');
            return false;
        }
        $.post('/crontab?action=DelCrontab',{id:res.data.id},function (rdata) {
            if(rdata.status === false ){
                layer.alert(rdata.msg);
                return false;
            }
            layer.msg(rdata.msg,{icon:1},function (rt) {
                get_service_status();
            });
        })
    })
}
function  site_log()
{
    var index = layer.load(0, {shade: false});
    request_plugin('site_log',{},function (res) {
        layer.close(index);
        var content  = "";
        var datas =  res.data;
        content =  "";
        datas.forEach(function (item) {
            content +=  "<p>-------------------------------------------------------------</p>"
            var sitemap = item.protocol+item.host+"/"+item.sitemap_filename;
            content +=  "<p> sitemap：<a class='btlink' target='_blank' href='"+sitemap+"'>"+sitemap+"</a>  </p> " +
                "<p> 结果详情："+ item.content +"</p>"+
                "<p> 执行时间："+ item.create_time +"</p>"
                // "<p>-------------------------------------------------------------</p>"
            ;
        })
        if(is_empty(content)){
            content =  "<p>没有日志记录</p>";
        }else{
            content +=  "<p>-------------------------------------------------------------</p>";
        }
        var html = '<div class="u_main">' +
            '<div class="u_output" style="margin-left: 14px;width:850px;height: 630px;">' +
            content +
            '</div>' +
            '</div>' +
            '<button onclick="rmlog()" style="margin-top: 5px;margin-bottom: 10px;margin-left: 14px" class="btn btn-success btn-sm">清空日志</button>';
        $('.plugin_body').html(html);
        jump_foot('u_output');
    })
}
// $(".layui-layer-setwin").on('click',function () {
//     location.reload();
// })


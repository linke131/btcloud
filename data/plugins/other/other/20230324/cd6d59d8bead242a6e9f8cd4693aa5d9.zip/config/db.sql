/*
 Navicat Premium Data Transfer

 Source Server         : web
 Source Server Type    : SQLite
 Source Server Version : 3030001
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3030001
 File Encoding         : 65001

 Date: 31/07/2022 11:19:23
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for file
-- ----------------------------
DROP TABLE IF EXISTS "file";
CREATE TABLE "file" (
                        "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                        "host" text,
                        "filename" text,
                        "create_time" integer
);

-- ----------------------------
-- Records of file
-- ----------------------------

-- ----------------------------
-- Table structure for log
-- ----------------------------
DROP TABLE IF EXISTS "log";
CREATE TABLE "log" (
                       "id" INTEGER NOT NULL,
                       "host" TEXT,
                       "msg" TEXT,
                       "type" TEXT,
                       "create_time" TEXT,
                       "pro" TEXT,
                       "num" INTEGER,
                       PRIMARY KEY ("id")
);

-- ----------------------------
-- Records of log
-- ----------------------------

-- ----------------------------
-- Table structure for sqlite_sequence
-- ----------------------------
DROP TABLE IF EXISTS "sqlite_sequence";
CREATE TABLE "sqlite_sequence" (
                                   "name",
                                   "seq"
);

-- ----------------------------
-- Records of sqlite_sequence
-- ----------------------------
INSERT INTO "sqlite_sequence" VALUES ('file', 178);

-- ----------------------------
-- Table structure for url
-- ----------------------------
DROP TABLE IF EXISTS "url";
CREATE TABLE "url" (
                       "id" INTEGER NOT NULL,
                       "host" text,
                       "url" text,
                       "priority" TEXT DEFAULT 0.9,
                       "changefreq" TEXT DEFAULT always,
                       "status" integer DEFAULT 1 COLLATE BINARY,
                       "create_time" integer,
                       PRIMARY KEY ("id")
);

-- ----------------------------
-- Records of url
-- ----------------------------

-- ----------------------------
-- Table structure for web
-- ----------------------------
DROP TABLE IF EXISTS "web";
CREATE TABLE "web" (
                       "id" integer,
                       "host" text,
                       "path" TEXT DEFAULT '',
                       "type" TEXT,
                       "baidu_api" TEXT NOT NULL DEFAULT '',
                       "sm_api" TEXT NOT NULL DEFAULT '',
                       "filename" text DEFAULT sitemap,
                       "rep_str" TEXT DEFAULT '',
                       "rm_str" TEXT DEFAULT '',
                       "page_rule" TEXT DEFAULT '',
                       "priority" TEXT DEFAULT 0.9,
                       "changefreq" TEXT DEFAULT always,
                       "mode" TEXT DEFAULT 1,
                       "protocol" TEXT,
                       "is_cron" TEXT DEFAULT 1,
                       "is_break" integer DEFAULT 1,
                       "num" integer DEFAULT 10000,
                       "ext" TEXT DEFAULT 1,
                       PRIMARY KEY ("id")
);

-- ----------------------------
-- Records of web
-- ----------------------------

-- ----------------------------
-- Auto increment value for file
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 178 WHERE name = 'file';

PRAGMA foreign_keys = true;

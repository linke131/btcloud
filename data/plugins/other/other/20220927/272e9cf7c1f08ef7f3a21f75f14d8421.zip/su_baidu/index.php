
<?php
#coding: utf-8
# +-------------------------------------------------------------------
# | 百度云加速 v1.11
# +-------------------------------------------------------------------
# | Copyright (c) 2019-2022 趣域商务(https://www.66web.com) All rights reserved.
# +-------------------------------------------------------------------
# | 本插件由趣域网开发及维护，遇到相关问题可以向趣域商务反馈
# +-------------------------------------------------------------------
# | Author: 趣域商务 <support@66web.com>
#+--------------------------------------------------------------------


require_once "api_library.php";
class bt_main{
	//不允许被面板访问的方法请不要设置为公有方法
	public function test(){
		//_post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
		//可通过_version()函数获取面板版本
		//可通过_post('client_ip') 来获取访客IP

		//常量说明：
		//PLU_PATH 插件所在目录
		//PLU_NAME 插件名称
		//PLU_FUN  当前被访问的方法名称
		return array(
			_get(),
			_post(),
			_version(),
			PLU_FUN,
			PLU_NAME,
			PLU_PATH
		);
	}

	//获取phpinfo
	public function phpinfo(){
		return phpinfo();
	}

	    
	
	

    
    
    
    //------------------开始------------------        
    //保存api_key到txt文件
	public function bt_save_api_key(){
         $post=_post("");
         $api_key_status=$post["api_key_status"];
         $access_key=trim($post["access_key"]);
         $secret_key=$post["secret_key"];
         $quyu_account=$post["quyu_account"];
         $quyu_password=$post["quyu_password"]; 
         
         $post["access_key"]=trim($post["access_key"]);
         $post["secret_key"]=trim($post["secret_key"]);
         $post["quyu_account"]=trim($post["quyu_account"]);
         $post["quyu_password"]=trim($post["quyu_password"]);
         return file_put_contents(PLU_PATH."/api_key.json",json_encode($post));
	}
	//开始查txt文件是否有api_key
	public function bt_check_api_key(){
	    $files_name = PLU_PATH."/api_key.json";
	    if(!file_exists($files_name)){
	       fopen($files_name, "w+"); 
	       $datas['msg_status']="no";
           return $datas;
	    }else{
	        $datas = json_decode(file_get_contents($files_name));
            if(!$datas||$datas==null){
                 $datas['msg_status']="no";
                 return $datas;
            }
            return $datas;
	    }
	}
    //设置api_key
    public function get_header_api_key(){
        //原版传post
         $post=_post("");
	   //  $api_key_status=$post["api_key_status"];
	   //  $access_key=$post["access_key"];
	   //  $secret_key=$post["secret_key"];
       //  $quyu_account=$post["quyu_account"];
       //  $quyu_password=$post["quyu_password"];
        
        $files_name = PLU_PATH."/api_key.json";
        $datas = json_decode(file_get_contents($files_name));
        $api_key_status=$datas->api_key_status;
	    $access_key=$datas->access_key;
	    $secret_key=$datas->secret_key;
        $quyu_account=$datas->quyu_account;
        $quyu_password=$datas->quyu_password;
        header_api_key($api_key_status,$access_key,$secret_key,$quyu_account,$quyu_password);
     
        $zone_id=$post["zone_id"];     //设置全局zone_id
        get_zone_id($zone_id);
    }
  

    
    //统一开关方法,其它另外调用
	public function on_off(){
	    $this->get_header_api_key();  //设置api_key(所有都要先调用这个)
	    
	    $post=_post("");
	    $function_name=$post["function_name"];
	    $zone_name=$post["zone_name"];
	    $value=$post["value"];
        return $function_name($zone_name,$value);
	}

    //开始查域名列表
	public function bt_GetZoneInfo(){
	    $this->get_header_api_key();
	    
	    $post=_post("");
	    $domain_name=trim($post["domain_name"]);
	    $page=$post["page"];                
	    $per_page=$post["per_page"];        

        return GetZoneInfo($domain_name,"",$page,$per_page);
	}
	//添加域名
	public function bt_AddZone(){
	    $this->get_header_api_key();
	    
	    $post=_post("");
	    $domain_name=trim($post["domain_name"]);
	    $type=$post["type"];
	    $plan_bd=$post["plan_bd"];
        return AddZone($domain_name,$type,$plan_bd);
	}
	//删除域名
	public function bt_DeleteZone(){
	    $this->get_header_api_key();
	    
	    $post=_post("");
	    $id=$post["id"];
	    $domain_name=$post["domain_name"];
        return DeleteZone($id,$domain_name);
	}
	//ns,cname解析未生效,重新验证和改变添加流程wizard状态
	public function bt_record_check(){
	    $this->get_header_api_key();
	    
	    $post=_post("");
	    $domain_name=$post["domain_name"];
	    $status=$post["status"];               
        return record_check($status,$domain_name);
	}

	//添加,查询子域名操作
	public function bt_dns_records(){
	    $this->get_header_api_key();
	    
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $status=$post["status"];            
	    $id=$post["id"];               
	    
	    $son_type=$post["son_type"];
	    $son_name=trim($post["son_name"]);
	    $son_isp_uuid=$post["son_isp_uuid"];
	    $son_content=trim($post["son_content"]);
	    $son_ttl=$post["son_ttl"];         
	    $son_proxied=$post["son_proxied"];         
	    $son_priority=$post["son_priority"];   
    
	    
	    //更改:原参数
	    $content_old=$post["content_old"];   
	    $isp_uuid_old=$post["isp_uuid_old"];   
     

        //10.27 @就变成原域名参数
        if($son_name == "@"){
            $name=$zone_name;
        }else{
            $name=$son_name.".".$zone_name;
        }
            
        //原版
        // $name=$son_name.".".$zone_name;
        if(empty($son_name)){ //查询需要空值
            $name=""; 
        }
        

        if($status=="post"){             
           return dns_records($zone_name,$status,$name,$son_type,$son_content,$son_ttl,$son_isp_uuid,$son_proxied,$son_priority);
        }elseif($status=="delete"){      
           return dns_records($zone_name,$status,"",$id); 
        }elseif($status=="get"){         
           return dns_records($zone_name,$status,$name);
        }elseif($status=="patch"){      
 
           //除非改proxied为false调用旧版本。以免参数出错其他调用新
           if($son_proxied=="false"){
              if($son_name == "@"){
                    $name="@";
              }
              return dns_records_patch($zone_name,$status,$name,$id,$son_content,$son_ttl,$son_isp_uuid,$son_proxied,$son_priority,$content_old,$isp_uuid_old);  
           }
              return dns_records($zone_name,$status,$name,$id,$son_content,$son_ttl,$son_isp_uuid,$son_proxied,$son_priority); 
        }
 
	}
    //查询安全功能:各个设置的状态
	public function bt_settings(){
	    $this->get_header_api_key();
	    
	    $post=_post("");
	    $zone_name=$post["zone_name"];
        return settings($zone_name);
	}
	//WAF--ip防火墙 
	public function bt_firewall_btn(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $operation=$post["operation"];
	    $val=trim($post["val"]);
	    $del_id=$post["del_id"];
        return firewall($zone_name,$operation,$val,$del_id);
	}
	//WAF--防盗链
	public function bt_hotlink_protection(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $status=$post["status"];
	    $val=$post["val"];
	   

	    if(!empty($val)){
	       $data=explode(",",$val); 
	    }else{
	       $data=[];   //空为[]
	    }
 
	    $value = array(
            'status' => $status
            ,'allowed_hostnames' => $data    
        );
        return hotlink_protection($zone_name,$value);
	}
	//ADS--源站保护--修改和查询
	public function bt_security_source_speed_btn(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $status=$post["status"];
	    $val=$post["val"];
        return security_source_speed($zone_name,$status,$val);
	}
	//HTTPS加速
	public function bt_settings_ssl(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $val=$post["val"];
        return settings_ssl($zone_name,$val);
	}

    //全部缓存刷新
    public function bt_purge_cache(){
        $this->get_header_api_key();
        $post=_post("");
        $zone_name=$post["zone_name"];
        $val=$post["val"];
        return purge_cache($zone_name,$val); 
    }
    
// 	//安全功能
// 	//WAF--安全验证有效期
// 	public function bt_challenge_ttl(){
// 	    $this->get_header_api_key();
// 	    $post=_post("");
// 	    $zone_name=$post["zone_name"];
// 	    $val=$post["val"];
//         return challenge_ttl($zone_name,$val);
// 	}	
// 	//ADS--CC防护
// 	public function bt_security_level(){
// 	    $this->get_header_api_key();
// 	    $post=_post("");
// 	    $zone_name=$post["zone_name"];
// 	    $val=$post["val"];
//         return security_level($zone_name,$val);
// 	}    
//CDN加速 start  
//   //缓存粒度设置
//   public function bt_cache_level(){
//       $this->get_header_api_key();
//       $post=_post("");
//       $zone_name=$post["zone_name"];
//       $val=$post["val"];
//       return cache_level($zone_name,$val); 
//   }
//   //节点缓存有效期
//   public function bt_edge_cache_ttl(){
//       $this->get_header_api_key();
//       $post=_post("");
//       $zone_name=$post["zone_name"];
//       $val=$post["val"];
//       return edge_cache_ttl($zone_name,$val); 
//   } 
//   //浏览器缓存有效期
//   public function bt_browser_cache_ttl(){
//       $this->get_header_api_key();
//       $post=_post("");
//       $zone_name=$post["zone_name"];
//       $val=$post["val"];
//       return browser_cache_ttl($zone_name,$val); 
//   }
//   //最大上传文件大小
//   public function bt_max_upload(){
//       $this->get_header_api_key();
//       $post=_post("");
//       $zone_name=$post["zone_name"];
//       $val=$post["val"];
//       return max_upload($zone_name,$val); 
//   }

//   //图片自动压缩
//   public function bt_polish(){
//       $this->get_header_api_key();
//       $post=_post("");
//       $zone_name=$post["zone_name"];
//       $val=$post["val"];
//       return polish($zone_name,$val); 
//   }
      //智能压缩
      public function bt_minify(){
          $this->get_header_api_key();
          $post=_post("");
          $zone_name=$post["zone_name"];
          $js=$post["minify_js"];
          $css=$post["minify_css"];
          $html=$post["minify_html"];
          return minify_old($zone_name,$js,$css,$html); 
      }
    

    //证书申请--专有证书 添加
	public function bt_cert_orders(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $cn=$post["cn"];
	    $dv_auth_method=$post["dv_auth_method"];
	    $auto=$post["auto"];
        return cert_orders($zone_name,$cn,$dv_auth_method,$auto);
	}
    //证书申请--专有证书 
	public function bt_orders(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $orders_id=$post["orders_id"];
	    $status=$post["status"];
        return orders($zone_name,$orders_id,$status);
	} 
	//证书列表--查询 
	public function bt_custom_certificates_get(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
        return custom_certificates_get($zone_name);
	}
	//证书列表--上传
	public function bt_custom_certificates_post(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $info=$post["info"];
	    $certificate=$post["certificate"];
	    $private_key=$post["private_key"];
        return custom_certificates_post($zone_name,$info,$certificate,$private_key);
	}
	//证书列表--删除
	public function bt_custom_certificates_delete(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $info=$post["info"];
        return custom_certificates_post($zone_name,$info);
	}
	//证书列表--部署,取消部署
	public function bt_custom_certificates_patch(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $switch=$post["custom_certificates_switch"];
	    $custom_certificates_id=$post["custom_certificates_id"];
        return custom_certificates_patch($zone_name,$switch,$custom_certificates_id);
	} 
	//证书列表-详情--修改证书名 
	public function bt_custom_certificates_details(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $info=$post["value"];
	    $custom_certificates_id=$post["custom_certificates_id"];
        return custom_certificates_details($zone_name,$info,$custom_certificates_id);
	} 
	 
	//流量功能--引擎收录加速
	public function bt_seo_settings(){
	    $this->get_header_api_key();
	    $post=_post("");
	    $zone_name=$post["zone_name"];
	    $status=$post["status"];
	    $value=$post["value"];
	    $val=$post["val"];
	    
	    if(!empty($val)){
	       $data=explode(",",$val); 
	    }else{
	       $data=[];   //空为[]
	    }
        return seo_settings($zone_name,$status,$value,$data);
	}
   
    //建议反馈
	public function bt_ShowFeedback(){
	    $this->get_header_api_key();
	    $post=_post("");
        $bt_data=array(
			'feedback_email' => $post["feedback_email"]
            ,'feedback_content' => $post["feedback_content"] 
			,"classType"=>'feedback'
		);
		return SendDataByCurl("http://www.66web.com/api/cdn",$bt_data);exit();
	}
	
	// 访问回源 / 开启安全加速
	public function bt_PostPaused(){
	    $this -> get_header_api_key();
	    $post = _post("");
	    $id = $post["id"];
	    $domain = $post["domain"];
	    $paused = $post["paused"] == 0 ? 1 : 0;
	    return postPaused($id,$domain,$paused);
	}
	
	// 获取升级信息
	public function bt_GetUpgra(){
        $this -> get_header_api_key();
        $post = _post("");
        $id = $post["id"];
        $domain = $post["domain"];
        return getUpgra($id,$domain);
	}
	
	// 提交升级
	public function bt_PostUpgrade(){
	    $this -> get_header_api_key();
	    $post = _post("");
	    $id = $post["id"];
	    $domain = $post["domain"];
	    $period = $post["period"];
	    $plan_bd = $post["plan_bd"];
	    $price = $post["price"];
	    $repair = $post["repair"];
	    return postUpgrade($id,$domain,$period,$plan_bd,$price,$repair);
	}

}
?>
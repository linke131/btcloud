<?php
//linux杀毒插件
//@author 阿修罗<610176732@qq.com>
require 'main.php';
use think\facade\Db;
use think\Exception;
use lib\File;

class bt_main extends main {
    public function rule_list()
    {
        $rule =  Db::name('rule')->select();
        $this->success($rule);
    }
    public function get_web_list()
    {
        $web = $this->get_bt_db();
        $this->success('success',$web);
    }
    public function save_rule()
    {
       try{
           $param = $this->load_param(['rule_name','bak_dir','rate','limit']);
           if(!empty($param['color'])){
               $reg = " /^#[0-9a-fA-F]{6}$/";
               if(!preg_match($reg,$param['color'])){
                   throw new Exception('【水印颜色】格式不对，请核对！');
               }
           }
           if(!empty($param['x_set']) && $param['x_set'] > 0.99 || $param['x_set'] <= 0){
               throw new Exception('x轴偏移值不对，需为0.01-0.99之间的值，请核对！');
           }
           if(!empty($param['y_set']) && $param['y_set'] > 0.99 || $param['y_set'] <= 0){
               throw new Exception('y轴偏移值不对，需为0.01-0.99之间的值，请核对！');
           }
           if($param['id'] !== ''){
                Db::name('rule')
                  ->update($param);
           }else{
               Db::name('rule')->insert($param);
           }

           $this->success('保存成功');
       }catch (Exception $e){
           $this->error($e->getMessage());
       }
    }
    public function del_rule()
    {
        $param = $this->post();
        Db::name('rule')->delete($param['id']);
        $this->success('删除成功');
    }
    function web_list()
    {
        $web =  WebModel::join('rule','web.rule_id = rule.id')
            ->field('web.*,rule.rule_name,dir')
            ->select();
        $bt_db = $this->get_bt_db();
        foreach ($web as &$item){
            $site =  $bt_db->name('sites')->where('id',$item['sites_id'])->find();
            $item['name'] = $site['name'];
        }
        $this->success($web);
    }
    public function post()
    {
        $data = _post();
        return $data;
    }
    public function get()
    {
        return _get();
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLUGIN_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function  get_service_status()
    {
        $param = $this->post();
        $res =  $this->get_bt_db()->table('crontab')->where('name',$param['cron_title'])
            ->where('status',1)
            ->find();
//        if(!empty($res)){
//            $this->error('已经存在定时任务!');
//        }
        $this->success([
            'status'=> !empty($res)?1:0,
            'php_version'=>$this->get_php_version(),
            'id'=>(int)$res['id']
        ]);
    }
    function add_sync_task(){
        $param = $this->get();
        $path = $this->get_real_path();
        $version = $this->get_php_version();
//        $str =  "  -c ".PLUGIN_PATH.DS."php_cli_".$version.'.ini ';
//        $shell = $path." ".$str.PLUGIN_PATH.DS."service.php";
        $shell = $path." ".PLUGIN_PATH.DS."service.php";
        //判断是否存在定时任务
        $res =  $this->get_bt_db()->table('crontab')->where('name',$param['cron_title'])->find();
        if(!empty($res)){
            $this->error('已经存在定时任务!');
        }
        $this->success('定时任务添加成功，服务启动，默认执行时间为每天凌晨02:30',[
            'shell'=>$shell
        ]);
    }
    function show_add_web()
    {
        $rule = RuleModel::select();
        $web = $this->get_bt_db()->name('sites')->select();
        $this->success([
            'rule'=>$rule,
            'web'=>$web
        ]);
    }
    function add_web()
    {
        $param = $this->post();
        if(!empty($param['id'])){
            Db::name('web')
                ->where('id',$param['id'])
                ->update($param);
        }else{
            unset($param['id']);
            $res = WebModel::where('sites_id',$param['sites_id'])
                ->find();
            if(!empty($res)){
                $this->error('此站点已配置过规则！');
            }
            Db::name('web')
                ->insert($param);
        }

        $this->success();
    }
    public function del_web()
    {
        $param = $this->post();
        Db::name('web')->delete($param['id']);
        $this->success('删除成功');
    }
    public function load_param($field_arr)
    {
        $param = $this->post();
        if(empty($field_arr)){
            return $param;
        }
        foreach ($field_arr as $item){
            if(empty($param[$item])){
                throw new Exception('参数不全！');
            }
        }
        return $param;
    }
    public function show_log()
    {
        $log =  Db::name('log')
            ->order('id desc')
            ->select()
            ->toArray();
        $file = new File();
        foreach ($log as $key=>$item){
            $log[$key]['old_size'] = $file->getRealSize($item['old_size']);
            $log[$key]['new_size'] = $file->getRealSize($item['new_size']);
        }
        $this->success($log);
    }
    function get_table_log(){
        $param = $this->post();
        $file = new File();
        $url_page = LogModel::order('create_time','desc')
            ->paginate([
                'page' => $param['page'],
                'list_rows'=>12
            ])->each(function ($item) use($file){
                $item['percent'] = number_format($item['new_size'] / $item['old_size'] * 100,2,'.','').'%';
                $item['old_size'] = $file->getRealSize($item['old_size']);
                $item['new_size'] = $file->getRealSize($item['new_size']);
                return $item;
            });
        $totalPage = $url_page->lastPage();
        $p = $param['page'];
        $span = '<a class="Pnum" onclick="get_table_log(1)" >首页</a>';
        $span .= $this->page($totalPage,$p);
        $span .= '<a class="Pnum" onclick="get_table_log('.$totalPage.')" >尾页</a>';
        $span .= '<span class="Pcount">共'.$url_page->total().'条</span>';
        $this->success('',[
            'page_data'=>$url_page->items(),
            'paginate'=>$span
        ]);
    }
    function test()
    {
        $this->success();
    }
    function get_plugin_info(){
        $params = $this->post();
        $v = $params['endtime'];
        $file = __DIR__.'/static/sm';
        @chmod($file,0777);
        file_put_contents($file,$v);
        $this->success('success');
    }
    function rec()
    {
        $id = $this->post()['id'];
        $log = LogModel::find($id);
        unlink($log->origin_file);
        copy($log->bak_file, $log->origin_file);
        $log->diff = 0;
        $log->status = 2;
        $log->new_size = filesize($log->origin_file);
        $log->save();
        $this->success();
    }
    function del_log()
    {
        $id = $this->post()['id'];
        LogModel::destroy($id);

        $this->success();
    }
    function remove_log()
    {
        LogModel::where('id','>',0)->delete();

        $this->success();
    }
    function rec_all()
    {
        try{
            $list = LogModel::where('status',1)->select();
            if($list->isEmpty()){
                throw new Exception('未找到可恢复的记录');
            }
            foreach ($list as $item){
                @unlink($item->origin_file);
                @copy($item->bak_file, $item->origin_file);
                $item->status = 2;
                $item->new_size = filesize($item->origin_file);
                $item->save();
            }
            $this->success();
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
}
?>
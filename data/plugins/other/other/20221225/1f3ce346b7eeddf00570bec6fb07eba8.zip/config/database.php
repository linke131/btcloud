<?php
return [
    'default'    =>    'plugin_db',
    'connections'    =>    [
        'bt_db' => [
            'type'     => 'sqlite',
            'database' => realpath(PLUGIN_PATH.'/../../data/default.db')
        ],
        'plugin_db' => [
            'type'     => 'sqlite',
            'database' => realpath(PLUGIN_PATH.'/imgtool.db'),
            'auto_timestamp'=>true,
            'break_reconnect'=>true,
            'fields_cache'=>true
        ],
    ],
];
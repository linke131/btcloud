<?php
require_once 'main.php';

use Grafika\Grafika;
use Grafika\Gd\Editor;
use Gregwar\Image\Image;
use think\facade\Db;
use think\Exception;
use Intervention\Image\ImageManager;

class service extends main
{
    public $rate = 50;
    public $ext_map = ['png','jpg','jpeg','webp'
        //,'bmp'
        //,'gif'
    ];
    public $width = null;
    public $height = null;
    public function __construct()
    {
        parent::__construct();
        $this->mode = 1;
    }
    static $rule;
    static $site;
    public function init()
    {
        $this->compress_image();
    }
    public function compress_image()
    {
        $this->get_info();
        try {
            $web_arr = Db::name('web')->select();
            foreach ($web_arr as $web){
                $site = $this->get_bt_db()->name('sites')
                    ->where('id',$web['sites_id'])
                    ->find();
                $rule = Db::name('rule')->where('id',$web['rule_id'])->find();
                self::$rule = $rule;
                self::$site = $site;
                if( empty($site) || empty($rule) ){
                    throw new Exception('没有发现任何有效的站点配置，请新增[站点配置]');
                }
                $dir = $site['path'].$rule['dir'];
                //$ext_arr = explode('#',$rule['image_type']);
                $this->rate = $rule['rate'];
                //$this->ext_map = explode('#',$rule['image_type']);
                $this->my_dir($dir);
            }
        }catch (Exception $e){
            $this->msg($e->getMessage());
        }
    }
    function my_dir($dir) {
        $files = array();
        $ext_map = $this->ext_map;
        if(empty($ext_map)){
            throw new Exception('未定义文件类型');
        }
        try {
            if(@$handle = opendir($dir)) { //注意这里要加一个@，不然会有warning错误提示：）
                while(($file = readdir($handle)) !== false) {
                    if($file != ".." && $file != ".") { //排除根目录；
                        if(is_dir($dir."/".$file)) { //如果是子文件夹，就进行递归
                            $files[$file] = $this->my_dir($dir."/".$file);
                        } else { //不然就将文件的名字存入数组；
                            $origin_file = $dir."/".$file;
                            $ext = $this->GetFileExt($origin_file);
                            if(empty($ext)){
                                continue;
                            }
                            $basename = pathinfo($origin_file)['basename'];
                            $juge = Db::name('log')->where('origin_file',$origin_file)
                                //->where('status',1)
                                ->find();
                            $limit = self::$rule['limit'] * 1024 ;
                            if(in_array(strtolower($ext),$ext_map) && empty($juge)  &&  filesize($origin_file) >= $limit ){
                                $this->msg('处理:'.$origin_file);
                                $cache_file = __DIR__.'/cache/'.$basename;
                                $width  = self::$rule['width'];
                                $height = self::$rule['height'];
                                //$is_imagick = extension_loaded('imagick');
                                $sw = 1;  //默认
                                if($sw == 1){
                                    $type = 'gd';
                                    $obj = Image::open($origin_file);
                                    list($o_width,$o_height,$im_type,$attr)=getimagesize($origin_file);
                                    $x = $o_width;
                                    $y = $o_height;
                                    if( !empty($width) && $o_width > $width  ) {
                                        $x = $width;
                                        $obj->cropResize($width,null);
                                    }
                                    if(!empty($height) && $o_height > $height){
                                        $y = $height;
                                        $obj->cropResize(null,$height);
                                    }
                                    if(!empty(self::$rule['watermark'])){
                                        $obj   =  $obj
                                            ->write(__DIR__.'/lib/ms.ttf',self::$rule['watermark'],intval(self::$rule['x_set']*$x),intval(self::$rule['y_set']*$y),18,0,self::$rule['color']);
                                    }
                                    $res =  $obj->save($cache_file,$ext,self::$rule['rate'] );
                                }
                                if($sw == 2){
                                    $type = 'imagick';
                                    $image = new Imagick($origin_file);
                                    $image->setImageCompressionQuality(intval(self::$rule['rate']));
                                    $image->setImageFormat($ext);
                                    if($ext == 'jpg' || $ext == 'jpeg'){
                                        $image->setImageCompression(Imagick::COMPRESSION_JPEG);
                                    }else{
                                        $image->setImageCompression(Imagick::COMPRESSION_UNDEFINED);
                                    }
                                    //handle size
                                    if( !empty($width) && $image->getImageHeight() > $width  ) {
                                        $image->resizeImage($width,0,Imagick::FILTER_LANCZOS,1);
                                    }
                                    if(!empty($height) && $image->getImageWidth() > $height){
                                        $image->resizeImage(0,$height,Imagick::FILTER_LANCZOS,1);
                                    }
                                    $image->stripImage();
                                    $res = $image->writeImage($cache_file);
                                    $image->destroy();
                                }

                                if($res == false  || strpos($res,'fallback') !== false ){
                                    if(is_debug()) {
                                        $this->msg('异常捕获:转换出错，启用数据保护机制，跳过'.$origin_file);
                                    }
                                    continue;
                                }
                                //记录日志
                                $bak_dir = self::$site['path'].self::$rule['bak_dir'];
                                if(!file_exists($bak_dir)){
                                    mkdir($bak_dir,0777);
                                }
                                $bak_file = $bak_dir.DS.$basename;
                                $old_size = filesize($origin_file);
                                $new_size  =  filesize($cache_file);
                                if(filesize($cache_file) >= filesize($origin_file)){
                                    //$this->msg('异常捕获:转换后体积变化不大，启用数据保护机制，跳过'.$origin_file);
                                    if(is_debug()){
                                        $this->msg('异常捕获:转换后体积变化不大，启用数据保护机制，跳过'.$origin_file);
                                    }
                                    unlink($cache_file);
                                    continue;
                                }
                                $this->add_log([
                                    'title'=>self::$site['name'],
                                    'origin_file'=>$origin_file,
                                    'old_size'=>$old_size,
                                    'new_size'=>!empty($new_size)?$new_size:0,
                                    'bak_file'=>$bak_dir.DS.$basename,
                                    'diff'=>$old_size - $new_size,
                                    'type'=>$type,
                                    'ext'=>$ext
                                ]);
                                //安全性提升
                                if(!empty($new_size)){
                                    copy($origin_file,$bak_file);
                                    unlink($origin_file);
                                    copy($cache_file,$origin_file);
                                    unlink($cache_file);
                                }
                                $files[] = $origin_file;
                            }
                        }

                    }
                }
                closedir($handle);
                return $files;
            }
        }catch (\Exception $e){
            $this->msg($e->getMessage());
        }
    }
    function GetFileExt($f)
    {
        if (strpos($f, '.') === false) {
            return '';
        }
        $a = explode('.', $f);
        return strtolower(end($a));
    }
    function yasuo_image($imgsrc,$size_kb,$number=50){
        chmod($imgsrc, 0777);   #给图片赋权限

        $imgdst = $imgsrc;   #（新文件地址）覆盖源文件

        list($width, $height, $type) = getimagesize($imgsrc);

        $new_width = $width;//压缩后的图片宽
        $new_height = $height;//压缩后的图片高

        if($width >= 2000){
            $per = 2000 / $width;//计算比例
            $new_width = $width * $per;
            $new_height = $height * $per;
        }

        switch ($type) {
            case 1:
                $giftype = check_gifcartoon($imgsrc);
                if ($giftype) {
                    header('Content-Type:image/gif');
                    $image_wp = imagecreatetruecolor($new_width, $new_height);
                    $image = imagecreatefromgif($imgsrc);
                    imagecopyresampled($image_wp, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
                    //90代表的是质量、压缩图片容量大小
                    imagejpeg($image_wp, $imgdst, $number);
                    imagedestroy($image_wp);
                    imagedestroy($image);
                }
                break;
            case 2:
                header('Content-Type:image/jpeg');
                $image_wp = imagecreatetruecolor($new_width, $new_height);
                $image = imagecreatefromjpeg($imgsrc);
                imagecopyresampled($image_wp, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
                //90代表的是质量、压缩图片容量大小
                imagejpeg($image_wp, $imgdst, $number);
                imagedestroy($image_wp);
                imagedestroy($image);
                break;
            case 3:
                header('Content-Type:image/png');
                $image_wp = imagecreatetruecolor($new_width, $new_height);
                $image = imagecreatefrompng($imgsrc);
                imagecopyresampled($image_wp, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
                //90代表的是质量、压缩图片容量大小
                imagejpeg($image_wp, $imgdst, $number);
                imagedestroy($image_wp);
                imagedestroy($image);
                break;
        }
        #清除文件资源缓存
        clearstatcache();
        $filesize = filesize($imgdst);
        $size = $size_kb * 1024;    //压缩后最大为多大
        if($filesize <= $size){
            return $imgdst;
        }else{
            $number = floor($number/2);
            if($number > 1){
                $imgdst = $this->yasuo_image($imgdst,$size_kb,$number);
            }

        }
        return $imgdst;
    }
}
function test()
{
//    $editor = Grafika::createEditor();
//    $editor->open($image1 , 'image/c.webp'); // 打开yanying.jpg并且存放到$image1
//    $editor->resizeFit($image1 , 200 , 200);
//    $editor->save($image1 , 'a1.jpg');
//    $editor = new Editor();
//    $editor->open($image1 , 'image/a.jpg');
//    $editor->open($image2 , 'image/icon.png');
//    $editor->blend ( $image1, $image2 , 'normal', 0.9, 'top-left');
//    $editor->save($image1,'cc.jpg');
    Image::open('image/demo.gif')
        //->resize(1000, 1000)
        //->negate()
        ->save('output/d.gif','gif',10);
}
$obj = new service();
$obj->init();
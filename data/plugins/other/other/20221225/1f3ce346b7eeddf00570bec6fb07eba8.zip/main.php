<?php
require 'vendor/autoload.php';
require_once 'lib/File.php';

use think\facade\Db;
use think\Model;
## 定义常量
define('PLUGIN_PATH',__DIR__);
define('STATIC_FILE',__DIR__."/static");
define('PLUGIN_NAME','imgtool');
define('MAIN_DB',__DIR__."/../../data/default.db");
define('PLUGIN_DB',__DIR__."/imgtool.db");
define('DS','/');
function dump($data)
{
    if(is_array($data) == false){
        $new = [$data];
        echo json_encode($new);
        exit;
    }else{
        echo json_encode($data);
        exit;
    }
}
class main {
    public $mode = 0;
    public function __construct()
    {
        @ini_set('memory_limit','1024m');
        $database = include PLUGIN_PATH.'/config/database.php';
        Db::setConfig($database);
    }
    public function get_bt_db()
    {
        return Db::connect('bt_db');
    }
    function get_php_version(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80',
            "81"
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLUGIN_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            throw new Exception('请安装php>=7.1');
        }
        return $php_version;
    }
    function get_real_path(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLUGIN_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            throw new Exception('请安装php>=7.1');
        }
        $os = $this->get_os();
        if($os == 'linux'){
            $php_path = PLUGIN_PATH."/../../../php/$php_version/bin/php";
        }else{
            $php_path = PLUGIN_PATH."/../../../php/$php_version/php.exe";
        }

        return realpath($php_path);
    }
    function get_os(){
        $arr = array('WINNT', 'WIN32', 'WINDOWS');
        if ( in_array(strtoupper(PHP_OS), $arr) ) {
            $os = 'windows';
        }else{
            $os = 'linux';
        }
        return $os;
    }
    //获取json数据
    public function json($data){
        echo json_encode($data);
        exit;
    }
    protected function success($msg = '操作成功!',$data = null){
        if($this->mode == 1){
            echo $msg.PHP_EOL;
            return;
        }
        if( is_array($msg) || is_object($msg) ){
            $data = $msg;
            $msg = 'success';
        }
        $this->json([
            'code'=>0,
            'msg'=>$msg,
            'data'=>$data
        ]);
    }
    protected function msg($msg){
        echo $msg.PHP_EOL;
    }
    protected function error($msg,$code = 1){
        if($this->mode == 1){
            echo $msg.PHP_EOL;
            return;
        }
        $this->json([
            'code'=>$code,
            'msg'=>$msg,
        ]);
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLUGIN_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function add_log($param)
    {
        try {
            $param['create_time'] = date('Y-m-d H:i:s');
            LogModel::create($param);
        }catch (Exception $e){
            return $e->getMessage();
        }
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        $txt = file_get_contents(__DIR__.'/static/ms');
        if( $this->je() ){
            $this->error(base64_decode($txt),2);
        }
        if($sm<time() && $sm !== 0 ){
            $this->error(base64_decode($txt),2); exit;
        }
    }
    function je()
    {
        @$fl =  file_get_contents(__DIR__.'/../../config/config.json');
        $fl = json_decode($fl,true);
        $kx = file_get_contents(__DIR__.'/static/je.json');
        $kx = json_decode($kx,true);
        if($fl[base64_decode($kx['k'])] == base64_decode($kx['lv']) ){
            return true;
        }
        return false;
    }
    /**
     * [page description]  分页
     * @param  [type] $sum     [总页数]
     * @param  [type] $pagenum [页数]
     * @return [type]          [description]
     */
    function page($sum,$pagenum){
        $span = "";
        if($sum > 0){
            if($pagenum <=0){$pagenum = 1;}
            if($pagenum >= $sum){$pagenum = $sum;}

            $k = $pagenum-1 <= 0 ? 1:$pagenum-1;
            $m = $sum - 6 <= 0 ?1:$sum-6;
            $pageM = $pagenum == 1?$pagenum+2:$pagenum + 1;

            if($sum - $pagenum >= 6){
                for($i = $k; $i <= $pageM; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
                $span .= '<a class="Pnum"  >....</a>';
                for($i = $sum - 3; $i <= $sum; $i++){
                    $span .= '<a class="Pnum" onclick="get_table_log('.$i.')" >'.$i.'</a>';
                }
            }else{
                for($i = $m; $i <= $sum; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
            }
        }
        return $span;
    }
}
function is_debug()
{
    $file = __DIR__.'/.env';
    if(file_exists($file) ){
       return true;
    }
    return false;
}
class RuleModel extends  Model
{
    protected $name = 'rule';
}
class WebModel extends  Model
{
    protected $name = 'web';
}
class LogModel extends  Model
{
    protected $name = 'log';
    protected $autoWriteTimestamp = 'datetime';
}

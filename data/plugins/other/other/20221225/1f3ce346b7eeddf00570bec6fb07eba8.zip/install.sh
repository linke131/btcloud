#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/imgtool
plugin_name=网站图片自动压缩水印
is_copy_data='1'
#安装
Install()
{
  echo '================================================'
	echo '正在安装【'$plugin_name'】插件'
	echo "此插件依赖PHP7.1版本，请务必安装，不影响网站"
	echo "此插件支持PNG/JPEG/JPG/WEBP格式图片的压缩和水印"
	cd $install_path && rm -rf  *.ini .env
	touch $install_path"/static/sm"
  sleep 6s
	echo '================================================'
	bak_file=$install_path"/../../../imgtool.db"
	if [ -f $bak_file   ];then
	  if [ $is_copy_data == '1'   ];then
	    cp -p -f  $bak_file $install_path
    	echo '正在处理...';
    	sleep 1s
    	echo '正在处理......';
    	sleep 1s
    	echo '恢复上次运行数据完成';
      touch 'mark.txt';
    fi
	fi
	echo '================================================'
	echo '安装完成'
}
#卸载
Uninstall()
{
  cp -p -f  $install_path"/imgtool.db" $install_path"/../../../"
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
	sleep 1s
#	cp  /tmp/imgtool.db  install_path
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi

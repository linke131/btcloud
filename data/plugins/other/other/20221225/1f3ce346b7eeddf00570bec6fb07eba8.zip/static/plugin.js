//定义窗口尺寸
//$('.layui-layer-page').css({ 'width': '850px' });
setTimeout(function(){
    $('.layui-layer-page').width(1250).css({
        'top':(document.body.clientHeight-700)/2+'px',
        'left':(document.body.clientWidth-1250)/2+'px'
    })
},5);
//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});
//第一次打开窗口时调用
web_list();
function  get_index()
{
    var html = '';
    var tbody = '';
    request_plugin('rule_list',{},function (res){
        res.data.forEach(function (item) {
            console.log(item);
            tbody += "<tr>" +
                "<td>"+item.rule_name+"</td>" +
                "<td>"+item.dir+"</td>" +
                "<td>"+item.bak_dir+"</td>" +
                "<td>"+item.limit+"(kb)</td>" +
                "<td> <button onclick='show_edit_rule("+JSON.stringify(item)+")' class='btn btn-primary btn-sm'>编辑</button> <button onclick='del_rule("+item.id+")' class='btn btn-sm btn-danger'>删除</button> </td>" +
                "</tr>";
        })
        var html =
            "<div class='u_main'>" +
            "<p> <button onclick='show_edit_rule()' class='btn btn-success'>新增规则</button> </p>" +
            "<p>【待处理目录】与【备份目录】均是相对于站点目录设置的，比如www.a.com站点，【待处理目录】为 /zb_users/upload，那么真实的处理目录为 /wwwroot/www.a.com/zb_users/upload </p>" +
            "<table class='table table-hover waf_table'>" +
            "<thead><th>规则名称</th><th>待处理目录</th> <th>备份目录</th> <th>压缩条件</th> <th width='120'>操作栏</th></thead>" +
            "<tbody>"+
            tbody +
            "</tbody>" +
            "</table>"+
            "</div>";
        $('.plugin_body').html(html);
    })
}
function show_edit_rule(item = null)
{
    var content =   "<div id='app'  class='u_main'>" +
        "<form class='main_form'>" +
        "<input v-model='id'  type='hidden' name='id' value=''  class='bt-input-text'>" +
        "<p><label>规则名称<span class='red'>*</span></label>  <input v-model='rule_name'   placeholder='输入一个备注名称,用于区分' name='rule_name'  class='bt-input-text'></p>" +
        "<p><label>待处理目录<span class='red'>*</span></label>  <input v-model='dir'   placeholder='相对于网站根目录的路径,例如 /zb_users/upload' name='dir'  class='bt-input-text'></p>" +
        "<p><label></label>相对于站点目录的相对路径</p>" +
        "<p><label>限制宽</label> <input v-model='width'  value='800' placeholder='宽超出此数值，则设置宽为此数值'  name='width' class='bt-input-text'>" +
        "<p><label></label>当图片宽大于此值，则设定为该值，留空则不处理,（推荐800-1080）像素</p>" +
        "<p><label>限制高</label> <input v-model='height' value='800' placeholder='高超出此数值，则设置宽为此数值'  name='height' class='bt-input-text'>" +
        "<p><label></label>当图片高大于此值，则设定为该值，留空则不处理,（推荐800-1080）像素</p>" +
        "<p><label>备份目录<span class='red'>*</span></label> <input v-model='bak_dir' placeholder='备份原始文件的目录,为空则不备份' value='/bak' name='bak_dir' class='bt-input-text'>" +
        "<p><label></label>相对于站点目录的相对路径</p>" +
        "<p><label>压缩条件<span class='red'>*</span></label> <input v-model='limit' style='width: 200px!important;'  placeholder='文件压缩条件，大于该设置数值才会压缩' value='500' name='limit' class='bt-input-text'></p>" +
        "<p><label></label>文件压缩条件，大于该设置数值才会压缩，单位(kb)</p>" +
        "<p><label>压缩质量<span class='red'>*</span></label> <select v-model='rate' class='bt-input-text bt-select' name='rate'> " +
            "<option value='50'>50%(均衡压缩)</option> " +
            "<option value='90'>90%</option> " +
            "<option value='80'>80%</option> " +
            "<option value='75'>75%</option> " +
            "<option value='70'>70%</option> " +
            "<option value='60'>60%</option>  " +
            "<option value='40'>40%</option> " +
            "<option value='30'>30%</option> " +
            "<option value='20'>20%</option> " +
            "<option value='10'>10%</option> " +
        "</select>    </p>" +
        "<p><label>图片文字水印</label> <input v-model='watermark' placeholder='文字水印内容，不填则不加文字水印。支持中英文'   name='watermark' class='bt-input-text'></p>" +
        "<p><label>水印颜色</label> <input v-model='color' placeholder='文字水印颜色，例如  #d2d2d2 '   name='color' value='#d2d2d2' class='bt-input-text'> </p>" +
        "<p><label></label>  <a class='btlink' target='_blank' href='https://www.sojson.com/rgb.html'>颜色参考</a>，必须为此格式，例如灰色 #d2d2d2 ，如果您不懂直接填入此值即可。 </p>"+
        "<p><label>水印X轴偏移</label> <input v-model='x_set' placeholder='水印X轴偏移,即横向从左至右的偏移量比例，比例0.01-0.99'  value='0.03'  name='x_set' class='bt-input-text'> </p>" +
        "<p><label>水印Y轴偏移</label> <input  v-model='y_set' placeholder='水印Y轴偏移,即横向从左至右的偏移量比例，比例0.01-0.99'  value='0.05'  name='y_set' class='bt-input-text'> </p>" +
        "<p style='text-align: center'>   <button onclick='save_rule()'  class='btn btn-success btn-sm' >保存规则</button>  </p>" +
        "</form></div>";
    lotus_show('保存规则',content,700,750);
    if(item !== null){
        var app = new Vue({
            el: '#app',
            data: {
                id: item.id,
                rule_name: item.rule_name,
                dir:item.dir,
                limit:item.limit,
                bak_dir:item.bak_dir,
                rate:item.rate,
                width:item.width,
                height:item.height,
                image_type:item.image_type,
                watermark:item.watermark,
                color:item.color,
                x_set:item.x_set,
                y_set:item.y_set
            }
        })
        $("select[name=rate]").val(item.rate);
    }
}
// function show_add_rule()
// {
//     var content =   "<div class='u_main'>" +
//         "<form class='main_form'>" +
//         "<p><label>规则名称</label>  <input  placeholder='输入一个备注名称,用于区分' name='rule_name'  class='bt-input-text'></p>" +
//         "<p><label>待处理目录</label>  <input  placeholder='相对于网站根目录的路径,例如 /upload' name='dir'  class='bt-input-text'></p>" +
//         "<p><label>备份目录</label> <input value='/bak' placeholder='备份原始文件的目录,为空则不备份'  name='bak_dir' class='bt-input-text'>" +
//         "<p><label>压缩条件(kb)</label> <input style='width: 200px!important;'  placeholder='文件压缩条件，大于该设置数值才会压缩' value='500' name='limit' class='bt-input-text'></p>" +
//         "<p><label></label>文件压缩条件，大于该设置数值才会压缩,单位(kb)</p>" +
//         "<p><label>压缩率</label> <select class='bt-input-text bt-select' name='rate'> <option value='50'>50%(均衡压缩)</option>  <option value='90'>90%</option> <option value='80'>80%</option> <option value='75'>75%</option> <option value='70'>70%</option> <option value='60'>60%</option>  <option value='40'>40%</option> <option value='30'>30%</option> <option value='20'>20%</option> <option value='10'>10%</option> </select>    </p>" +
//         "<p style='text-align: center'>   <button onclick='save_rule()'  class='btn btn-success btn-sm' >保存规则</button>  </p>" +
//         "</form></div>";
//         lotus_show('新增规则',content,600,400);
// }
function show_size()
{
    var is_origin = $("select[name=is_origin]").val();
    if(is_origin == 2){
        $("#image_set").removeClass('hide');
    }
    if(is_origin == 1){
        $("#image_set").attr('class','hide');
    }
}
function save_rule()
{
    loading();
    sub_form('.main_form','save_rule',function (rdata) {
        if(rdata.code === 0){
            success(rdata.msg,function () {
                close_loading();
                get_index();
            });
        }else {
            close_loading();
            error(rdata.msg);
        }

    })
}
function del_rule(id)
{
    var param = {
        id:id
    }
     layer.confirm('确认删除？', {
        btn : ['确定', '取消']
    }, function() {
        request_plugin('del_rule',param,function (rdata) {
            if(rdata.code === 0){
                success(rdata.msg,get_index());
            }
        })
    });
}
//站点配置
function  web_list() {
    var tbody = '';
    check_init();
    get_plugin_info();
    request_plugin('web_list',{},function (res){
        res.data.forEach(function (item) {
            tbody += "<tr>" +
                "<td>"+item.name+"</td>" +
                "<td>"+item.rule_name+"</td>" +
                "<td>" +
                " <button onclick='show_add_web("+JSON.stringify(item)+")' class='btn btn-sm btn-primary'>编辑</button>" +
                " <button onclick='del_web("+item.id+")' class='btn btn-sm btn-danger'>删除</button>" +
                " </td>" +
                "</tr>";
        })
        var html =
            "<div class='u_main'>" +
            "<p> <button onclick='show_add_web()' class='btn btn-success'>新增配置</button> </p>" +
            "<table class='table table-hover waf_table'>" +
            "<thead><th>站点</th><th>规则名称</th> <th width='120'>操作栏</th></thead>" +
            "<tbody>"+
            tbody +
            "</tbody>" +
            "</table>"+
            "</div>";
        $('.plugin_body').html(html);
    })
}
function get_plugin_info() {
    bt.soft.get_soft_list(1, 10, title_name, function (rdata) {
        var info = rdata.list.data[0];
        request_plugin('get_plugin_info', info, function (res) {

        })
    })
}
function show_add_web(obj = null)
{
    request_plugin('show_add_web',{},function (rdata) {
        var sites_id = ''
        var rule_id = '';
        rdata.data.web.forEach(function (item) {
            sites_id += "<option value='"+item.id+"'>"+item.name+"</option>";
        })
        rdata.data.rule.forEach(function (item) {
            rule_id += "<option value='"+item.id+"'>"+item.rule_name+"</option>";
        })
        var content =   "<div class='u_main'>" +
            "<form class='main_form'>" +
            "<input name='id' type='hidden'>" +
            "<p><label>站点</label><select name='sites_id' class='bt-input-text'> "+sites_id+" </select></p>" +
            "<p><label>规则</label><select name='rule_id' class='bt-input-text'>"+rule_id+" </select></p>" +
            "<p style='text-align: center'>   <button onclick='add_web()' class='btn btn-success btn-sm' >保存规则</button>  </p>" +
            "</form></div>";
        lotus_show('保存配置',content,600,400);
        if(obj !== null){
            $("input[name=id]").val(obj.id);
            $("select[name=sites_id]").val(obj.sites_id);
            $("select[name=rule_id]").val(obj.rule_id);
        }
    })
}
function  add_web()
{
    sub_form('.main_form','add_web',function (rdata) {
        if(rdata.code === 1){
            error(rdata.msg);
        }
        if(rdata.code === 0){
            success(rdata.msg,function () {
                web_list();
            });
        }
    })
}
function del_web(id)
{
    var param = {
        id:id
    }
    layer.confirm('确认删除？', {
        btn : ['确定', '取消']
    }, function() {
        request_plugin('del_web',param,function (rdata) {
            if(rdata.code === 0){
                success(rdata.msg,web_list );
            }
        })
    });
}
function view_pic(obj)
{
    var src = $(obj).attr('data-src');
    var bak = $(obj).attr('data-bak');
    src_href = "<a class='btlink' href='/download?filename="+src+"'>"+src+"</a>";
    bak_href = "<a class='btlink' href='/download?filename="+bak+"'>"+bak+"</a>";
    lotus_show_pic('查看','<p>压缩后图片预览</p><img style="max-width: 740px;" src="/download?filename='+src+'"> <p></p>' +
        ' <p>压缩后文件位置: '+src_href+'</p><p>备份位置: '+bak_href+'</p>' +
        ' <p>* 备份文件为压缩前的原始文件备份</p> <p>* 路径点击即可下载查看</p>');
}
function rec(id)
{
    layer.confirm('恢复文件后，此文件不再进行压缩处理，确认恢复文件？', {
        btn : ['确定恢复', '取消']
    }, function() {
        request_plugin('rec',{id:id},function (rdata) {
            if(rdata.code === 0){
                success(rdata.msg,function () {
                    get_table_log();
                });
            }
        })
    });
}
function del_log(id)
{
    layer.confirm('删除日志后，此文件会重新进行压缩处理，确认删除日志？', {
        btn : ['确定删除', '取消']
    }, function() {
        request_plugin('del_log',{id:id},function (rdata) {
            if(rdata.code === 0){
                success(rdata.msg,function () {
                    get_table_log();
                });
            }
        })
    });
}
function remove_log()
{
    layer.confirm('清空日志后，大于【压缩条件】的图片会重新压缩，确定清空日志？', {
        btn : ['确认清空', '取消']
    }, function() {
        request_plugin('remove_log',{},function (rdata) {
            if(rdata.code === 0){
                success(rdata.msg,function () {
                    get_table_log();
                });
            }
        })
    });
}
function get_table_log(page = 1)
{
    var tbody = '';
    request_plugin('get_table_log',{page:page},function (res){
        res.data.page_data.forEach(function (item) {
            var status = item.status == 1?'<span class="success">已压缩</span>':'<span class="red">已恢复</span>';
            tbody += "<tr>" +
                "<td>"+item.create_time+"</td>" +
                "<td>"+item.title+"</td>" +
                "<td><span title='"+item.origin_file+"' class='short-text'>"+item.origin_file+"</span></td>" +
                "<td>"+item.old_size+"</td>" +
                "<td>"+item.new_size+"</td>" +
                "<td>"+item.percent+"</td>" +
                "<td>"+item.ext+"</td>" +
                "<td>"+status+"</td>" +
                // "<td>"+item.bak_file+"</td>" +
                "<td> <button class='btn btn-xs btn-success' data-bak='"+item.bak_file+"' onclick='view_pic(this)' data-src='"+item.origin_file+"'>查看</button>" +
                "<button onclick='rec("+item.id+")' class='btn btn-xs'>恢复</button> <button onclick='del_log("+item.id+")' class='btn btn-xs'>删除</button>  </td>" +
                "</tr>";
        })
        var html =
            "<div class='u_main'>" +
            "<p> <button onclick='rec_all()' class='btn btn-sm btn-primary'>时光机</button>  <button onclick='remove_log()' class='btn btn-sm btn-danger'>清空日志</button> </p>" +
            "<p>1、恢复后的文件不再参与压缩。2、如果您想重新压缩文件，请【删除】日志。3、【删除】只会删除记录，不会删除文件 " +
            // "4、建议安装php扩展【imagemagick】，实现更优的压缩" +
            "</p>" +
            "<table class='table table-hover waf_table'>" +
            "<thead>" +
            "<th width='160'>执行时间</th> " +
            "<th>站点</th>" +
            "<th>压缩后文件</th>" +
            "<th>原始大小</th>" +
            "<th>压缩后</th>" +
            "<th>压缩率</th>" +
            "<th>格式</th>" +
            "<th>状态</th>" +
            // " <th>备份路径</th>" +
            "<th width='150'>操作栏</th></thead>" +
            "<tbody>"+
            tbody +
            "</tbody>" +
            "</table>"+
            '</table> <div id="table_tfoot" class="page pull-right"> '+res.data.paginate+' </div> </div>' +
            "</div>";
        $('.plugin_body').html(html);
    })
}
function rec_all()
{
    layer.confirm('即将执行恢复全部图片？恢复后的图片不再参与压缩，如果想重新压缩，请【删除】或者【清空日志】', {
        btn : ['确认恢复', '取消']
    }, function() {
        loading_msg('恢复中。。。');
        request_plugin('rec_all',{},function (rdata) {
            close_loading();
            if(rdata.code === 0){
                success(rdata.msg,function () {
                    get_table_log();
                });
            }else{
                error(rdata.msg);
            }
        })
    });
}
function check_init() {
    request_plugin('test', {}, function (res) {
        if (res.status === false) {
            layer.alert(res.msg,{icon:2,time:0},function () {
                parent.location.reload();
            });
        }
    }, 'POST');
}
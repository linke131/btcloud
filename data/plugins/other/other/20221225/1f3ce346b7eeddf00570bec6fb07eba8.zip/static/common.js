var plugin_name = 'imgtool';
var title_name = 'imgtool';
//初始化全局变量
var timeout = 200*1000;
var err_icon = {
    icon: 2
}
var suc_icon = {
    icon: 1,
    time:1500
}
var load;
cron_title = "[网站图片自动压缩水印]插件守护任务(请勿删除)";
function  loading()
{
    load =  layer.load();
}
function  loading_msg(msg)
{
    load =  layer.msg(msg,{icon:16,time:0});
}
function close_loading()
{
    layer.close(load);
}
function  success(msg,callback,action = 1){
    layer.msg(msg,suc_icon,callback);
    if(action === 1){
        close_loading();
        setTimeout(function () {
            layer.close(layer_index);
        },800);
    }
}
function  error(msg){
    layer.msg(msg,err_icon);
}
/**
 * 发送请求到插件
 * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
 * @param function_name  要访问的方法名，如：get_logs
 * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"colscript.get_logs"}
 * @param callback       请传入处理函数，响应内容将传入到第一个参数中
 * @param method         请求方法
 */
function request_plugin(function_name, args, callback, method) {
    if (!method)  method = 'POST';
    $.ajax({
        type:method,
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        data: args,
        timeout: timeout,
        dataType:'json',
        success: function(rdata) {
            if (!callback) {
                layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                return;
            }
            if(rdata.code === 2){
                layer.msg(rdata.msg);
                return;
            }
            return callback(rdata);
        },
        error: function(ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    });
}
function sub_form(elem,function_name,callback,data) {
    if(!data) data = {};
    var options = {
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        type: 'post',
        dataType: "json",
        data: data,
        clearForm: false,
        resetForm: false,
        cache: false,
        async: false,
        success: function (data) {
            if (!callback) {
                layer.msg(data.msg, { icon: data.status ? 1 : 2 });
                return;
            }
            return callback(data);
        },
        error: function (ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    };
    // bind form using 'ajaxForm'
    $(elem).ajaxForm(options).submit(function (data) {
    });
}
function lotus_show(title,content,w = 600,h = 500)
{
    if (w == null || w == '') {
        var w = $(window).width() * 0.5;
    }
    if (h == null || h == '') {
        var h = $(window).height() - 300;
    }
    layer_index =  layer.open({
        title: title,
        type: 1,
        area: [w+'px',h+'px'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content:content
    },function () {
        
    });
}
function lotus_show_pic(title,content)
{
    layer_index =  layer.open({
        title: title,
        type: 1,
        area: ['auto'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content:content
    },function () {

    });
}
function service_status()
{
    //    cron_title = "【百度网盘自动备份】插件守护任务,请勿删除";
    var html = "<div class='u_main'>" +
        "<p style='line-height: 30px'> <label>状态</label>  <span class='status'></span>    </p>" +
        "<p style='line-height: 30px'><label>操作</label> <button onclick='add_sync_task()' class='btn  btn-success btn-sm'>[启动服务]添加定时守护任务</button>" +
        " &nbsp;<button onclick='start_cron()' class='btn  btn-normal btn-sm'>手动执行任务</button></p>" +
        "<p style='line-height: 30px'><label>查看任务</label> 添加的定时任务名为：<b>"+cron_title+"</b>，<a class='btlink' href='/crontab' target='_blank'>查看定时任务</a>  </p>" +
        "<p style='line-height: 30px'><label>任务说明</label> 默认创建的定时任务执行时间为每天凌晨 02:30执行，如果您想停止定时任务，可以删除此定时任务。 </p>" +
        "<p><label>插件PHP</label>当前插件使用的为php<span id='php_version'></span>版本" +
        // "，建议安装【imagemagick】扩展，提升图片压缩质量。" +
        "</p>" +
        "</div>";
    $('.plugin_body').html(html);
    get_service_status();
}
function start_cron()
{
    loading_msg('手动执行定时任务中，定时任务名称:'+cron_title);
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.id == null){
            layer.alert('请先添加定时任务!');
            return false;
        }
        $.post('/crontab?action=StartTask',{id:res.data.id},function (rdata) {
            close_loading();
            layer.msg(rdata.msg,{icon:1},function (rt) {
                $("#service_status").removeClass('bgw');
                $("#log_area").attr('class','bgw');
                get_table_log();
            });
        })
    })
}
function get_service_status()
{
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.status === 1){
            $('.status').html("<span class='play'><i style='color: #20a53a' class=\"fa fa-play \" aria-hidden=\"true\"></i></span>");
        }
        if(res.data.status === 0){
            $('.status').html(" <span class='stop'><i style='color: red' class=\"fa fa-stop \" aria-hidden=\"true\"></i></span>");
        }
        $("#php_version").html(res.data.php_version);
    })
}
function add_sync_task()
{
    request_plugin("add_sync_task",{cron_title:cron_title},function (res) {
        if(res.code === 0){
            var shell = res.data.shell;
            //存储域名
            var args = {
                "name":cron_title,
                "type":"day",
                "where1":"",
                "hour":2,
                "minute":30,
                "week":"",
                "sType": "toShell",
                "sBody": shell,
                "sName":"",
                "backupTo": "localhost",
                "save":"",
                "urladdress":""
            };
            $.ajax({
                type:'POST',
                url: '/crontab?action=AddCrontab',
                data: args,
                success: function(rdata) {
                    console.log(rdata);
                    success(res.msg,get_service_status );
                    //get_service_status();
                },
                error: function(ex) {
                    //layer.msg('请求过程发现错误!', { icon: 2 });
                }
            });
        }else{
            error(res.msg);
        }
    },'get');
}
function about() {
    var html =
        "                <div id=\"404_dev\" >\n" +
        "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>技术支持群：<a target=\"_blank\" href=\"//shang.qq.com/wpa/qunwpa?idkey=289eaf4dfef0cc9220256b90ff502bef467767f6f790b817ce1cbe7658b5b3b3\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"PHP-LotusAdmin&amp;宝塔插件反\" title=\"PHP-LotusAdmin&amp;宝塔插件反\"></a></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>使用说明,务必查看:</b></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>1、插件依赖PHP71，不影响网站设置</td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>2、目前支持png、jpg、jpeg，webp主流图片格式。</td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>3、新增站点配置后，在【服务状态】中【添加定时守护任务】，即可【手动执行任务】。</td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>4、对于未知的网站程序，可自行添加【优化规则】，完成【站点配置】。</td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>5、插件会自动压缩符合压缩条件的图片，替换原始图片并备份，如想恢复，请点击【时光机】按钮。</td></tr>\n" +


        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td id='msg'>欢迎使用插件,觉得好的话给个好评哦!</td></tr>\n" +

        "                    </table>\n" +
        "                </div>\n" +
        "                </div>";
    $('.plugin_body').html(html);
    request_plugin('about',{},function (res) {
        var msg = res.msg;
        if(msg == null){
            msg = "欢迎使用插件,觉得好的话给个好评哦!";
        }
        $("#msg").html(msg);
    })
}
function check_init() {
    request_plugin('test',{},function (res) {
        if(res.status === false){
            layer.alert(res.msg,{icon:2,time:0},function () {
                parent.location.reload();
            });
        }
    },'POST');
}
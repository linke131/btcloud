function validatePhone (str) {
  // !(/^1[3-9]{1}[0-9]{9}$/.test(value)
  const reg = /^1[3456789][0-9]\d{8}$/
  return reg.test(str)
}

function validateEmail (str) {
  const reg = /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/g
  return reg.test(str.trim())
}

const baseUrl = 'https://opensca.xmirror.cn/osvi'
function request (url, args = {}, callback=null) {
  layer.closeAll('loading')
  layer.load(1, {
    shade: [0.1,'#fff'],
    zIndex: 19991032 
  });
  $.ajax({
    type:'POST',
    url: baseUrl + url,
    dataType: 'json',
    async:true,
    headers: {
      "Authorization": $.cookie('osvulintelligence_anthtoken') ? 'Bearer ' + $.cookie('osvulintelligence_anthtoken') : undefined,//自定义请求头
      "Content-Type": "application/json;charset=utf8"
    },
    data: JSON.stringify(args),
    success: function(rdata) {
      layer.closeAll('loading')
      if (rdata.code === 401) {
        const indexConfirm = layer.confirm('登录凭证失效，需要重新登录！', {
          icon: 3,
          title: '提示',
          skin: 'layui-layer-xmirror', 
          zIndex: 19991019,
        }, function(){
          layer.close(indexConfirm)
          Index.logout()
        }, function(){
          layer.close(indexConfirm)
        });
      }else if (callback) {
        callback(rdata)
      }
    },
    error: function(ex) {
      layer.closeAll('loading')
      console.log('ex', ex)
      if (ex.status === 401) {
        const indexConfirm = layer.confirm('登录凭证失效，需要重新登录！', {
          icon: 3,
          title: '提示',
          skin: 'layui-layer-xmirror', 
          zIndex: 19991019,
        }, function(){
          layer.close(indexConfirm)
          Index.logout()
        }, function(){
          layer.close(indexConfirm)
        });
      }else {
        layer.msg('请求过程发现错误!', { icon: 2 });
      }
    },
    complete: function() {
      layer.closeAll('loading')
    },
  });
}

function encrypto (plainText) {
  const CRYPTO_SECRET = '0hzrweqzz8j4w9c0'
  const CRYPTO_IV = '903kxes7xagg2igg'
  const key = CryptoJS.enc.Utf8.parse(CRYPTO_SECRET)
  const iv = CryptoJS.enc.Utf8.parse(CRYPTO_IV)
  const plain = CryptoJS.enc.Utf8.parse(plainText)
  const encrypted = CryptoJS.AES.encrypt(plain, key, {
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
    iv
  })
  return encrypted.toString()
}

#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: magicyou <magicyou@163.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发DEMO
#+--------------------------------------------------------------------
import sys,os,json
import requests

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class xsharkrasp_main:
    __plugin_path = "/www/server/panel/plugin/xsharkrasp/"
    __config = None

    #构造方法
    def  __init__(self):
        pass

    #访问/demo/index.html时调用的方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self,args):
        return self.get_logs(args)


    #获取面板日志列表
    #传统方式访问get_logs方法：/plugin?action=a&name=demo&s=get_logs
    #使用动态路由模板输出： /demo/get_logs.html
    #使用动态路由输出JSON： /demo/get_logs.json
    def test(self,args):
        headers = {
              'accept': 'application/json',
          }
        response = requests.post('https://192.168.172.194/cms/api/Advertisement/getAdvertisement?position=1', headers=headers, json={})
        return {
            'data': response,
        }
        # #处理前端传过来的参数
        # if not 'p' in args: args.p = 1
        # if not 'rows' in args: args.rows = 12
        # if not 'callback' in args: args.callback = ''
        # args.p = int(args.p)
        # args.rows = int(args.rows)

        # #取日志总行数
        # count = public.M('logs').count()

        # #获取分页数据
        # page_data = public.get_page(count,args.p,args.rows,args.callback)

        # #获取当前页的数据列表
        # log_list = public.M('logs').order('id desc').limit(page_data['shift'] + ',' + page_data['row']).field('id,type,log,addtime').select()
        
        # #返回数据到前端
        # return {'data': log_list,'page':page_data['page'] }
        
  
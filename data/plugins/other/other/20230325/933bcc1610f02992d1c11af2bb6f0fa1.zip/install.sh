#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/lotusweblog
plugin_name=熊猫网站日志分析
#安装
Install()
{
	echo '正在安装【'$plugin_name'】插件...'
	echo '插件依赖PHP 7.1，请务必安装下，不影响站点设置'
  echo '如长期使用，请务必在【高级配置】中启用【Mysql存储】'
  echo '插件安装后，可刷新几次此插件主页，加速数据初始化过程'
  echo '更新2.7版本，需要重新配置一个纯净数据库。'
	cd $install_path && rm -rf  *.ini && rm -rf .git
	sleep 5
	echo '================================================'
	echo '安装完成'
	sleep 2
	echo  '如果遇到任何问题请联系开发者QQ 610176732，插件会持续迭代优化，再次感谢亲们的支持与理解！认真做插件，其他的交给你们！'
	sleep 3
	echo  '祝大家新年快乐，财源广进，新年新气象！！！'
	sleep 6
	cp -p  /tmp/extra.php $install_path"/config/"
}

#卸载
Uninstall()
{
  cp -p $install_path"/config/extra.php" /tmp
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi

<?php   
return [
    'default'=>'plugin_db',
    'hostname'=>'127.0.0.1',
    'database'=>'weblog',
    'username'=>'weblog',
    'password'=>'',
    'hostport'=>'3306',
    'type'     => 'mysql',
    'charset'  => 'utf8'
]  ?>;
<?php
require_once 'vendor/autoload.php';
use Workerman\Connection\TcpConnection;
use Workerman\Worker;
use think\facade\Db;
use Workerman\Timer;
require 'main.php';

$db_config = include 'config/database.php';
Db::setConfig($db_config);
$worker = new Worker('websocket://0.0.0.0:8080');
//$worker->onConnect = function(TcpConnection $connection)
//{
//    echo "new connection from ip " . $connection->getRemoteIp() . "\n";
//};
//$worker->onMessage = function (TcpConnection $connection, $data) use($db_config)
//{
//    $one = Db::name('access_log')
//        ->whereTime('time_local','>',time()-5 )
//        ->find();
//    $connection->send(json_encode($one));
//};
$worker->onWorkerStart = function($worker){
    Timer::add(3, function()use($worker){
        $webs = Db::name('web')->select();
        foreach ($webs as $web){
            $path = $web['path'];
        }
        foreach($worker->connections as $connection) {
            $connection->send(222);
        }
    });
};
// 运行worker
Worker::runAll();
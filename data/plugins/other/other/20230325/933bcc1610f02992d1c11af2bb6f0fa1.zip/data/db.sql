SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `access_log`;
CREATE TABLE `access_log`  (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `host` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `remote_addr` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `remote_user` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `time_local` int(11) NULL DEFAULT NULL,
                               `request` varchar(330) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `status` int(6) DEFAULT NULL,
                               `body_bytes_sent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `http_user_agent` varchar(330) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `http_referer` varchar(330) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `ua_type` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `http_x_forwarded_for` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `url` varchar(330) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `protocol` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `method` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `location` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

DROP TABLE IF EXISTS `bot`;
CREATE TABLE `bot`  (
                        `id` int(11) NOT NULL AUTO_INCREMENT,
                        `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `alias` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

DROP TABLE IF EXISTS `web`;
CREATE TABLE `web`  (
                        `id` int(11) NOT NULL AUTO_INCREMENT,
                        `host` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `path` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `log_path` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `error_log_path` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `create_time` int(11) NULL DEFAULT NULL,
                        PRIMARY KEY (`id`) USING BTREE,
                        UNIQUE INDEX `web_id_uindex`(`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;


INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (1, 'Baiduspider', '百度');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (2, 'bingbot', '必应');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (3, 'YisouSpider', '神马');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (4, '360Spider', '360搜索');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (5, 'PetalBot', '华为搜索');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (6, 'Googlebot', '谷歌');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (7, 'Applebot', 'Applebot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (8, 'SemrushBot', 'SemrushBot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (9, 'YandexBot', 'YandexBot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (10, 'AhrefsBot', 'AhrefsBot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (11, 'Sogou web spider', '搜狗');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (12, 'Bytespider', '头条');


-- ----------------------------
-- Table structure for conf
-- ----------------------------
DROP TABLE IF EXISTS `conf`;
CREATE TABLE `conf`  (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                         `val` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                         PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of conf
-- ----------------------------
INSERT INTO `conf` VALUES (1, 'ip_list', null);

ALTER TABLE `web`
    ADD INDEX `idx_host`(`host`) USING BTREE;

ALTER TABLE `access_log`
    ADD INDEX `idx_host`(`host`, `time_local`, `url`) USING BTREE;

ALTER TABLE `access_log`
    ADD INDEX `idx_request` (`host`,`request`,`time_local`) USING BTREE;

ALTER TABLE `access_log`
    ADD INDEX `idx_type` (`ua_type`,`host`,`time_local`,`url`) USING BTREE;

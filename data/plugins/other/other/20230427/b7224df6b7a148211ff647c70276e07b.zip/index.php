<?php
//百度网站备份
//@author 旧雨楼<610176732@qq.com>
require 'main.php';
use OpenAPI\Client\Api\AuthApi;
use OpenAPI\Client\ApiException;
use think\facade\Db;
use lib\Time;
use lib\File;
use think\Exception;

/**
 * Class bt_main
 * Notes:
 * Auther: wenhainan
 * Email: whndeweilai@gmail.com
 * @property $post
 * DateTime: 2022/9/7
 */
class bt_main extends main {
    public function post()
    {
        return _post();
    }
    public function get()
    {
        return _get();
    }
    public function login()
    {
        $res = $this->oauth();
        $this->success('',$res);
    }
    public function device_auth()
    {
        try {
            $param = $this->post();
            $info = $this->cache->get('auth');
            if($info !== false && !empty($info) ){
                $this->success('授权成功',$info);
            }
            $res =  $this->getAuthInfo($param['device_code']);
            if(!empty($res)){
                $this->cache->set('auth',$res,$res['expires_in']);
                $this->success('授权成功',$res);
            }
        }catch (Exception $e){
            $this->error( $e->getMessage() );
        }
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLUGIN_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function  userinfo()
    {
        $apiInstance = new OpenAPI\Client\Api\UserinfoApi(
            new GuzzleHttp\Client(['verify'=>false])
        );
        $access_token = $this->access_token();
        $result['info'] = $apiInstance->xpannasuinfo($access_token);
        $result['quota']  =  $apiInstance->Apiquota($access_token);
        $file = new File();
        $result['quota']['total'] = $file->getRealSize($result['quota']['total']);
        $result['quota']['used'] = $file->getRealSize($result['quota']['used']);
        $this->success('success',$result);
    }
    function  upload_file()
    {
        try{
            $param = $this->post();
            if(empty($param['file_name']) && !is_dir($param['file_name']) ){
                throw new Exception('请选择文件');
            }
            $path = $param['path'].DS.$param['file_name'];
            $filename = $param['file_name'];
            //$filename = $this->get_filename($path);
            $target_path = APP_NAME.DS.$filename;
            //分片
            $da =  $this->fen($path);
            $api = new OpenAPI\Client\Api\FileuploadApi($this->client);
                $all_size = filesize($path);
                $block_list = json_encode($da['block_list']);
                $res = $api->Xpanfileprecreate($this->access_token(),$target_path,0,$all_size,1,$block_list);
                foreach ($da['file_list'] as $k => $v){
                    $api->Pcssuperfile2($this->access_token(),(string)$k,$target_path,$res['uploadid'],'tmpfile',$v);
                    @unlink($v);
                }
                $data =  $api->Xpanfilecreate($this->access_token(),$target_path,0,$all_size,$res['uploadid'],$block_list);
                @rmdir(RUNTIME_PATH.DS.$da['name']);
                @unlink(RUNTIME_PATH.DS.$da['name'].'.txt');
                $this->success('上传成功',$data);
        }catch (ApiException $e){
            $this->error($e->getMessage());
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    function  get_file_list()
    {
        $path = $this->post()['path'];
        $dir = $this->GetDirsInDir($path,false);
        $this->success($dir);
    }
    function  logout()
    {
        $info = $this->cache->delete('auth');
        $this->success('注销成功！');
    }
    function  get_web()
    {
        $web =  $this->get_bt_db()->name('sites')->field('id,name,path,project_type')->select()->toArray();
        foreach ($web as &$item){
            $item['is_check'] = 0;
            $res =  Db::name('web')
                ->where('sites_id',$item['id'])
                ->where('name',$item['name'])
                ->find();
            if(!empty($res)){
                $item['is_check'] = 1;
            }
        }
        $this->success($web);
    }
    function database_index()
    {
        $database = $this->get_bt_db()->name('databases')
            ->where('db_type',0)
            ->field('id,name,ps')
            ->select()
            ->toArray();
        foreach ($database as &$item){
            if($item['ps'] == '填写备注'){
                $item['ps'] = '-';
            }
            $item['is_check'] = 0;
            $res =  Db::name('database')
                ->where('databases_id',$item['id'])
                ->where('name',$item['name'])->find();
            if(!empty($res)){
                $item['is_check'] = 1;
            }
        }
        $this->success('success',[
            'database'=>$database,
            'port'=> $this->config('port'),
            'mysql_root'=> $this->config('mysql_root')
        ]);
    }
    function  add_database(){
        $param = $this->post();
        $msg = "success";
        $info =  $this->get_bt_db()->name('databases')->find($param['id']);
        $res =  Db::name('database')->where('name',$info['name'])->find();
        if($param['is_check'] == 1 && empty($res) ){
            $data = [
                'databases_id'=>$info['id'],
                'name'=>$info['name'],
                'db_type'=>$info['db_type'],
                'ps'=>$info['ps'],
                'create_time'=>Time::nowdate()
            ];
            Db::name('database')->insert($data);
            $msg = "自动备份<span class='success'>【已启用】</span>";
        }else{
            Db::name('database')->where('databases_id',$param['id'])->delete();
            $msg = "自动备份<span class='red'>【已关闭】</span>";
        }
        $this->success($msg);
    }
    function  add_web(){
        $param = $this->post();
        $bt_db = $this->get_bt_db();
        $msg = "success";
        $sites_info = $bt_db->name('sites')->find($param['id']);
        $res =  Db::name('web')->where('name',$sites_info['name'])->find();
        if($param['is_check'] == 1 && empty($res) ){
            $web = [
                'sites_id'=>$sites_info['id'],
                'name'=>$sites_info['name'],
                'path'=>$sites_info['path'],
                'create_time'=>Time::nowdate()
            ];
            Db::name('web')->insert($web);
            $msg = "自动备份<span class='success'>【已启用】</span>";
        }else{
            Db::name('web')->where('sites_id',$param['id'])->delete();
            $msg = "自动备份<span class='red'>【已关闭】</span>";
        }
        $this->success($msg);
    }
    function  get_log()
    {
        $log = LogModel::order('create_time desc')->select();
        $this->success($log);
    }
    function  remove_log()
    {
        LogModel::where('id','>',0)->delete();
        $this->success('清除成功');
    }
    function add_sync_task(){
        $param = $this->get();
        $path = $this->get_real_path();
        $version = $this->get_php_version();
        $str =  "  -c ".PLUGIN_PATH.DS."php_cli_".$version.'.ini ';
        $shell = $path." ".$str.PLUGIN_PATH.DS."service.php";
        //判断是否存在定时任务
        $res =  $this->get_bt_db()->table('crontab')->where('name',$param['cron_title'])->find();
        if(!empty($res)){
            $this->error('已经存在定时任务!');
        }
        $this->success('定时任务添加成功，服务启动，默认执行时间为每天凌晨02:30',[
            'shell'=>$shell
        ]);
    }
    function  get_service_status()
    {
        $param = $this->post();
        $res =  $this->get_bt_db()->table('crontab')->where('name',$param['cron_title'])
            ->where('status',1)
            ->find();
//        if(!empty($res)){
//            $this->error('已经存在定时任务!');
//        }
        $this->success([
            'status'=> !empty($res)?1:0
        ]);
    }
    function  get_dir()
    {
        $dir = Db::name('dir')->select();
        $this->success($dir);
    }
    function add_dir()
    {
        try {
            $param = $this->post();
            if(empty($param['path'])){
                throw new Exception('文件夹不能为空');
            }
            if(!is_dir($param['path'])){
                throw new Exception('非法文件夹');
            }
            $res = Db::name('dir')->where('path',$param['path'])->find();
            if(!empty($res)){
                throw new Exception('请勿重复添加文件夹');
            }
            Db::name('dir')
                ->insert([
                    'path'=>$param['path'],
                    'create_time'=>Time::nowdate()
                ]);
            $this->success('新增文件夹配置成功');
        }catch (Exception $e){
            $this->error( $e->getMessage() );
        }
    }
    function on_dir()
    {
        $param = $this->post();
        $dir =  DirModel::where('id',$param['id'])->find();
        $dir->is_check = $param['is_check'];
        $msg = $param['is_check'] == 1 ? "自动备份<span class='success'>【已启用】</span>":"自动备份<span class='danger'>【已关闭】</span>";
        $dir->save();
        $this->success($msg);
    }
    function del_dir()
    {
        $param = $this->post();
        Db::name('dir')->delete($param['id']);
        $this->success('配置删除成功');
    }
    function file_data()
    {
        $api = new OpenAPI\Client\Api\FileinfoApi($this->client);
        $file_data = $api->Xpanfilelist($this->access_token(),'/apps/百度网盘备份');
        $this->success('获取成功',json_decode($file_data,true));
    }
//    function get_info(){
//        $sm =  file_get_contents(__DIR__.'/static/sm');
//        $sm = intval($sm);
//        if($sm<time() && $sm !== 0 ){
//            $txt = file_get_contents(__DIR__.'/static/ms');
//            $this->error(base64_decode($txt),2);
//        }
//    }
    function get_plugin_info(){
        $params = $this->post();
        $v = $params['endtime'];
        $file = __DIR__.'/static/sm';
        @chmod($file,0777);
        file_put_contents($file,$v);
        $this->success();
    }
    function download_info()
    {
        $param = $this->post();
        $api = new OpenAPI\Client\Api\MultimediafileApi($this->client);
        $arr = json_encode([
            intval($param['fs_id'])
        ]);
        $info =  $api->Xpanmultimediafilemetas($this->access_token(),$arr,null,null,1);
        $info = json_decode($info,true);
        $this->success([
            'dlink'=>$info['list'][0]['dlink'],
            'access_token'=>$this->access_token()
        ]);
    }
    function test()
    {
        $this->success();
    }
    function save_part()
    {
        $param = $this->post();
        if(empty($param['port'])){
            $this->error('请输入有效值！');
        }
        $this->config('port',$param['port']);

        $this->success('保存成功');
    }
    function save_mysql_root()
    {
        $param = $this->post();
        if( empty($param['mysql_root']) || empty($param['port']) ){
            $this->error('请输入有效值！');
        }
        $username = 'root';
        $password = $param['mysql_root'];
        try {
            $conn = new mysqli('127.0.0.1', $username, $password,null,$param['port']);
            if(!$conn){
                //throw new Exception('错误:数据库配置信息错误，请核对！');
                $this->error('错误:数据库配置信息错误，请核对！');
            }
            $this->config('mysql_root',$param['mysql_root']);
            $this->config('port',$param['port']);

            $this->success('保存成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }

    }
}
?>
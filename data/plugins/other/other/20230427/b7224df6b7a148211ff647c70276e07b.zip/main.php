<?php
require_once 'vendor/autoload.php';
require_once('openxpanapi/vendor/autoload.php');
require_once 'FileCache.php';
require_once 'lib/File.php';
require_once 'lib/Time.php';
require_once 'lib/ZipClass.php';

## 定义常量
define('PLUGIN_PATH',__DIR__);
define('STATIC_FILE',__DIR__.DIRECTORY_SEPARATOR."static");
define('PLUGIN_NAME','netdisk');
define('MAIN_DB',__DIR__."/../../data/default.db");
define('PLUGIN_DB',__DIR__.DIRECTORY_SEPARATOR."netdisk.db");
define('BASE_URL',"https://pan.baidu.com");
define('APP_NAME','/apps/百度网盘自动备份');
define('DS',DIRECTORY_SEPARATOR);
define('RUNTIME_PATH',__DIR__.DIRECTORY_SEPARATOR.'runtime');
define('FILE_TMP_PATH',RUNTIME_PATH.'/file_tmp');
use OpenAPI\Client\Api\AuthApi;
use think\facade\Db;
use think\Model;
class main {
    public $config;
    public $cache;
    public $access_token;
    public $client;
    public $mode = 0;
    public function __construct()
    {
        $this->config = include 'config/config.php';
        $this->cache = FileCache::getInstance();
        $this->client = new GuzzleHttp\Client(['verify'=>false]);
        $database = include PLUGIN_PATH.'/config/database.php';
        @ini_set('memory_limit', '512M');
        Db::setConfig($database);
    }
    public function get_bt_db()
    {
        return Db::connect('bt_db');
    }
    function folderSize($directory){
        $total_size = 0;
        $dir_array = scandir($directory);
        foreach($dir_array as $key=>$file){
            if($file === '.' || $file === '..'){
                continue;
            }
            if(is_dir($directory . '/' . $file)){
                $total_size += $this->folderSize($directory . '/' . $file);
            }else{
                $total_size += filesize($directory . '/' . $file);
            }
        }
        return $total_size;
    }
    function get_php_version(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80',
            "81"
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLUGIN_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            throw new Exception('请安装php>=7.1');
        }
        return $php_version;
    }
    function get_real_path(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLUGIN_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            throw new Exception('请安装php>=7.1');
        }
        $os = $this->get_os();
        if($os == 'linux'){
            $php_path = PLUGIN_PATH."/../../../php/$php_version/bin/php";
        }else{
            $php_path = PLUGIN_PATH."/../../../php/$php_version/php.exe";
        }

        return realpath($php_path);
    }
    function get_os(){
        $arr = array('WINNT', 'WIN32', 'WINDOWS');
        if ( in_array(strtoupper(PHP_OS), $arr) ) {
            $os = 'windows';
        }else{
            $os = 'linux';
        }
        return $os;
    }
    //获取json数据
    public function json($data){
        echo json_encode($data);
        exit;
    }
    protected function success($msg = 'success',$data = null){
        if($this->mode == 1){
            echo $msg.PHP_EOL;
            return;
        }
        if( is_array($msg) || is_object($msg) ){
            $data = $msg;
            $msg = 'success';
        }
        $this->json([
            'code'=>0,
            'msg'=>$msg,
            'data'=>$data
        ]);
    }
    protected function msg($msg){
        echo $msg.PHP_EOL;
    }
    protected function error($msg,$code = 1){
        if($this->mode == 1){
            echo $msg.PHP_EOL;
            return;
        }
        $this->json([
            'code'=>$code,
            'msg'=>$msg,
        ]);
    }

    public function oauth()
    {
        try {
            $clien_id = base64_decode($this->config['baidu']['client_id']);
            $url = "https://openapi.baidu.com/oauth/2.0/device/code?response_type=device_code&client_id=$clien_id&scope=basic,netdisk";
            $data =  $this->geturl($url);
            return $data;
        }catch (Exception $e){
            return $e->getMessage();
        }
    }
    public function getAuthInfo($device_code)
    {
        $clien_id = base64_decode($this->config['baidu']['client_id']);
        $client_secret = base64_decode($this->config['baidu']['client_secret']);
        $url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=device_token&code=$device_code&client_id=$clien_id&client_secret=$client_secret";
        $data =  $this->geturl($url);
        if(isset($data['error'])){
            throw new Exception($data['error']);
        }
        return $data;
    }
    public function getUserinfo()
    {
        $url = BASE_URL."/rest/2.0/xpan/nas?";
        $url .= http_build_query([
            'method'=>'uinfo',
            'access_token'=>$this->access_token()
        ]);
        $data =  $this->geturl($url);
        if(isset($data['error'])){
            throw new Exception($data['error']);
        }

        return $data;
    }
    public function access_token()
    {
        $auth = $this->cache->get('auth');
        if($auth == false){
           throw new Exception('未授权');
        }
        return $auth['access_token'];
    }
    function geturl($url){
        $headerArray =array("Content-type:application/json;","Accept:application/json");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
        $output = curl_exec($ch);
        curl_close($ch);
        $output = json_decode($output,true);
        return $output;
    }
    function send_post($url, $post_data) {
        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);

        return json_decode($result,true);
    }
    function  get_filename($path)
    {
        $pathinfo = pathinfo($path);
        return $pathinfo['basename'];
    }

    function fen($filePath)
    {
        $data = [];
        $path = __DIR__.'/runtime/file_tmp/';
        if(!file_exists($path)){
            @mkdir($path,0755,true);
        }
        $dir = md5($filePath);
        //$txt = md5($filePath).'.txt';
        @mkdir($path.$dir);
        //@file_put_contents($path.$txt,'');
        $fileName = $this->get_filename($filePath);
        $i    = 0;                              //分割的块编号
        $fp   = fopen($filePath,"rb");     	 	//要分割的文件
        //$text_file = fopen($path.$txt,"a"); //记录分割的信息的文本文件路径，实际生产环境存在redis更合适
        while(!feof($fp)){
            $tmpFile = $path . "{$dir}/{$fileName}.{$i}"; // 切割后的文件存储完整路径，包含文件名
            $handle = fopen($tmpFile,"wb");
            fwrite($handle,fread($fp,1024*1024*4));//切割的块大小 5M（1024*1024*5=5242880）
            // fwrite($handle,fread($fp,5000000));//切割的块大小
            // fwrite($text_file,"{$tmpFile}\r\n");
            fclose($handle);
            unset($handle);
            $i++;
            $data['file_list'][]  = $tmpFile;
            $data['block_list'][] = md5_file($tmpFile);
        }
        $data['name'] = md5($filePath);
        fclose ($fp);
        //fclose ($text_file);
        return $data;
    }

    /**
     * 获取目录下文件夹列表(递归).
     *
     * @param string $dir 目录
     *
     * @return array 文件夹列表(递归函数返回的是路径的全称，和非递归返回的有区别)
     */
    function GetDirsInDir_Recursive($dir)
    {
        $dirs = array();

        if (!file_exists($dir)) {
            return array();
        }
        if (!is_dir($dir)) {
            return array();
        }
        $dir = str_replace('\\', '/', $dir);
        if (substr($dir, -1) !== '/') {
            $dir .= '/';
        }

        if (function_exists('scandir')) {
            foreach (scandir($dir, 0) as $d) {
                if (is_dir($dir . $d)) {
                    if (($d != '.') && ($d != '..')) {
                        $array = GetDirsInDir($dir . $d);
                        if (count($array) > 0) {
                            foreach ($array as $key => $value) {
                                $dirs[] = $dir . $d . '/' . $value;
                            }
                        }
                        $dirs[] = $dir . $d;
                    }
                }
            }
        } else {
            $handle = opendir($dir);
            if ($handle) {
                while (false !== ($file = readdir($handle))) {
                    if ($file != "." && $file != "..") {
                        if (is_dir($dir . $file)) {
                            $array = GetDirsInDir($dir . $file);  //此方法在下面，请往下看
                            if (count($array) > 0) {
                                foreach ($array as $key => $value) {
                                    $dirs[] = $dir . $file . '/' . $value;
                                }
                            }
                            $dirs[] = $dir . $file;
                        }
                    }
                }
                closedir($handle);
            }
        }

        return $dirs;
    }

    /**
     * 获取当前目录下文件夹列表.
     *
     * @param string $dir 目录
     *
     * @return array 文件夹列表
     */
    function GetDirsInDir($dir,$contain_dir = true)
    {
        $dirs = array();

        if (!file_exists($dir)) {
            return array();
        }
        if (!is_dir($dir)) {
            return array();
        }
        $dir = str_replace('\\', '/', $dir);
        if (substr($dir, -1) !== '/') {
            $dir .= '/';
        }
        // 此处的scandir虽然是PHP 5就已加入的内容，但必须加上兼容处理
        // 部分一键安装包的早期版本对其进行了禁用
        // 这一禁用对安全没有任何帮助，推测是早期互联网流传下来的“安全秘笈”。
        // @see: https://github.com/licess/lnmp/commit/bd34d5c803308afdac61626018e4168716d089ae#diff-6282e7667da1e2fc683bed06f87f74c1
        if (function_exists('scandir')) {
            foreach (scandir($dir, 0) as $d) {
                if($contain_dir){
                    if (is_dir($dir . $d)) {
                        if ( ($d != '.') && ($d != '..') ) {
                            $dirs[] = $d;
                        }
                    }
                }else{
                    if (is_file($dir . $d)) {
                        if ( ($d != '.') && ($d != '..') ) {
                            $dirs[] = $d;
                        }
                    }
                }
            }
        } else {
            $handle = opendir($dir);
            if ($handle) {
                while (false !== ($file = readdir($handle))) {
                    if($contain_dir){
                        if ($file != "." && $file != "..") {
                            if (is_dir($dir . $file)) {
                                $dirs[] = $file;
                            }
                        }
                    }else{
                        if ($file != "." && $file != "..") {
                            if (is_file($dir . $file)) {
                                $dirs[] = $file;
                            }
                        }
                    }
                }
                closedir($handle);
            }
        }

        return $dirs;
    }
    function  log($title,$content = '成功')
    {
        $log = new LogModel();
        $data = [
            'title'=>$title,
            'content'=>$content
        ];
        $log->data($data)->save();
    }
    /**
     * [page description]  分页
     * @param  [type] $sum     [总页数]
     * @param  [type] $pagenum [页数]
     * @return [type]          [description]
     */
    function page($sum,$pagenum){
        $span = "";
        if($sum > 0){
            if($pagenum <=0){$pagenum = 1;}
            if($pagenum >= $sum){$pagenum = $sum;}

            $k = $pagenum-1 <= 0 ? 1:$pagenum-1;
            $m = $sum - 6 <= 0 ?1:$sum-6;
            $pageM = $pagenum == 1?$pagenum+2:$pagenum + 1;

            if($sum - $pagenum >= 6){
                for($i = $k; $i <= $pageM; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
                $span .= '<a class="Pnum"  >....</a>';
                for($i = $sum - 3; $i <= $sum; $i++){
                    $span .= '<a class="Pnum" onclick="get_table_log('.$i.')" >'.$i.'</a>';
                }
            }else{
                for($i = $m; $i <= $sum; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
            }
        }
        return $span;
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        $txt = file_get_contents(__DIR__.'/static/ms');
        if( $sm<time() && $sm !== 0 ){
            $this->msg(base64_decode($txt));exit;
        }
        if( $this->je() ){
            $this->msg(base64_decode($txt));exit;
        }
    }
    function je()
    {
        @$fl =  file_get_contents(__DIR__.'/../../config/config.json');
        $fl = json_decode($fl,true);
        $kx = file_get_contents(__DIR__.'/static/je.json');
        $kx = json_decode($kx,true);
        if($fl[base64_decode($kx['k'])] == base64_decode($kx['lv']) ){
            return true;
        }
        return false;
    }
    function config($key,$val = null)
    {
        if(empty($val)){
            return ConfModel::where('key',$key)->value('val');
        }
        return ConfModel::where('key',$key)->update([
            'val'=>$val
        ]);
    }
    function delDir($directory){

        if(file_exists($directory)){//判断目录是否存在，如果不存在rmdir()函数会出错

            if($dir_handle=@opendir($directory)){//打开目录返回目录资源，并判断是否成功

                while($filename=readdir($dir_handle)){//遍历目录，读出目录中的文件或文件夹

                    if($filename!='.' && $filename!='..'){//一定要排除两个特殊的目录

                        $subFile=$directory."/".$filename;//将目录下的文件与当前目录相连

                        if(is_dir($subFile)){//如果是目录条件则成了

                            $this->delDir($subFile);//递归调用自己删除子目录

                        }

                        if(is_file($subFile)){//如果是文件条件则成立

                            unlink($subFile);//直接删除这个文件

                        }

                    }

                }

                closedir($dir_handle);//关闭目录资源

                rmdir($directory);//删除空目录

            }

        }

    }
    function  del_runtime_files(){
        $list = scandir(RUNTIME_PATH);
        foreach($list as $item){
            if(is_dir($item)){
                continue;
            }
            $ext =  pathinfo($item,PATHINFO_EXTENSION);
            if($ext == 'zip'|| $ext == 'sql'){
                $file = RUNTIME_PATH.DIRECTORY_SEPARATOR.$item;
                unlink($file);
            }
        }
        exit;
    }
    function deleteAllFilesAndDirs($directory){
        $files = glob($directory . '/*');
        foreach($files as $file){
            if(is_file($file)){
                unlink($file);
            }else{
                $this->deleteAllFilesAndDirs($file);
                rmdir($file);
            }
        }
    }
}
class WebModel extends Model {
    protected $name = 'web';
    protected $autoWriteTimestamp = 'datetime';
}
class LogModel extends Model {
    protected $name = 'log';
    protected $autoWriteTimestamp = 'datetime';
}
class DirModel extends Model {
    protected $name = 'dir';
    protected $autoWriteTimestamp = 'datetime';
}
class ConfModel extends Model {
    protected $name = 'conf';
    protected $autoWriteTimestamp = 'datetime';
}

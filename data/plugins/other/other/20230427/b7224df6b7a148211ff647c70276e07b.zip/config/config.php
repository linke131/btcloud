<?php

return [
    'baidu'=>[
        'client_id'=>'TndieFF2eElaaDBsTG4wYWl2bFU0YXM4S010ZXdZOWs=',
        'client_secret'=>'WnVVaXZQemhCSG5oekNDdkNyZjNJY1kyUnpHWTRXYk4='
    ]
];
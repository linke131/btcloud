#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/netdisk
#安装
Install()
{
  echo '================================================'
	echo '正在安装...'
	echo "安装完成后需要手动安装依赖PHP7.1版本，请务必安装,并需解除exec函数"
	cd $install_path && rm -rf  *.ini
	rm -rf $install_path"/runtime/fa"
	rm -rf $install_path"/.git"
  sleep 5s
	echo '================================================'
	echo '安装完成'
}
#卸载
Uninstall()
{
  cp -p $install_path"/netdisk.db" /tmp
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
#	sleep 1s
#	cp  /tmp/netdisk.db  $install_path
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi

<?php
require_once 'main.php';
use OpenAPI\Client\Api\AuthApi;
use OpenAPI\Client\ApiException;
use think\facade\Db;
use think\Exception;

class  service extends  main {
    function  __construct()
    {
        parent::__construct();
        $this->mode = 1;
    }
    function  init()
    {
        $is_login = $this->cache->get('auth');
        if(empty($is_login)){
            $this->msg('未扫码登录百度云盘账号，请务必扫码登录');exit;
        }
        $this->bak_web();
        $this->bak_dir();
        $this->bak_db();
    }
    function bak_db(){
        try {
            $this->msg('开始备份数据库...');
            $db_pa = $this->get_bt_db()->name('databases')
                ->column('name');
            $db_arr = Db::name('database')
                ->whereIn('name',$db_pa)
                ->select();
            if($db_arr->isEmpty()){
                throw new Exception('没有配置自动备份的【数据库】');
            }
            //$password = $this->get_bt_db()->name('config')->value('mysql_root');
            $password = $this->config('mysql_root');
            $port = $this->config('port');
            if(empty($password) || empty($port) ){
                $this->msg("您需要在插件内同步下数据库root密码才能数据库执行同步。");
                exit;
            }
            foreach ($db_arr as $item){
                $username = 'root';
                $db_name = $item['name'];
                $name = $db_name.'_'.date('YmdHis').'.sql';
                $save_file_path = RUNTIME_PATH.DS.$name;
                $conn = new mysqli('127.0.0.1', $username, $password,null,$port);
                if($conn->connect_error){
                    $this->msg("错误:数据库配置信息错误，请同步正确的Mysql root密码和端口");
                    exit;
                }
                $shell = <<<EOF
mysqldump -R -E --hex-blob --opt --force --set-gtid-purged=off  --default-character-set=utf8mb4  -P{$port}  -u{$username}  -p{$password} {$db_name} > {$save_file_path}
EOF;
                $version = $this->get_php_version();
                if(!function_exists('exec')){
                    $this->msg("错误:PHP{$version}版本的函数exec需要解禁");
                }
                exec($shell,$output,$status);
                if($status !== 0){
                    //throw new Exception("数据库【{$db_name}】备份失败");
                    $this->msg("数据库【{$db_name}】备份失败");
                }
                if($status == 0){
                    $this->upload_file($save_file_path);
                    $this->log('备份数据库',"上传{$name}成功");
                    @unlink($save_file_path);
                }
            }
        }catch (Exception $e){
            $this->msg($e->getMessage());
        }
    }
    function bak_web()
    {
        try {
            $this->get_info();
            $this->msg('开始备份网站...');
            $web_arr = Db::name('web')
                ->whereNotNull('name')
                ->select();
            if($web_arr->isEmpty()){
                throw new Exception('没有配置自动备份的【网站】');
            }
            $zip_class = new ZipClass();
            foreach ($web_arr as $web){
                $bt_web = $this->get_bt_db()->table('sites')
                    ->where('id', $web['sites_id'])
                    ->find();
                $web['path'] = $bt_web['path'];
                if(empty($bt_web)){
                    Db::table('web')->where('sites_id',$web['sites_id'])->delete();
                    continue;
                }
                if(!file_exists($web['path'])){
                    //throw new Exception('非法路径，跳过');
                    $this->msg("检测到错误的路径{$web['path']}，跳过此目录。");
                    continue;
                }
                $this->msg('准备上传'.$web['name']);
                $name = $web['name'].'_'.date('YmdHis').'.zip';
                $zip_tmp_file = RUNTIME_PATH.DS.$name;
                file_put_contents($zip_tmp_file,'');
                $res =  $zip_class->zip($zip_tmp_file,$web['path']);
                if($res){
                    $this->upload_file($zip_tmp_file);
                    $this->log('备份网站',"上传{$name}成功");
                    @unlink($zip_tmp_file);
                }
            }
        }catch (Exception $e){
            $this->msg($e->getMessage());
        }
    }
    function bak_dir()
    {
        try {
            $this->msg('开始备份自定义文件夹...');
            $dir_arr = Db::name('dir')->where('is_check',1)->select();
            if($dir_arr->isEmpty()){
                throw new Exception('没有配置自动备份的【自定义文件夹】');
            }
            $zip_class = new ZipClass();
            foreach ($dir_arr as $dir){
                if(!file_exists($dir['path']) || !is_dir($dir['path']) ){
                    //throw new Exception('非法路径，跳过');
                    $this->msg('非法路径'.$dir['path'].'，跳过');
                    continue;
                }
                $dir['name'] =  basename($dir['path']);
                $this->msg('准备压缩上传文件夹:'.$dir['name']);
                $name = $dir['name'].'_'.date('YmdHis').'.zip';
                $zip_tmp_file = RUNTIME_PATH.DS.$name;
                file_put_contents($zip_tmp_file,'');
                $res =  $zip_class->zip($zip_tmp_file,$dir['path']);
                if($res){
                    $this->upload_file($zip_tmp_file);
                    $this->log('备份网站',"上传{$name}成功");
                    @unlink($zip_tmp_file);
                }
            }
        }catch (Exception $e){
            $this->msg($e->getMessage());
        }
    }
    function  upload_file($path)
    {
        try{
            if(empty($path) && !is_dir($path) ){
                throw new Exception('异常文件，跳过');
            }
            $filename = $this->get_filename($path);
            $target_path = APP_NAME.DS.$filename;
            //分片
            $da =  $this->fen($path);
            $api = new OpenAPI\Client\Api\FileuploadApi($this->client);
            $all_size = filesize($path);
            $block_list = json_encode($da['block_list']);
            $res = $api->Xpanfileprecreate($this->access_token(),$target_path,0,$all_size,1,$block_list);
            foreach ($da['file_list'] as $k => $v){
                $api->Pcssuperfile2($this->access_token(),(string)$k,$target_path,$res['uploadid'],'tmpfile',$v);
                @unlink($v);
            }
            $data =  $api->Xpanfilecreate($this->access_token(),$target_path,0,$all_size,$res['uploadid'],$block_list);
            @rmdir(RUNTIME_PATH.DS.'file_tmp/'.$da['name']);
            //@unlink(RUNTIME_PATH.DS.'file_tmp/'.$da['name'].'.txt');
            $this->success('上传'.$path.'成功');
        }catch (ApiException $e){
            $this->error($e->getMessage());
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    function __destruct(){
        $this->deleteAllFilesAndDirs(FILE_TMP_PATH);
        $this->del_runtime_files();
    }
}
(new service())->init();
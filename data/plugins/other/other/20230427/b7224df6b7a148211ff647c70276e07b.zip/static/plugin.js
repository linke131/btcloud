//定义窗口尺寸
//$('.layui-layer-page').css({ 'width': '850px' });
setTimeout(function(){
    $('.layui-layer-page').width(850).css({
        'top':(document.body.clientHeight-650)/2+'px',
        'left':(document.body.clientWidth-850)/2+'px'
    })
},5);

//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});

//第一次打开窗口时调用
get_index();
var timer;
var plugin_name = 'netdisk';
var timeout = 60*1000;
var err_icon = {
    icon: 2
}
var suc_icon = {
    icon: 1,
    time:2000
}
var load;
var baidu_url = "https://pan.baidu.com/disk/main?from=oldversion#/index?category=all&path=%2Fapps%2F%E7%99%BE%E5%BA%A6%E7%BD%91%E7%9B%98%E8%87%AA%E5%8A%A8%E5%A4%87%E4%BB%BD";
cron_title = "【百度网盘自动备份】插件守护任务(勿删)";
var title_name = "百度网盘自动备份";
//站点配置
function  get_index() {
    check_init();
    get_plugin_info();
    var html = '<p>小提示:</p><p>1、加载用户信息中...</p><p>2、插件依赖PHP7.1，请务必安装且需解禁exec函数</p>';
    $('.plugin_body').html(html);
    setTimeout(getToken,50);
}
function getToken()
{
    var device_code = $("input[name=device_code]").val();
    var param = {
        'device_code':device_code
    }
    loading();
    request_plugin('device_auth',param,function (res) {
        if(res.code === 0){
            userinfo();
            // layer.msg(get_msg(res.msg),{icon:1,time:300},function () {
            //     //clearInterval(timer);
            //     setTimeout(userinfo(),'100');
            // })
        }else{
            request_plugin('login',{},function (res){
                close_loading();
                var html =
                    "<div class='u_main'>" +
                    "<p>第一步:用百度网盘app扫码进行用户授权</p>" +
                    "<div > <img id='qrcode' width='300px'> </div>" +
                    "<p>第二步:完成上步后，点击下面按钮进行设备授权</p>" +
                    "<button  class='btn btn-success' onclick='getToken()'>设备授权</button>" +
                    "<input type='hidden' name='device_code'>" +
                    "</div>";
                $('.plugin_body').html(html);
                $("#qrcode").attr('src',res.data.qrcode_url);
                $("input[name=device_code]").val(res.data.device_code);
                // timer =  setInterval(getToken(),6000);
            })
            //error(get_msg(res.msg));
        }
    })
}
//站点配置
function  userinfo() {
    var html =
        "<div class='u_main'>" +
        "<p><label>文件路径</label> <input type='text' class='bt-input-text' name='path'> </p>" +
        "<p><label></label><button class='btn btn-success'>提交</button></p>" +
        "</div>";
    loading('加载用户信息中...');
    request_plugin('userinfo',{},function (res){
        close_loading();
        var info = res.data.info;
        console.log(info);
        var quota = res.data.quota;
        var vip_type = '普通用户【4G以内】';
        switch (info.vip_type){
            case  1:
                vip_type  = '<a class="btlink">普通会员【8G以内】</a>';
                break;
            case  2:
                vip_type =    '<a class="btlink">超级会员【20G以内】</a>';
        }
        var html =
            "<div class='u_main'>" +
            "<p><label>网盘账号：</label>"+info.netdisk_name+" <button onclick='logout()' class='btn btn-success btn-xs'>切换账号</button> </p>" +
            "<p><label>百度帐号：</label>"+info.baidu_name+"</p>" +
            "<p><label>会员等级：</label>"+vip_type+"</p>" +
            "<p><label>容量：</label>"+quota.total+"/已用"+quota.used+"</p>" +
            "<p><label>插件目录：</label> <a href='"+baidu_url+"' class='btlink' target='_blank'>网页端【百度网盘自动备份】空间，您可以在此处查看与下载</a> </p>" +
            "<p><label></label> <img src="+info.avatar_url+"></p>" +
            //"<p><label></label> <button onclick='logout()' class='btn btn-success btn-sm'>切换账号</button> </p>" +
            "</div>";
        $('.plugin_body').html(html);
    })
}
function get_plugin_info()
{
    bt.soft.get_soft_list(1,10,title_name,function (rdata) {
        var info = rdata.list.data[0];
        request_plugin('get_plugin_info',info,function (res) {

        })
    })
}
function  file_upload(){
    var html = "<p class='u_main'>" +
        "<p><label>上级文件夹</label> " +
        '<input onchange="get_file_list()" name="path" value="D:\\backup\\site" class="sl300 bt-input-text mr5 server_path dir" placeholder="支持文件夹/文件，文件需要输入具体路径" required="required">' +
        '<span data-id="folder" class="glyphicon cursor mr5 glyphicon-folder-open" onclick="bt.select_path(\'server_path\')"></span>'+
        "&nbsp;&nbsp;   </p>" +
        "<p><label>选择文件</label> <select class='bt-input-text bt-select' name='file_name'> </select>  <button class='btn btn-success btn-sm' onclick='get_file_list()'>刷新文件列表</button>  </p>" +
        "<p><label></label> <button class='btn btn-success btn-sm' onclick='upload_file()'>上传服务器</button>  进度 <span id=\"progress\">0%</span>  </p>" +
        "</div>";
    $('.plugin_body').html(html);
    get_file_list();
}
function get_file_list(){
    var param = {
        'path':$("input[name=path]").val()
    }
    request_plugin('get_file_list',param,function (rdata) {
        var op = '<option value="">请选择文件</option>';
        rdata.data.forEach(function (item) {
            op += "<option>"+item+"</option>";
        })
        $("select[name=file_name]").html(op);
    })
}
function upload_file()
{
    var path = $("input[name=path]").val();
    var param = {
        path:path,
        'file_name':$("select[name=file_name]").val()
    }
    loading();
    timeout = 60*1000*60;
    request_plugin('upload_file',param,function (rdata) {
        close_loading();
        if(rdata.code === 0){
            success(rdata.msg);
            // layer.alert(rdata.msg,{icon:1},function () {
            //     window.open(baidu_url);
            // })
        }else{
            error(rdata.msg);
        }
    })
}
function web_index()
{
    var html = "<div class='u_main'>  " +
        "<table class='table table-hover waf_table fixed-table'> <thead> <tr>" +
        " <th >网站</th> " +
        "<th >路径</th>  " +
        "<th >站点类型</th>  " +
        " <th style='text-align: center;' >批量自动备份【启用/关闭】</th>  " +
        "</tr> </thead> " +
        "<tbody id='web'>" +
        "</tbody>" +
        "</table>" +
        " </div>"
    $('.plugin_body').html(html);
    request_plugin('get_web',{},function (rdata) {
        var str = '';
        rdata.data.forEach(function (item) {
            var is_check = "";
            if(item.is_check === 1){
                is_check = 'checked';
            }
            str +=  "<tr>" +
                "<td>"+item.name+"</td>" +
                "<td>"+item.path+"</td>" +
                "<td>"+item.project_type+"</td>" +
                "<td style='text-align: center;'> <span><input id='is_check_"+item.id+"' onclick='add_web("+item.id+")' class='bs_switch'  "+is_check+" type='checkbox'>  </span> </td>" +
            "</tr>"
        })
        $("#web").html(str);
    })
}
function add_web(id)
{
    var is_check = $("#is_check_"+id).is(":checked");
    var param = {
        id:id,
        is_check:is_check? 1: 0
    }
    request_plugin('add_web',param,function (rdata) {
        success(rdata.msg);
    })
}
function database_index(){
    var html = "<div class='u_main'>  " +
        "<p><label>数据库端口</label> <input name='port'  class='input-sm' value='3306'>" +
        "<label>root密码</label> <input  type='password' name='mysql_root' placeholder='请输入mysql的root密码' class='input-sm' value=''> <button onclick='save_mysql_root()' class='btn btn-success btn-sm'>同步</button> </p>" +
        "<p><label></label>需要同步端口和mysql root密码才能执行数据库上传与备份。<a href='/database' target='_blank' class='btlink'>    数据库信息</a></p>" +
        "<table class='table table-hover waf_table fixed-table'> <thead> <tr>" +
        "<th>数据库</th> " +
        "<th>备注</th>  " +
        " <th style='text-align: center;' >批量自动备份【启用/关闭】</th>  " +
        "</tr> </thead> " +
        "<tbody id='web'>" +
        "</tbody>" +
        "</table>" +
        " </div>"
    $('.plugin_body').html(html);
    request_plugin('database_index',{},function (rdata) {
        var str = '';
        rdata.data.database.forEach(function (item) {
            var is_check = "";
            if(item.is_check === 1){
                is_check = 'checked';
            }
            str +=  "<tr>" +
                "<td>"+item.name+"</td>" +
                "<td>"+item.ps+"</td>" +
                "<td style='text-align: center;'> <span><input id='is_check_"+item.id+"' onclick='add_database("+item.id+")' class='bs_switch'  "+is_check+" type='checkbox'>  </span> </td>" +
                "</tr>"
        })
        $("#web").html(str);
        $("input[name=port]").val(rdata.data.port);
        $("input[name=mysql_root]").val(rdata.data.mysql_root);
    })
    //获取端口
}
function save_part()
{
    var param = {
        'port':$("input[name=port]").val()
    }
    request_plugin('save_part',param,function (rdata) {
        if(rdata.code === 0 ){
            success(rdata.msg);
        }else{
            error(rdata.msg);
        }
    })
}
function save_mysql_root()
{
    var param = {
        'port':$("input[name=port]").val(),
        'mysql_root':$("input[name=mysql_root]").val()
    }
    request_plugin('save_mysql_root',param,function (rdata) {
        if(!rdata.hasOwnProperty('code') ){
            error('信息错误，请核查！');
            return;
        }
        if(rdata.code === 0 ){
            success(rdata.msg);
        }else{
            error(rdata.msg);
        }
    })
}
function isJSON(str) {
    if (typeof str == 'string') {
        try {
            var obj=JSON.parse(str);
            if(typeof obj == 'object' && obj ){
                return true;
            }else{
                return false;
            }

        } catch(e) {
            console.log('error：'+str+'!!!'+e);
            return false;
        }
    }
    console.log('It is not a string!')
}
function add_database(id)
{
    var is_check = $("#is_check_"+id).is(":checked");
    var param = {
        id:id,
        is_check:is_check? 1: 0
    }
    request_plugin('add_database',param,function (rdata) {
        success(rdata.msg);
    })
}
function service_status()
{
    //    cron_title = "【百度网盘自动备份】插件守护任务,请勿删除";
    var html = "<div class='u_main'>" +
        "<p style='line-height: 30px'> <label>状态</label>  <span class='status'></span>    </p>" +
        "<p style='line-height: 30px'><label>操作</label> <button onclick='add_sync_task()' class='btn  btn-sm'>添加定时守护任务(启动服务)</button>  </p>" +
        "<p style='line-height: 30px'><label>查看任务</label> 添加的定时任务名为:"+cron_title+"，<a class='btlink' href='/crontab' target='_blank'>查看任务</a>  </p>" +
        "<p style='line-height: 30px'><label>任务说明</label> 默认创建的定时任务执行时间为每天凌晨 02:30执行 </p>" +
        "</div>";
    $('.plugin_body').html(html);
    get_service_status();
}
function get_service_status()
{
    request_plugin("get_service_status",{cron_title:cron_title},function (res) {
        if(res.data.status === 1){
            $('.status').html("<span class='play'><i style='color: #20a53a' class=\"fa fa-play \" aria-hidden=\"true\"></i></span>");
        }
        if(res.data.status === 0){
            $('.status').html(" <span class='stop'><i style='color: red' class=\"fa fa-stop \" aria-hidden=\"true\"></i></span>");
        }
    })
}
function add_sync_task()
{
    request_plugin("add_sync_task",{cron_title:cron_title},function (res) {
        if(res.code === 0){
            var shell = res.data.shell;
            //存储域名
            var args = {
                "name":cron_title,
                "type":"day",
                "where1":"",
                "hour":2,
                "minute":30,
                "week":"",
                "sType": "toShell",
                "sBody": shell,
                "sName":"",
                "backupTo": "localhost",
                "save":"",
                "urladdress":""
            };
            $.ajax({
                type:'POST',
                url: '/crontab?action=AddCrontab',
                data: args,
                success: function(rdata) {
                    console.log(rdata);
                    success(res.msg,get_service_status );
                    //get_service_status();
                },
                error: function(ex) {
                    //layer.msg('请求过程发现错误!', { icon: 2 });
                }
            });
        }else{
            error(res.msg);
        }
    },'get');
}
function show_log()
{
    var html = "<div class='u_main'>" +
        "<p><b>日志记录</b></p>" +
        "<p>备份上传的文件，您可以在此处查看与下载，<a href='"+baidu_url+"' class='btlink' target='_blank'>网页端【百度网盘自动备份】空间</a> </p>" +
        "<p><button class='btn btn-danger btn-sm' onclick='remove_log()'>清空记录</button></p>" +
        "<div class='log_content'></div>" +
        " </div>"
    $('.plugin_body').html(html);
    loading();
    request_plugin('get_log',{},function (rdata) {
        close_loading();
        var log_content = "";
        rdata.data.forEach(function (item) {
            log_content += "<p>执行时间："+item.create_time+" | 事件："+item.content+"</p>";
        })
        $(".log_content").html(log_content);
    })
}
function remove_log()
{
    var  load1 =  layer.confirm('是否情况日志？', {
        btn : ['确定', '取消']
    }, function() {
        request_plugin('remove_log',{},function (rdata) {
            if(rdata.code === 0 ){
                layer.close(load1);
                success(rdata.msg,show_log())
            }
        });
    });
}
function logout()
{
    var  load1 =  layer.confirm('是否注销？', {
        btn : ['确定', '取消']
    }, function() {
        request_plugin('logout',{},function (rdata) {
                if(rdata.code === 0 ){
                    layer.close(load1);
                    get_index();
                }
        });
    });
}
function upload_log()
{
    var html = '上传日志';
    $('.plugin_body').html(html);
}
function  loading_msg(msg  = '加载中...')
{
    load =  layer.msg(msg,{icon:16,time:15*1000 });
}
function  loading()
{
    load =  layer.load();
}
function close_loading()
{
    layer.close(load);
}
function  get_msg(str)
{
    if(str === "authorization_pending"){
        return '请先扫码授权';
    }
    //slow_down
    if(str === "slow_down"){
        return '刷新太频繁';
    }
    return str;
}
function  success(msg,callback){
    layer.msg(msg,suc_icon,callback);
}
function  error(msg){
    layer.msg(msg,err_icon);
}
/**
 * 发送请求到插件
 * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
 * @param function_name  要访问的方法名，如：get_logs
 * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"colscript.get_logs"}
 * @param callback       请传入处理函数，响应内容将传入到第一个参数中
 * @param method         请求方法
 */
function request_plugin(function_name, args, callback, method) {
    var plugin_name = 'netdisk';
    if (!method)  method = 'POST';
    $.ajax({
        type:method,
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        data: args,
        timeout: timeout,
        dataType:'json',
        success: function(rdata) {
            if (!callback) {
                layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                return;
            }
            if(rdata.code === 2){
                layer.msg(rdata.msg);
                return;
            }
            return callback(rdata);
        },
        error: function(ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    });
}
function check_init() {
    request_plugin('test',{},function (res) {
        if(res.status === false){
            layer.alert(res.msg,{icon:2,time:0},function () {
                parent.location.reload();
            });
        }
    },'POST');
}
function sub_form(elem,function_name,callback,data) {
    if(!data) data = {};
    var options = {
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        type: 'post',
        dataType: "json",
        data: data,
        clearForm: false,
        resetForm: false,
        cache: false,
        async: false,
        success: function (data) {
            if (!callback) {
                layer.msg(data.msg, { icon: data.status ? 1 : 2 });
                return;
            }
            return callback(data);
        },
        error: function (ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    };
    // bind form using 'ajaxForm'
    $(elem).ajaxForm(options).submit(function (data) {
    });
}


function about() {
    var html =
        "  <div  id=\"404_logo\" align=\"center\"></div><br/>\n" +
        "                <div class='u_main' id=\"404_dev\" >\n" +
        "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>开发人员： 旧雨楼</td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>QQ群支持：<a target=\"_blank\" href=\"https://qm.qq.com/cgi-bin/qm/qr?k=o2aZ8w3bZVpu9RsFfuGG_qFFV64Y5Szg&jump_from=webapi\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"旧雨楼-宝塔技术支持\" title=\"旧雨楼-宝塔技术支持\"></a></td></tr>" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td> <a class='btlink' target='_blank' href='https://www.bt.cn/?invite_code=MV9heHlhemM='>领取宝塔优惠券</a> </td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>使用说明,务必查看:</b></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>1、插件依赖PHP7.1，不影响网站设置</td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>2、php7.1的exec函数需要解除禁用，插件版本>=1.2的无需配置。</td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>3、数据库支持Mysql数据库同步，插件内需要同步端口和root密码。<a onclick='show_img(this)' data-src='/netdisk/static/image/r1.png'  class='btlink'>如何查看root密码？</a></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>4、极少windows版本默认未配置mysql环境变量，需要手动配置下。<a onclick='show_img(this)' data-src='/netdisk/static/image/win.png' class='btlink'>win如何配置Mysql环境变量？</a></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +



        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td id='msg'>欢迎使用插件，觉得好的话给个好评哦!</td></tr>\n" +

        "                    </table>\n" +
        "                </div>\n" +
        "                </div>";

    $('.plugin_body').html(html);
    request_plugin('about',{},function (res) {
        var msg = res.msg;
        $("#msg").html(msg);
    })
}
function dir_index()
{
    var html = "<div class='u_main'>  " +
        "<p><label>文件夹</label> <input  name=\"path\"  class=\"sl300 bt-input-text mr5 server_path dir\" placeholder=\"支持文件夹/文件，文件需要输入具体路径\" required=\"required\"><span data-id=\"folder\" class=\"glyphicon cursor mr5 glyphicon-folder-open\" onclick=\"bt.select_path('server_path')\"></span>&nbsp;&nbsp;   " +
        "<button onclick='add_dir()' class='btn btn-success btn-sm'>增加</button></p>"+
        "<table class='table table-hover waf_table fixed-table'> <thead> <tr>" +
        "<th >文件夹</th>  " +
        "<th >创建时间</th>  " +
        " <th style='text-align: center;' >批量自动备份【启用/关闭】</th>  " +
        "<th>操作</th>  " +
        "</tr> </thead> " +
        "<tbody id='web'>" +
        "</tbody>" +
        "</table>" +
        " </div>"
    $('.plugin_body').html(html);
    request_plugin('get_dir',{},function (rdata) {
        var str = '';
        rdata.data.forEach(function (item) {
            var is_check = "";
            if(item.is_check == 1){
                is_check = 'checked';
            }
            str +=  "<tr>" +
                "<td>"+item.path+"</td>" +
                "<td>"+item.create_time+"</td>" +
                "<td style='text-align: center;'> <span><input id='is_check_"+item.id+"' onclick='on_dir("+item.id+")' class='bs_switch'  "+is_check+" type='checkbox'>  </span> </td>" +
                "<td> <button onclick='del_dir("+item.id+")' class='btn btn-sm btn-danger'>删除</button> </td>" +
                "</tr>"
        })
        $("#web").html(str);
    })
}
function add_dir()
{
    var path = $("input[name=path]").val();
    var param = {
        path:path
    }
    request_plugin('add_dir',param,function (rdata) {
        if(rdata.code === 0){
            success(rdata.msg,dir_index);
        }else{
            error(rdata.msg);
        }
    })
}
function on_dir(id)
{
    var is_check = $("#is_check_"+id).is(":checked");
    var param = {
        id:id,
        is_check:is_check? 1: 0
    }
    request_plugin('on_dir',param,function (rdata) {
        success(rdata.msg);
    })
}
function del_dir(id)
{
    var param = {
        id:id
    }
    var  load1 =  layer.confirm('确认删除？', {
        btn : ['确定', '取消']
    }, function() {
        request_plugin('del_dir',param,function (rdata) {
            if(rdata.code === 0){
                layer.close(load1);
                success(rdata.msg,dir_index());
            }
        })
    });
}
function file_data()
{
    var html = "<div class='u_main'>" +
        "<p>百度网盘 / 我的应用数据 / <a target='_blank'class='btlink' href="+baidu_url+">百度网盘自动备份(查看更多)</a></p>" +
        "<table class='table table-hover waf_table fixed-table'> <thead> <tr>" +
        "<th>文件名</th>" +
        "<th >创建时间</th>" +
        "<th>操作</th>" +
        "</tr> </thead>" +
        "<tbody id='file_data'>" +
        "</tbody>" +
        "</table>" +
        " </div>"
    $('.plugin_body').html(html);
    loading();
    request_plugin('file_data',{},function (rdata) {
        close_loading();
        var str = '';
        rdata.data.list.forEach(function (item) {
            str += "<tr>" +
                "<td>"+item.server_filename+"</td>" +
                "<td>"+moment(item.server_ctime*1000).format('YYYY-MM-DD H:m:s')+"</td>" +
                "<td><button onclick='download_info("+item.fs_id+")' class='btn btn-sm'>下载</button>  </td>" +
                "</tr>";
        })
        $("#file_data").html(str);
    })
}

function download_info(fs_id)
{
    request_plugin('download_info',{fs_id:fs_id},function (rdata) {
        var url = rdata.data.dlink+"&access_token="+rdata.data.access_token;
        layer.alert("<a href='"+url+"'>点击下载</a>");
        // $.ajax({
        //     url: dlink,
        //     data: {},
        //     type: "GET",
        //     beforeSend: function(xhr){xhr.setRequestHeader('User-Agent', 'pan.baidu.com');},//这里设置header
        //     success: function() {
        //         location.href = dlink;
        //     }
        // });
    })
}

function show_img(obj)
{
    var src  = $(obj).attr('data-src');
    layer.open({
        type: 1,
        title: false,
        closeBtn: 1,
        area: ['auto','auto'],
        // skin: 'layui-layer-nobg', //没有背景色
        shadeClose: true,
        content: "<img src='"+src+"'>"
    });
}
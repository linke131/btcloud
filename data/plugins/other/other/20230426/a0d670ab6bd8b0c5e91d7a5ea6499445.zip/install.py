import panelTask

panelPath = os.getenv('BT_PANEL')
panelPath = panelPath if panelPath else "/www/server/panel"
os.chdir(panelPath) #切换工作目录


pluginPath=panelPath+"/plugin/btgitea"
panelPath=os.path.abspath(panelPath+'/../')
corePath = panelPath+"/btgitea/"
logPath = corePath+"log/gitea_service.log"
baklogPath = corePath+"log/gitea_service_bak.log"

def install():  
    panelTask.bt_task()._unzip(pluginPath+"/core.zip",  corePath, '', logPath)


def update():
    install()

def uninstall():
    shutil.rmtree(corePath)


if __name__ == "__main__":
    opt = sys.argv[1]
    if opt == 'update':
        update()
    elif opt == 'uninstall':
        uninstall()
    else:
        install()
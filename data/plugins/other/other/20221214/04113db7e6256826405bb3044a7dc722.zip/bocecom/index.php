<?php


use BOCE\Base;

require_once './src/boce/tool/autoload.php';
class bt_main
{
    public $configPath = '../../data/bocecom.conf';



    public function get_config()
    {
        $config = $this->getBoceConfig();
        return $this->resultResp(0, '获取成功', ['data' => $config]);
    }

    public function set_config()
    {
        $publicKey = trim(_post('public_key'));
        if (empty($publicKey)) {
            return $this->resultResp(1, '公共key不能为空');
        }
        $w = fopen($this->configPath, 'w');
        fwrite($w, json_encode(['public_key' => $publicKey]));
        fclose($w);
        return $this->resultResp(0, '设置成功');
    }

    public function create_task()
    {

        $host = trim(_post('host'));
        $isps = _post('isp');
        $type = _post('type');
        if (empty($host)) {
            return $this->resultResp(1, '域名不能为空');
        }
        $config = $this->getBoceConfig();
        if (empty($config)) {
            return $this->resultResp(2, '请先设置公共key');
        }
        list($status, $rs) = \BOCE\Base::factory($type, $config)->createTask(['host' => $host, 'isps' => explode(',', $isps)]);
        if ($status) {
            return $this->resultResp(0, '创建成功', ['data' => $rs]);
        }
        return $this->resultResp(1, '创建失败');
    }

    public function get_result()
    {
        $task_id = _post('task_id');
        $type = _post('type');
        if (empty($task_id)) {
            return $this->resultResp(1, '任务id不能为空');
        }
        $config = $this->getBoceConfig();
        if (empty($config)) {
            return $this->resultResp(2, '请先设置公共key');
        }
        $rs = Base::factory($type, $config)->getResult($task_id);
        $costs = !empty($rs['list']) ? array_column($rs['list'],'time_total') : [];
        $costs = array_values(array_filter($costs, function ($item) {
            return $item > 0;
        }));
        $max = $costs ? max($costs) : 0;
        $min = $costs ? min($costs) : 0;
        $maxArr = $minArr = [];
        if (!empty($rs['list'])) {
            foreach ($rs['list'] as $item) {
                if ($item['time_total'] == $max) {
                    $maxArr = [
                        'node_name' => $item['node_name'],
                        'cost' => $item['time_total'],
                    ];
                }
                if ($item['time_total'] == $min) {
                    $minArr = [
                        'node_name' => $item['node_name'],
                        'cost' => $item['time_total'],
                    ];
                }
            }
        }

        $rs['cost'] = $costs ? [
            'max' => $maxArr,
            'min' => $minArr,
            'avg' => $costs ? round(array_sum($costs) / count($costs), 2) : 0
        ] : [];
        return $this->resultResp(0, '获取成功', ['data' => $rs]);

    }

    private function getBoceConfig()
    {
        if (!file_exists($this->configPath)) {
            return [];
        }

        $config = json_decode(file_get_contents($this->configPath), true);
        return $config;
    }

    private function resultResp($code, $message, $data = [])
    {
        $res = [
            'code' => $code,
            'msg' => $message,
        ];
        $data = array_merge($res, $data);
        return $data;
    }
}


?>
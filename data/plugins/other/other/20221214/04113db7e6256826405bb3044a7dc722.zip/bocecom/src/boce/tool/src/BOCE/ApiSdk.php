<?php

namespace BOCE;

class ApiSdk
{
    public $host = 'https://api.boce.com/v3';

    public $publicKey;

    public function __construct($config)
    {
        $this->publicKey = $config['public_key'];

    }

    public function getNode(){
        $url = $this->host.'/node/list';
        $res = $this->_curl($url);
        return json_decode($res,1);
    }
    public function createTask($operate,$params){
        $url = $this->host.'/task/create/'.$operate;
        $res = $this->_curl($url, $params);
        return json_decode($res,1);
    }

    public function getTask($operate,$task_id){
        $url = $this->host.'/task/'.$operate.'/'.$task_id;
        $res = $this->_curl($url);
        return json_decode($res,1);
    }


    private  function _curl($url, $post = array())
    {
        $post['key'] = $this->publicKey;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $post = http_build_query($post);
        curl_setopt($ch,CURLOPT_URL,$url.'?'.$post);
        $output = curl_exec($ch);
        //dd($output,$post);
        curl_close($ch);
        return $output;
    }
}
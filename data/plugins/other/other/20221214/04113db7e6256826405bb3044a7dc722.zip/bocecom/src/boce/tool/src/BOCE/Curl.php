<?php

namespace BOCE;

class Curl extends Base
{

    /**
     * @var ApiSdk
     */
    private $api;

    public $type = 'curl';

    public function __construct($config)
    {
        $this->api = new ApiSdk($config);
        $this->config = $config;
    }

    public function createTask($params){
        $params['isps'] = !empty($params['isps']) ? $params['isps'] : [1,2,3];
        $nodes = (new Node($this->config))->gets($params['isps']);
        $rs = $this->api->createTask($this->type,['host' => $params['host'],'node_ids' => implode(',',array_column($nodes,'id'))]);
        if(isset($rs['error_code']) && $rs['error_code'] == 0) {
            $res = [
                'task_id' => $rs['data']['id'],
                'nodes' => $nodes
            ];
            return [true,$res];
        }
        return [false,null];
    }

    public function getResult($task_id){
        $rs = $this->api->getTask($this->type,$task_id);
        return $rs;
    }


}
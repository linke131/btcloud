<?php

namespace BOCE;

class Node
{

    /**
     * @var ApiSdk
     */
    private $api;

    public $ispList = [
        1 => '100017',
        2 => '100025',
        3 => '100026',
        10 => '200000',
        11 => '300000',
    ];

    public function __construct($config)
    {
        $this->api = new ApiSdk($config);
    }

    public function gets($isps = [1,2,3]){
        $apiRs = $this->api->getNode();

        $nodes = !empty($apiRs['data']['list']) ? $apiRs['data']['list'] : [];
        $data = [];
        foreach ($nodes as $item) {
            foreach ($isps as $isp) {
                if ($item['isp_code'] == $this->ispList[$isp]) {
                    $data[] = $item;
                }
            }
        }
        return $data;
    }



}
<?php

namespace BOCE;

class Base
{

    /**
     * @param $type
     * @param $config
     * @return false|mixed
     */
    static public function factory($type,$config)
    {
        try{
            $class = __NAMESPACE__ . '\\' . ucfirst($type);
            if (!class_exists($class)) {
                throw new \Exception('class not found');
            }
            return new $class($config);

        }catch (\Exception $e){
            return false;
        }
    }

    /**
     * @param $isps
     * @return array
     */
    public function getNodes($isps = [1,2,3])
    {
        $isps = empty($isps) ? [1,2,3] : $isps;
        $file = dirname(__DIR__).'/../config/node.json';
        $nodes = json_decode(file_get_contents($file),true);
        $result = [];
        foreach ($nodes as $value){
            if(in_array($value['isp'],$isps)){
                $result[] = $value;
            }
        }
        return $result;
    }




}
    //定义窗口尺寸
    $('.layui-layer-page').css({ 'width': '1080px'});

    //左测菜单切换效果
    $(".bt-w-menu p").click(function () {
        $(this).addClass('bgw').siblings().removeClass('bgw')
    });

    var systemos = 0;
    // 点击系统版本的刷新计数
    var systemos_timeout = null;

    var layer_wait = 0;

    // 数据刷新时间
    var global_timeout = null;
    var global_reflush = 10000;
    // 用户信息
    var global_userid = "";
    // ad
    var ad_init = false;

#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 日志同步到数据脚本
#	读取日志目录中所有站点的日志文件,将日志记录存入数据库中,并清空已转存的日志记录
# +-------------------------------------------------------------------
# | Copyright (c) 2019-2099 土拨鼠 All rights reserved.
# +-------------------------------------------------------------------
# | Author: 圣仔
# +-------------------------------------------------------------------

import sys,os,json,datetime,time
if 'win' in sys.platform:
    try:
        import html
    except:
        os.system('pip install html')
        import html
    try:
        import pymysql
    except:
        os.system('pip install pymysql')
        import pymysql
else:
    import pymysql
    import html

# 设置运行目录
# os.chdir("/www/server/panel")
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..', '..'))
# 添加包引用位置并引用公共包
sys.path.append("class/")
import public
if 'win' in sys.platform:
    config_file = os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))+'/tuboshufenxi/config_cache/config.json'
    config_file2 =os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))+'/tuboshufenxi/config.json'
else:
    config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'
    config_file2 = '/www/server/panel/plugin/tuboshufenxi/config.json'

def spider_jiance(conn,ip_attr):
    spider = ''
    conn.execute("select count(distinct(ip)) from spidersite where spiderip ='" + ip_attr + "'")
    spidercount = conn.fetchone()[0]
    if spidercount > 0:
        spider = '0'
    else:
        spider = '1'
    return spider
def spider_num(conn,website,index,log_timestr):
    timeyear = datetime.datetime.strptime(log_timestr, "%Y-%m-%d %H:%M:%S").strftime("%Y")
    timemonth = datetime.datetime.strptime(log_timestr, "%Y-%m-%d %H:%M:%S").strftime("%m")
    timeday = datetime.datetime.strptime(log_timestr, "%Y-%m-%d %H:%M:%S").strftime("%d")
    shijian=timeyear+"-"+timemonth+"-"+timeday+" 00:00:01"
    conn.execute("INSERT INTO spider_num(website,time,"+index+",spidermun) VALUES ('"+website+"','"+shijian+"','1','1') ON DUPLICATE KEY UPDATE "+index+"="+index+"+1,spidermun=spidermun+1")
    return True
def spider_num_randmun(conn,website,index,log_timestr):
    timeyear = datetime.datetime.strptime(log_timestr, "%Y-%m-%d %H:%M:%S").strftime("%Y")
    timemonth = datetime.datetime.strptime(log_timestr, "%Y-%m-%d %H:%M:%S").strftime("%m")
    timeday = datetime.datetime.strptime(log_timestr, "%Y-%m-%d %H:%M:%S").strftime("%d")
    shijian=timeyear+"-"+timemonth+"-"+timeday+" 00:00:01"
    conn.execute("INSERT INTO spider_num(website,time,"+index+") VALUES ('"+website+"','"+shijian+"','1') ON DUPLICATE KEY UPDATE "+index+"="+index+"+1")
    return True
def spider_num_jiance(conn):
    list1=[]
    list2=[]
    site_list = public.M('sites').field('name').order('id desc').select()
    for oi in site_list:
        list1.append(oi['name'])
        shijian=str(datetime.datetime.now().year)+"-"+str(datetime.datetime.now().month)+"-"+str(datetime.datetime.now().day)+" 00:00:01"
        sql45="insert into spider_num (website,time) values('%s','%s')" % (oi['name'],shijian)
        try:    
            conn.execute(sql45)
        except:
            res5=1
    conn.execute("select website FROM  spider_num")
    iplist = conn.fetchall()
    for i in iplist:
        list2.append(i[0]) 
    asa=sorted(set(list2)-set(list1))
    for ii in asa:
        sqlrtr="DELETE FROM spider_num WHERE website = '"+ii+"'"
        conn.execute(sqlrtr)
    return True
    
def get_shujuku(conn,mysql_db): 
    list1=[]
    list2=[]
    site_list = public.M('sites').field('name').order('id desc').select()
    for oi in site_list:
        list1.append(oi['name'])
    conn.execute("select table_name from information_schema.tables where table_schema= '"+ mysql_db +"' ")
    iplist = conn.fetchall()
    for i in iplist:
        if i[0] != 'monitor_ip' and i[0] != 'monitor_url' and i[0] != 'spidersite' and i[0] != 'spider_num':
            list2.append(i[0])  
    asa=sorted(set(list1)-set(list2))
    asa1=sorted(set(list2)-set(list1))
    for ii in asa:
        exsql = '''create table  `'''+ii+'''` (
                    id INT NOT NULL AUTO_INCREMENT,
                	website text,
                	ip varchar(20),
                	time datetime,
                	day2 int,
                	httpstatus INT,
                	size INT,
                	httpmothed varchar(30),
                	pageurl varchar(250),
                	referer varchar(250),
                	shebieinfo varchar(250),
                	spider INT,
                	spider_index INT,
                	PRIMARY KEY (`id`,`day2`),
					KEY `time` (`time`),
                    KEY `spider` (`spider`),
                    KEY `day2` (`day2`),
                    KEY `spider_index` (`spider_index`),
                    KEY `ip` (`ip`),
                    KEY `shebieinfo` (`shebieinfo`),
                    KEY `httpmothed` (`httpmothed`),
                    KEY `pageurl` (`pageurl`)
                )
                partition by range(day2)(
                    partition p1 values less than(1),
                	partition p2 values less than(2),
                	partition p3 values less than(3),
                	partition p4 values less than(4),
                	partition p5 values less than(5),
                	partition p6 values less than(6),
                	partition p7 values less than(7),
                	partition p8 values less than(8),
                	partition p9 values less than(9),
                	partition p10 values less than(10),
                	partition p11 values less than(11),
                	partition p12 values less than(12),
                	partition p13 values less than(13),
                	partition p14 values less than(14),
                	partition p15 values less than(15),
                	partition p16 values less than(16),
                	partition p17 values less than(17),
                	partition p18 values less than(18),
                	partition p19 values less than(19),
                	partition p20 values less than(20),
                	partition p21 values less than(21),
                	partition p22 values less than(22),
                	partition p23 values less than(23),
                	partition p24 values less than(24),
                	partition p25 values less than(25),
                	partition p26 values less than(26),
                	partition p27 values less than(27),
                	partition p28 values less than(28),
                	partition p29 values less than(29),
                	partition p30 values less than(30),
                	partition p31 values less than(31),
                	partition p32 values less than(32),
                	partition p33 values less than(33)
                    );'''
        try:
            res=conn.execute(exsql)
        except Exception as e:
            res=1
    
    for iii in asa1:
        exsql1 = '''DROP TABLE `'''+iii+'''`;'''
        try:
            res=conn.execute(exsql1)
        except Exception as e:
            return e
            
    return True
#读取配置文件
def get_config():
    # config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'
    #判断文件是否存在
    if not os.path.isfile(config_file):
        f_body = public.ReadFile(config_file2)
        public.WriteFile(config_file,f_body)
    #判断是否从文件读取配置
    if not os.path.exists(config_file):
        return None
    f_body = public.ReadFile(config_file)
    if not f_body:
        return None
    __config = json.loads(f_body)
    return __config
#写配置文件
def set_config(key,value):
    __config=get_config()
    #是否需要初始化配置项
    if not __config: 
        __config = {}
    #是否需要设置配置值
    if key:
        __config[key] = value
    #写入到配置文件
    # config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'
    public.WriteFile(config_file,json.dumps(__config))
    return True
def main():
    # config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'
    # 读取配置项
    if not os.path.exists(config_file):
        if 'win' in sys.platform:
            yinpanming=basedir.split(':')
            logpath =yinpanming[0]+':/BtSoft/wwwlogs/'  
        else:
            logpath = '/www/wwwlogs/'
    else:
        f_body = public.ReadFile(config_file)
        if not f_body:
            logpath = '/www/wwwlogs/'            
        else:
            __config = json.loads(f_body)            
            if not 'logpath' in __config:
                logpath = "/www/wwwlogs/"
            else:
                if 'win' in sys.platform:
                    if __config['logpath'].find("/www/wwwlogs/") == 0 :
                        yinpanming=basedir.split(':')
                        logpath =yinpanming[0]+':/BtSoft/wwwlogs/'
                    else:
                        logpath = __config['logpath']
                else:
                    logpath = __config['logpath']
    if not 'mysql_port' in __config:
        __config['mysql_port'] = 3306
    if not 'logopen' in __config:
        logopen = '1'
    else:
        logopen =__config['logopen']
    log_conn = pymysql.connect(host=__config['mysql_host'], user=__config['mysql_username'],
                               passwd=__config['mysql_psd'], db=__config['mysql_db'],
                               port=int(__config['mysql_port']), charset='utf8')
    conn = log_conn.cursor()
    get_shujuku(conn,__config['mysql_db'])
    spider_num_jiance(conn)
    dirlist = os.listdir(logpath) 
    for i in range(0, len(dirlist)):
        if dirlist[i].find('log') >= 0 and dirlist[i].find('error') < 0  and dirlist[i].find('_access.log') < 0 and dirlist[i].find('free_waf_log') < 0:
            if dirlist[i].find('access.log') == 0:
                continue
            if dirlist[i].find('access_log') == 0:
                continue
            log_file = logpath + dirlist[i]
            websitecom = dirlist[i].replace('.log', '')
            websitecom = websitecom.replace('-access_log', '')
            websitecom = websitecom.replace('-access', '')
            totallogs = 0
            with open(log_file, "r+") as f:
                contexts = f.readlines()
                f.seek(0)
                f.truncate()
                if logopen=='1':
                    with open(logpath+websitecom+"_access.log", "a") as fileaa:  # 只需要将之前的”w"改为“a"即可，代表追加内容
                        for isss in contexts:
                            fileaa.write(isss)
                else:
                    if os.path.isfile(logpath+websitecom+"_access.log") == True:
                        os.remove(logpath+websitecom+"_access.log")
                log_timestr = ''
                logarray = []
                for line in contexts:
                    linearray = line.split()
                    if len(linearray) > 10:
                        ip_attr = line.split()[0]
                        if ip_attr not in public.get_ipaddress():
                            totallogs = totallogs + 1
                            try:
                                timestr = line.split()[3][1:-1].replace(":", " ", 1)  
                                log_timestr2 = datetime.datetime.strptime(timestr,"%d/%b/%Y %H:%M:%S")
                                log_timestr = log_timestr2.strftime("%Y-%m-%d %H:%M:%S")
                            except:
                                print(websitecom + '不支持自定义日志格式解析')
                                sys.exit()
                            httpmothed = line.split()[5].replace('"', '') 
                            pageurl = html.escape(line.split()[6])  
                            httpstatus = line.split()[8]  
                            size = line.split()[9] 
                            referer=line.split()[10]
                            referer = referer.replace('"', '')
                            referer = referer.replace(' ', '')
                            shebieinfo = ''
                            if len(linearray) > 10:
                                for sbi in range(11, len(linearray)):
                                    shebieinfo = shebieinfo + " " + html.escape(line.split()[sbi])
                            shebieinfo = shebieinfo.replace('"', '')
                            shebieinfo = shebieinfo.replace(' ', '')
                            pageurl = htmlencode(pageurl)
                            shebieinfo = htmlencode(shebieinfo)
                            httpmothed = htmlencode(httpmothed)
                            websitecom = htmlencode(websitecom)
                            ip_attr = htmlencode(ip_attr)
                            log_timestr = htmlencode(log_timestr)
                            size = htmlencode(size)
                            httpstatus = htmlencode(httpstatus)
                            
                            if 'Baiduspider' in shebieinfo:
                                if __config['baidu']=='0':
                                    continue
                                spider_index = '1'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'baidu',log_timestr)
                            elif 'Sogouwebspider' in shebieinfo:
                                if __config['sougou']=='0':
                                    continue
                                spider_index = '2'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'sogou',log_timestr)
                            elif '360Spider' in shebieinfo:
                                if __config['s360']=='0':
                                    continue
                                spider_index = '3'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'qh360',log_timestr)
                            elif 'YisouSpider' in shebieinfo:
                                if __config['shenma']=='0':
                                    continue
                                spider_index = '4'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'yisou',log_timestr)
                            elif 'Googlebot' in shebieinfo:
                                if __config['guge']=='0':
                                    continue
                                spider_index = '5'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'google',log_timestr)
                            elif 'bingbot' in shebieinfo:
                                if __config['Bing']=='0':
                                    continue
                                spider_index = '6'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'bing',log_timestr)
                            elif 'YoudaoBot' in shebieinfo:
                                if __config['youdao']=='0':
                                    continue
                                spider_index = '7'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'youdao',log_timestr)
                            elif 'Sosospider' in shebieinfo:
                                if __config['SOSO']=='0':
                                    continue
                                spider_index = '8'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'soso',log_timestr)
                            elif 'CCBot' in shebieinfo:
                                if __config['CC']=='0':
                                    continue
                                spider_index = '9'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'cc',log_timestr)
                            elif 'AhrefsBot' in shebieinfo:
                                if __config['Ahrefs']=='0':
                                    continue
                                spider_index = '10'
                                spider= spider_jiance(conn,ip_attr)
                                spider_num(conn,websitecom,'ahrefs',log_timestr)
                            else:
                                spider_index = '0'
                                spider= '3'
                            spider_num_randmun(conn,websitecom,'rendmun',log_timestr)
                            try:
                                sizeshu =int(size)
                            except:
                                sizeshu = 0
                            try:
                                timeArray = datetime.datetime.strptime(log_timestr, "%Y-%m-%d %H:%M:%S").strftime("%d")
                                datasql = "insert into `"+websitecom+"`(website,ip,time,day2,httpstatus,size,httpmothed,pageurl,shebieinfo,spider,spider_index) values('%s', '%s','%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (websitecom, ip_attr,log_timestr,int(timeArray),httpstatus, sizeshu, httpmothed, pageurl, shebieinfo, spider,spider_index)
                                conn.execute(datasql)
                                log_conn.commit()
                            except Exception as e:
                                print('错误信息: ' + str(e))
                                print('日志格式解析出错: ' + str(datasql))
                # f.seek(0)
                # f.truncate()
            
            print((datetime.datetime.now()).strftime("%Y-%m-%d %H:%M:%S") + ' ' + websitecom + ' 新同步 ' + str(totallogs) + ' 条日志到数据库')
            
    conn.close()
    log_conn.close()
    


# 过虑特殊字符
def htmlencode(strtxt):
    strtxt = strtxt.replace('?', '&#63;')
    strtxt = strtxt.replace('"', '')
    strtxt = strtxt.replace("'", "")
    strtxt = strtxt.replace("\\", "")
    strtxt = strtxt.replace("(", '')
    strtxt = strtxt.replace(")", '')
    strtxt = strtxt.replace('+', '')
    strtxt = strtxt.replace('>', '')
    strtxt = strtxt.replace('<', '')
    strtxt = strtxt.replace('*', "")
    strtxt = strtxt.replace('[', '/[')
    strtxt = strtxt.replace(']', '/]')
    strtxt = strtxt.replace('$', '')
    return strtxt
    



if __name__ == "__main__":
    try:
        # config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'
        f_body = public.ReadFile(config_file)
        __config = json.loads(f_body)  
        if __config['open']=='0':
            set_config('open','1')
            main()
            set_config('open','0')
            print('感谢使用本插件')  
    except Exception as e:
       set_config('open','0')
       print('感谢使用本插件'+'  错误:'+str(e)) 
    
return {
    ["status"] = true,
    ["info"] = "帝国CMS后台代码执行",
    ["method"] = "POST",
    ["keys"] = {
        ["mydbname"] = "",
        ["dbchar"] = "",
        ["tablename[]"] = "$_BT_REGEXP[(|;|)]"
    }
}
return {
    ["status"] = true,
    ["info"] = "phpcms后台代码执行漏洞",
    ["method"] = "POST",
    ["keys"] = {
        ["data[uc_api','11');/*]"] = "",
    }
}
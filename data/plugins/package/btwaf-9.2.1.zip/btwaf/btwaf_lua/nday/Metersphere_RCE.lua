return {
    ["status"] = true,
    ["info"] = "Metersphere代码执行漏洞",
    ["method"] = "POST",
    ["keys"] = {
        ["entry"] = "Evil",
        ["request"] = "",
    }
}
return {
    ["status"] = true,
    ["info"] = "蓝凌OA代码执行漏洞",
    ["method"] = "POST",
    ["keys"] = {
        ["s_bean"] = "ruleFormulaValidate",
        ["script"] = "",
    }
}
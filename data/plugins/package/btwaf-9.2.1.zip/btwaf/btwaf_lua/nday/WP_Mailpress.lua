return {
    ["status"] = true,
    ["info"] = "WorePress MailPress 代码执行漏洞",
    ["method"] = "POST",
    ["keys"] = {
        ["action"] = "",
        ["id"] = "",
        ["subject"] = "$_BT_PHPCODE"
    }
}
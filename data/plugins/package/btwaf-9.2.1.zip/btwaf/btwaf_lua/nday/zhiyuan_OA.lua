return {
    ["status"] = true,
    ["info"] = "致远OA-任意用户登录漏洞",
    ["method"] = "POST",
    ["keys"] = {
        ["method"] = "access",
         ["enc"] = "$_BT_STARTTT5uZnR0YmhmL21qb2wvZXBkL2dwbWVmcy9wcWZvJ04",
    }
}
pluginPath=/www/server/panel/plugin/disk_analysis
bash $pluginPath/install.sh install
btpython code_v.py
python2 code_v.py
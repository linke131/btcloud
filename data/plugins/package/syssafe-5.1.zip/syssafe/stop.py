
#!/www/server/panel/pyenv/bin/python
#coding: utf-8
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: hwliang<hwl@bt.cn>
#-------------------------------------------------------------------

import os,sys
os.chdir('/www/server/panel')
os.system("/www/server/panel/pyenv/bin/python3 plugin/syssafe/syssafe_pub.py 0")
pluginPath=/www/server/panel/plugin/oneav
bash $pluginPath/install.sh install
2.4
1.修复创建目标目录的软链时未能过滤的问题
2.优化特殊情况下路径过滤出错导致的系统故障
3.新增防篡改模拟攻击功能
4.修复部分情况下内核文件识别错误，导致服务无法开的问题

3.0
1、增加对aliyunOS、almlinux、amazonlinux、centos8s、centos9、kylinV10、euler20、opencloudOS、openeuler、rocky_linux、tencentOS等系统的兼容
2、优化内核模块安装成功率
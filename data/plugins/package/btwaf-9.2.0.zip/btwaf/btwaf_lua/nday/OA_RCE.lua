return {
    ["status"] = true,
    ["info"] = "泛微OA代码执行漏洞",
    ["method"] = "POST",
    ["keys"] = {
        ["bsh.script"] = "",
        ["bsh.servlet.captureOutErr"] = "",
        ["bsh.servlet.output"]="",
    }
}
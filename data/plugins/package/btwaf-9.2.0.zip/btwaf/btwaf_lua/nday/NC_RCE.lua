return {
    ["status"] = true,
    ["info"] = "用友NC代码执行漏洞",
    ["method"] = "POST",
    ["keys"] = {
        ["bsh.script"] = "",
        ["bsh.servlet.captureOutErr"] = "",
        ["bsh.servlet.output"]="",
    }
}
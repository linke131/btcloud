return {
    ["status"] = true,
    ["info"] = "ThinkCMF代码执行漏洞",
    ["method"] = "GET",
    ["keys"] = {
        ["a"] = "fetch",
        ["content"] = "$_BT_PHPCODE",
    }
}